import { useEffect, useState, type FormEvent } from 'react';
import {
  Archive,
  X,
  Search,
  Sparkles,
  Loader2,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Car,
  User,
  Swords,
  Trees,
  Layers,
  CloudSun,
  Volume2,
  Bell,
  Image as ImageIcon,
  Shapes,
  Database,
} from 'lucide-react';
import {
  ASSET_DEPARTMENTS,
  type AssetHuntResult,
} from '../services/assetHunterService';
import {
  AssetPickerList,
  stopAssetPreviewAudio,
} from './AssetPickerList';
import type {
  AssetCategory,
  Language,
  StudioAssetItem,
} from '../types/studio';

interface VaultPanelProps {
  open: boolean;
  language: Language;
  query: string;
  selectedCategories: AssetCategory[];
  isHunting: boolean;
  result: AssetHuntResult | null;
  candidateAssets: StudioAssetItem[];
  selectedAssets: StudioAssetItem[];
  vaultUrl?: string;
  onHunt: (query: string, categories?: AssetCategory[]) => void;
  onCategoriesChange: (categories: AssetCategory[]) => void;
  onKeepAsset: (item: StudioAssetItem) => void;
  onRejectAsset: (item: StudioAssetItem) => void;
  onRemoveSelectedAsset: (item: StudioAssetItem) => void;
  onClose: () => void;
}

const DEPARTMENT_ICONS: Record<AssetCategory, typeof Car> = {
  vehicles: Car,
  characters: User,
  weapons_gear: Swords,
  village_world: Trees,
  textures_pbr: Layers,
  hdri_sky: CloudSun,
  audio_sfx: Volume2,
  app_audio: Bell,
  wikimedia_photos: ImageIcon,
  iconify_icons: Shapes,
};

export function VaultPanel({
  open,
  language,
  query,
  selectedCategories,
  isHunting,
  result,
  candidateAssets,
  selectedAssets,
  vaultUrl,
  onHunt,
  onCategoriesChange,
  onKeepAsset,
  onRejectAsset,
  onRemoveSelectedAsset,
  onClose,
}: VaultPanelProps) {
  const [draftQuery, setDraftQuery] = useState(query);

  useEffect(() => {
    setDraftQuery(query);
  }, [query]);

  // Stop any playing inline audio cleanly when the Vault sheet closes
  useEffect(() => {
    if (!open) {
      stopAssetPreviewAudio();
    }
  }, [open]);

  if (!open) return null;

  const toggleDepartment = (deptId: AssetCategory) => {
    const exists = selectedCategories.includes(deptId);
    const next = exists
      ? selectedCategories.filter((c) => c !== deptId)
      : [...selectedCategories, deptId];
    onCategoriesChange(next);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    stopAssetPreviewAudio();
    onHunt(
      draftQuery.trim(),
      selectedCategories.length > 0 ? selectedCategories : undefined
    );
  };

  const handleClose = () => {
    stopAssetPreviewAudio();
    onClose();
  };

  const activeDeptLabels = (result?.departments ?? selectedCategories)
    .map((id) => ASSET_DEPARTMENTS.find((d) => d.id === id)?.shortLabel ?? id)
    .join(', ');

  const hasAnyAssets = candidateAssets.length > 0 || selectedAssets.length > 0;

  return (
    <div
      className="fixed inset-0 z-[60] bg-slate-900/25 backdrop-blur-[3px] flex items-end sm:items-center justify-center sm:p-4"
      onClick={handleClose}
      role="dialog"
      aria-modal="true"
      aria-label="Asset Vault Hunter"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-full sm:max-w-xl mx-auto bg-[#F8FAFE]/95 backdrop-blur-2xl border-t sm:border border-slate-200/90 rounded-t-3xl sm:rounded-3xl shadow-[0_-14px_48px_rgba(15,23,42,0.18)] flex flex-col max-h-[88dvh] sm:max-h-[84dvh] overflow-hidden"
      >
        {/* Mobile Drag Handle */}
        <div className="pt-2.5 pb-1 flex justify-center sm:hidden shrink-0">
          <div className="w-10 h-1 rounded-full bg-slate-300/90" aria-hidden="true" />
        </div>

        {/* Sticky Sheet Header */}
        <div className="px-3.5 sm:px-5 py-2.5 bg-white/85 backdrop-blur-xl border-b border-slate-200/80 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#10B981] to-[#007AFF] text-white flex items-center justify-center shadow-xs shrink-0"
              aria-hidden="true"
            >
              <Archive className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h2 className="text-[14px] sm:text-[15px] font-bold text-[#0F172A] tracking-tight truncate">
                {language === 'hi' ? 'एसेट वॉल्ट · हंटर' : 'Asset Vault · Hunter'}
              </h2>
              <p className="text-[11px] font-medium text-[#64748B] truncate">
                {language === 'hi'
                  ? 'डिपार्टमेंट सर्च · ✓ Keep / ✕ Reject पिकर'
                  : 'Department search · ✓ Keep / ✕ Reject picker'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleClose}
            aria-label="Close Asset Vault"
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200/80 text-[#0F172A] flex items-center justify-center transition-colors shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search Controls + Department Chips */}
        <div className="px-3 sm:px-5 pt-2.5 pb-2.5 bg-white/75 border-b border-slate-200/75 flex flex-col gap-2 shrink-0">
          {/* Horizontal Scrollable Department Chips */}
          <div
            className="flex items-center gap-1.5 overflow-x-auto pb-0.5 studio-scroll w-full min-w-0"
            role="group"
            aria-label="Asset Departments"
          >
            <button
              type="button"
              onClick={() => onCategoriesChange([])}
              aria-pressed={selectedCategories.length === 0}
              className={`h-8 px-2.5 rounded-full text-[11px] font-semibold inline-flex items-center gap-1 shrink-0 border transition-all cursor-pointer whitespace-nowrap ${
                selectedCategories.length === 0
                  ? 'bg-[#0F172A] text-white border-[#0F172A] shadow-xs'
                  : 'bg-white border-slate-200/90 text-[#475569] hover:bg-slate-50'
              }`}
            >
              <Sparkles className="w-3 h-3 shrink-0" aria-hidden="true" />
              <span>Auto</span>
            </button>

            {ASSET_DEPARTMENTS.map((dept) => {
              const Icon = DEPARTMENT_ICONS[dept.id];
              const isActive = selectedCategories.includes(dept.id);
              return (
                <button
                  key={dept.id}
                  type="button"
                  onClick={() => toggleDepartment(dept.id)}
                  aria-pressed={isActive}
                  className={`h-8 px-2.5 rounded-full text-[11px] font-semibold inline-flex items-center gap-1 shrink-0 border transition-all cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-gradient-to-r from-[#10B981] to-[#007AFF] text-white border-transparent shadow-xs'
                      : 'bg-white border-slate-200/90 text-[#0F172A] hover:bg-slate-50'
                  }`}
                >
                  <Icon
                    className={`w-3 h-3 shrink-0 ${
                      isActive ? 'text-white' : dept.accentText
                    }`}
                    aria-hidden="true"
                  />
                  <span>{dept.label}</span>
                </button>
              );
            })}
          </div>

          {/* Search Bar + Colorful Hunt Assets Button */}
          <form onSubmit={handleSubmit} className="flex items-center gap-1.5 w-full min-w-0">
            <div className="relative flex-1 min-w-0">
              <Search
                className="w-3.5 h-3.5 text-[#64748B] absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="text"
                value={draftQuery}
                onChange={(e) => setDraftQuery(e.target.value)}
                placeholder={
                  language === 'hi'
                    ? 'कार, ट्रक, आइकन या फोटो खोजें...'
                    : 'Search truck, sword, sunset sky, icons...'
                }
                aria-label="Search studio assets"
                className="w-full min-w-0 h-10 pl-8 pr-2.5 rounded-xl bg-white border border-slate-200/90 text-[12px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15"
              />
            </div>

            <button
              type="submit"
              disabled={isHunting}
              className="h-10 px-3 rounded-xl bg-gradient-to-r from-[#10B981] via-[#007AFF] to-[#5856D6] hover:brightness-105 disabled:opacity-65 text-white text-[11.5px] font-bold inline-flex items-center justify-center gap-1.5 shadow-[0_4px_14px_rgba(0,122,255,0.24)] transition-all shrink-0 whitespace-nowrap cursor-pointer active:scale-[0.98]"
            >
              {isHunting ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
              ) : (
                <Sparkles className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              )}
              <span>{isHunting ? 'Hunting...' : 'Hunt Assets'}</span>
            </button>
          </form>

          {/* Live Count & Timeout Status Badge Row */}
          <div className="flex flex-wrap items-center justify-between gap-1.5 text-[10.5px]">
            {isHunting ? (
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-[#007AFF]/10 text-[#007AFF] font-semibold">
                <Loader2 className="w-3 h-3 animate-spin shrink-0" aria-hidden="true" />
                <span>Scanning scoped departments (5s max)...</span>
              </span>
            ) : result ? (
              <div className="flex flex-wrap items-center gap-1.5 min-w-0">
                <span
                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full font-semibold ${
                    result.timedOut
                      ? 'bg-[#F59E0B]/15 text-[#B45309]'
                      : candidateAssets.length > 0
                        ? 'bg-[#10B981]/12 text-[#047857]'
                        : 'bg-slate-100 text-[#475569]'
                  }`}
                >
                  {result.timedOut ? (
                    <Clock className="w-3 h-3 shrink-0" aria-hidden="true" />
                  ) : (
                    <CheckCircle2 className="w-3 h-3 shrink-0" aria-hidden="true" />
                  )}
                  <span className="tabular-nums">
                    {candidateAssets.length} / 16 active
                  </span>
                </span>

                {activeDeptLabels && (
                  <span className="px-2 py-0.5 rounded-full bg-white border border-slate-200/80 text-[#475569] font-medium truncate max-w-[180px]">
                    {activeDeptLabels}
                  </span>
                )}

                <span className="text-[10px] font-mono text-[#64748B] tabular-nums">
                  {result.fromCache ? 'Cached · ' : ''}
                  {result.durationMs}ms
                </span>
              </div>
            ) : (
              <span className="inline-flex items-center gap-1 text-[#64748B] font-medium">
                <Database className="w-3 h-3 text-[#10B981] shrink-0" aria-hidden="true" />
                <span>
                  {language === 'hi'
                    ? 'डिपार्टमेंट चुनें या कीवर्ड लिखकर Hunt Assets दबाएँ'
                    : 'Pick a department or enter keywords to hunt'}
                </span>
              </span>
            )}

            {result && result.catalogTotalCount > 0 && (
              <span className="text-[10px] font-mono text-[#64748B] tabular-nums shrink-0">
                Vault: {result.catalogTotalCount}
              </span>
            )}
          </div>

          {/* Non-blocking Timeout / Source Warning Banner */}
          {result && result.warnings.length > 0 && !isHunting && (
            <div className="rounded-xl bg-[#F59E0B]/12 border border-[#F59E0B]/30 px-2.5 py-1.5 flex items-center gap-1.5 text-[11px] font-medium text-[#92400E]">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-[#D97706]" aria-hidden="true" />
              <span className="truncate">{result.warnings.join(' · ')}</span>
            </div>
          )}
        </div>

        {/* Scrollable Interactive Picker Grid */}
        <div className="flex-1 min-h-0 overflow-y-auto studio-scroll px-3 sm:px-5 pt-3 pb-8">
          {isHunting ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {Array.from({ length: 6 }).map((_, idx) => (
                <div
                  key={idx}
                  className="bg-white/80 border border-slate-200/75 rounded-2xl p-2 flex flex-col gap-2 animate-pulse"
                >
                  <div className="w-full aspect-[16/10] rounded-xl bg-slate-200/70" />
                  <div className="h-3 w-3/4 rounded bg-slate-200/70" />
                  <div className="h-6 w-full rounded-xl bg-slate-100" />
                </div>
              ))}
            </div>
          ) : hasAnyAssets ? (
            <AssetPickerList
              candidates={candidateAssets}
              selectedAssets={selectedAssets}
              language={language}
              onKeep={onKeepAsset}
              onReject={onRejectAsset}
              onRemoveSelected={onRemoveSelectedAsset}
            />
          ) : result ? (
            <div className="rounded-2xl bg-white/85 border border-slate-200/80 p-5 text-center flex flex-col items-center gap-2">
              <div className="w-10 h-10 rounded-2xl bg-slate-100 text-[#64748B] flex items-center justify-center">
                <Search className="w-5 h-5" aria-hidden="true" />
              </div>
              <p className="text-[13px] font-bold text-[#0F172A]">
                {language === 'hi'
                  ? 'इस डिपार्टमेंट में कोई एसेट नहीं मिला'
                  : 'No matches in scanned departments'}
              </p>
              <p className="text-[11.5px] text-[#64748B] max-w-xs leading-relaxed">
                {language === 'hi'
                  ? 'दूसरा डिपार्टमेंट चिप चुनें या Icons / Photos लाइव सर्च आज़माएँ।'
                  : 'Try another keyword, switch department chips, or tap Icons / Photos for live asset discovery.'}
              </p>
            </div>
          ) : (
            <div className="rounded-2xl bg-white/85 border border-slate-200/80 p-4 flex flex-col gap-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[12px] font-bold text-[#0F172A]">
                  {language === 'hi'
                    ? 'क्विक डिपार्टमेंट हंट'
                    : 'Quick Scoped Hunts'}
                </span>
                <span className="text-[10px] font-mono text-[#64748B] truncate max-w-[160px]">
                  {vaultUrl ? 'catalog.json linked' : 'Default Vault'}
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { label: 'Trucks & Cars', q: 'truck', cats: ['vehicles'] as AssetCategory[] },
                  { label: 'Village Props', q: 'house', cats: ['village_world'] as AssetCategory[] },
                  { label: 'Game SFX', q: 'engine', cats: ['audio_sfx'] as AssetCategory[] },
                  { label: 'UI Icons', q: 'car', cats: ['iconify_icons'] as AssetCategory[] },
                  { label: 'Real Photos', q: 'indian village', cats: ['wikimedia_photos'] as AssetCategory[] },
                ].map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => {
                      setDraftQuery(preset.q);
                      onCategoriesChange(preset.cats);
                      onHunt(preset.q, preset.cats);
                    }}
                    className="h-8 px-2.5 rounded-xl bg-[#F3F6FB] hover:bg-[#E7EEF9] border border-slate-200/85 text-[11px] font-semibold text-[#0F172A] transition-colors cursor-pointer"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Compact Footer Showing Manifest Sync Status */}
        <div className="px-3.5 sm:px-5 py-2 bg-white/90 border-t border-slate-200/80 flex items-center justify-between gap-2 text-[10.5px] text-[#64748B] shrink-0 pb-[max(0.5rem,env(safe-area-inset-bottom))]">
          <span className="truncate font-medium">
            {language === 'hi'
              ? `चुने गए: ${selectedAssets.length} · assets/manifest.json सिंक`
              : `Kept: ${selectedAssets.length} · synced to assets/manifest.json`}
          </span>
          <span className="font-mono text-[#10B981] font-semibold shrink-0">
            5s Guard
          </span>
        </div>
      </div>
    </div>
  );
}
