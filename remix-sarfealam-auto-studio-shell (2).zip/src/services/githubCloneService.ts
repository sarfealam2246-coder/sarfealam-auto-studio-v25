import { studioBus } from './eventBus';
import type { VirtualFile } from '../types/studio';

const GITHUB_TIMEOUT_MS = 10_000;
const MAX_CLONED_FILES = 35;
const MAX_BLOB_BYTES = 180_000;

export interface ParsedGitHubRepo {
  owner: string;
  repo: string;
  normalized: string;
}

export interface GitHubCloneResult {
  ok: boolean;
  repo: string;
  branch: string;
  files: VirtualFile[];
  totalTreeCount: number;
  durationMs: number;
  error?: string;
}

const EXCLUDED_DIR_PREFIXES = [
  'node_modules/',
  'dist/',
  'build/',
  '.git/',
  '.next/',
  '.nuxt/',
  '.svelte-kit/',
  '.cache/',
  'coverage/',
  'vendor/',
  'out/',
  'android/app/build/',
  'ios/Pods/',
];

const EXCLUDED_FILENAMES = new Set([
  'package-lock.json',
  'yarn.lock',
  'pnpm-lock.yaml',
  'bun.lockb',
  'cargo.lock',
  'composer.lock',
  'gemfile.lock',
]);

const ALLOWED_TEXT_EXTENSIONS = new Set([
  'html',
  'htm',
  'css',
  'scss',
  'sass',
  'less',
  'js',
  'jsx',
  'ts',
  'tsx',
  'mjs',
  'cjs',
  'json',
  'md',
  'mdx',
  'txt',
  'yml',
  'yaml',
  'toml',
  'xml',
  'svg',
  'gd',
  'dart',
  'cs',
  'glsl',
  'vert',
  'frag',
  'env',
  'example',
]);

export function parseGitHubRepoInput(repoInput: string): ParsedGitHubRepo | null {
  const trimmed = repoInput.trim();
  if (!trimmed) return null;

  let cleaned = trimmed
    .replace(/^git@github\.com:/i, '')
    .replace(/^https?:\/\/(?:www\.)?github\.com\//i, '')
    .replace(/^github\.com\//i, '')
    .replace(/\.git(?:$|[?#])/i, '')
    .replace(/^\/+|\/+$/g, '');

  // Strip query/hash fragments
  cleaned = cleaned.split(/[?#]/)[0];
  const parts = cleaned.split('/').filter(Boolean);
  if (parts.length < 2) return null;

  const owner = parts[0].trim();
  const repo = parts[1].trim();
  if (!/^[a-zA-Z0-9._-]+$/.test(owner) || !/^[a-zA-Z0-9._-]+$/.test(repo)) {
    return null;
  }

  return {
    owner,
    repo,
    normalized: `${owner}/${repo}`,
  };
}

function inferLanguageFromPath(path: string): string {
  const ext = path.split('.').pop()?.toLowerCase() ?? '';
  if (ext === 'tsx' || ext === 'ts') return ext;
  if (ext === 'jsx' || ext === 'js' || ext === 'mjs' || ext === 'cjs') return 'js';
  if (ext === 'json') return 'json';
  if (ext === 'html' || ext === 'htm') return 'html';
  if (ext === 'css' || ext === 'scss' || ext === 'less') return 'css';
  if (ext === 'md' || ext === 'mdx') return 'markdown';
  if (ext === 'svg' || ext === 'xml') return 'xml';
  if (ext === 'gd') return 'gdscript';
  if (ext === 'dart') return 'dart';
  if (ext === 'cs') return 'csharp';
  if (ext === 'yml' || ext === 'yaml') return 'yaml';
  return 'text';
}

function isClonableTextPath(path: string, size?: number): boolean {
  const lower = path.toLowerCase();
  if (typeof size === 'number' && size > MAX_BLOB_BYTES) return false;

  for (const prefix of EXCLUDED_DIR_PREFIXES) {
    if (lower.startsWith(prefix) || lower.includes(`/${prefix}`)) {
      return false;
    }
  }

  const fileName = lower.split('/').pop() ?? lower;
  if (EXCLUDED_FILENAMES.has(fileName)) return false;
  if (fileName.startsWith('.') && fileName !== '.env.example') return false;

  const dotIdx = fileName.lastIndexOf('.');
  if (dotIdx <= 0) {
    return fileName === 'readme' || fileName === 'license';
  }
  const ext = fileName.slice(dotIdx + 1);
  return ALLOWED_TEXT_EXTENSIONS.has(ext);
}

function scoreFilePriority(path: string): number {
  const lower = path.toLowerCase();
  if (lower === 'index.html' || lower === 'docs/index.html') return 100;
  if (lower === 'package.json' || lower === 'readme.md') return 95;
  if (lower.startsWith('src/') && /\.(tsx|ts|jsx|js|css)$/.test(lower)) return 90;
  if (/\.(html|htm)$/.test(lower)) return 85;
  if (/\.(css|js|ts|tsx|jsx)$/.test(lower)) return 80;
  if (lower.startsWith('docs/') || lower.startsWith('assets/')) return 75;
  if (lower.endsWith('.json') || lower.endsWith('.md')) return 70;
  return 50;
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs = GITHUB_TIMEOUT_MS
): Promise<Response> {
  const controller = new AbortController();
  const timerId = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    window.clearTimeout(timerId);
  }
}

function buildGitHubHeaders(githubPat?: string, rawAccept = false): HeadersInit {
  const headers: Record<string, string> = {
    Accept: rawAccept
      ? 'application/vnd.github.raw+json'
      : 'application/vnd.github+json',
  };
  const pat = githubPat?.trim();
  if (pat) {
    headers.Authorization = `Bearer ${pat}`;
  }
  return headers;
}

interface GitHubTreeItem {
  path?: string;
  type?: string;
  size?: number;
}

async function fetchFileContent(
  owner: string,
  repo: string,
  branch: string,
  filePath: string,
  githubPat?: string
): Promise<string | null> {
  const encodedPath = filePath
    .split('/')
    .map((seg) => encodeURIComponent(seg))
    .join('/');

  const pat = githubPat?.trim();
  const url = pat
    ? `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(
        repo
      )}/contents/${encodedPath}?ref=${encodeURIComponent(branch)}`
    : `https://raw.githubusercontent.com/${encodeURIComponent(
        owner
      )}/${encodeURIComponent(repo)}/${encodeURIComponent(branch)}/${encodedPath}`;

  try {
    const res = await fetchWithTimeout(
      url,
      {
        method: 'GET',
        headers: pat ? buildGitHubHeaders(pat, true) : undefined,
      },
      GITHUB_TIMEOUT_MS
    );
    if (!res.ok) return null;
    const text = await res.text();
    // Guard against unexpected binary payloads containing NUL bytes
    if (text.includes('\u0000')) return null;
    return text;
  } catch {
    return null;
  }
}

export async function cloneGitHubRepo(
  repoInput: string,
  githubPat?: string
): Promise<GitHubCloneResult> {
  const startedAt = Date.now();
  const parsed = parseGitHubRepoInput(repoInput);

  studioBus.emit('bot:progress', {
    botId: 'github',
    status: 'working',
    progress: 15,
    message: parsed ? `Connecting to ${parsed.normalized}...` : 'Parsing GitHub repo...',
  });

  let finalStatus: 'ready' | 'error' = 'ready';
  let finalProgress = 100;
  let finalMessage = 'GitHub clone complete';

  try {
    if (!parsed) {
      finalStatus = 'error';
      finalProgress = 0;
      finalMessage = 'Invalid repo format (use owner/repo)';
      return {
        ok: false,
        repo: repoInput.trim(),
        branch: '',
        files: [],
        totalTreeCount: 0,
        durationMs: Date.now() - startedAt,
        error: 'Enter a valid GitHub repo (e.g. owner/repo or https://github.com/owner/repo).',
      };
    }

    const { owner, repo, normalized } = parsed;
    const apiHeaders = buildGitHubHeaders(githubPat, false);

    // 1. Fetch repository metadata for default_branch
    const repoMetaRes = await fetchWithTimeout(
      `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(
        repo
      )}`,
      { method: 'GET', headers: apiHeaders },
      GITHUB_TIMEOUT_MS
    );

    if (!repoMetaRes.ok) {
      const hint =
        repoMetaRes.status === 404
          ? 'Repo not found (or private — add GitHub PAT in Secrets).'
          : repoMetaRes.status === 403
            ? 'GitHub API rate limit reached — add a GitHub PAT in Secrets.'
            : `GitHub returned HTTP ${repoMetaRes.status}.`;
      throw new Error(hint);
    }

    const repoMeta = (await repoMetaRes.json()) as {
      default_branch?: string;
    };
    const branch = repoMeta.default_branch?.trim() || 'main';

    studioBus.emit('bot:progress', {
      botId: 'github',
      status: 'working',
      progress: 40,
      message: `Indexing ${normalized}@${branch}...`,
    });

    // 2. Fetch recursive git tree
    const treeRes = await fetchWithTimeout(
      `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(
        repo
      )}/git/trees/${encodeURIComponent(branch)}?recursive=1`,
      { method: 'GET', headers: apiHeaders },
      GITHUB_TIMEOUT_MS
    );

    if (!treeRes.ok) {
      throw new Error(`Unable to read repo tree (HTTP ${treeRes.status}).`);
    }

    const treeJson = (await treeRes.json()) as {
      tree?: GitHubTreeItem[];
    };
    const rawTree = Array.isArray(treeJson.tree) ? treeJson.tree : [];

    const candidates = rawTree
      .filter(
        (item): item is { path: string; type: string; size?: number } =>
          item.type === 'blob' &&
          typeof item.path === 'string' &&
          isClonableTextPath(item.path, item.size)
      )
      .sort((a, b) => scoreFilePriority(b.path) - scoreFilePriority(a.path))
      .slice(0, MAX_CLONED_FILES);

    if (candidates.length === 0) {
      throw new Error('No readable text/source files found in repository.');
    }

    // 3. Fetch up to 35 files in controlled batches
    const clonedFiles: VirtualFile[] = [];
    const batchSize = 6;
    const now = Date.now();

    for (let i = 0; i < candidates.length; i += batchSize) {
      const slice = candidates.slice(i, i + batchSize);
      const batchProgress = Math.min(
        92,
        45 + Math.round(((i + slice.length) / candidates.length) * 47)
      );
      studioBus.emit('bot:progress', {
        botId: 'github',
        status: 'working',
        progress: batchProgress,
        message: `Cloning ${Math.min(i + slice.length, candidates.length)}/${candidates.length} files...`,
      });

      const contents = await Promise.all(
        slice.map(async (entry) => {
          const content = await fetchFileContent(
            owner,
            repo,
            branch,
            entry.path,
            githubPat
          );
          if (content === null) return null;
          return {
            path: entry.path,
            content,
            language: inferLanguageFromPath(entry.path),
            updatedAt: now,
            generatedBy: 'github' as const,
          };
        })
      );

      for (const file of contents) {
        if (file) clonedFiles.push(file);
      }
    }

    if (clonedFiles.length === 0) {
      throw new Error('Failed to download source file contents from GitHub.');
    }

    finalStatus = 'ready';
    finalProgress = 100;
    finalMessage = `Cloned ${clonedFiles.length} files from ${normalized}`;

    return {
      ok: true,
      repo: normalized,
      branch,
      files: clonedFiles,
      totalTreeCount: rawTree.length,
      durationMs: Date.now() - startedAt,
    };
  } catch (err) {
    const isTimeout = err instanceof DOMException && err.name === 'AbortError';
    const message = isTimeout
      ? 'GitHub clone timed out after 10s.'
      : err instanceof Error
        ? err.message
        : 'GitHub clone failed.';

    finalStatus = 'error';
    finalProgress = 0;
    finalMessage = message;

    return {
      ok: false,
      repo: parsed?.normalized ?? repoInput.trim(),
      branch: '',
      files: [],
      totalTreeCount: 0,
      durationMs: Date.now() - startedAt,
      error: message,
    };
  } finally {
    studioBus.emit('bot:progress', {
      botId: 'github',
      status: finalStatus,
      progress: finalProgress,
      message: finalMessage,
    });
  }
}
