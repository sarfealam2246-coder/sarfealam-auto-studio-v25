import type { StudioSecrets } from '../types/studio';

export const SECRETS_STORAGE_KEY = 'sarfealam_studio_secrets_v2';

export const DEFAULT_2026_MODELS = {
  gemini: 'gemini-3.8-flash',
  geminiLive: 'gemini-3.8-live',
  geminiTts: 'gemini-3.8-flash-tts',
  nvidia: 'qwen/qwen3-next-80b-a3b-instruct',
  groq: 'openai/gpt-oss-120b',
  openRouter: 'qwen/qwen3-coder:free',
  cohere: 'command-a-03-2025',
} as const;

export const DEFAULT_TARGET_REPO = 'sarfealam2246-coder/sarfealam-auto-studio-v2';

export const DEFAULT_ASSET_VAULT_URL =
  'https://raw.githubusercontent.com/sarfealam2246-coder/sarfealam-3d-assets/main/catalog.json';

export const STUDIO_SUPABASE_SQL = `-- Sarfealam Auto-Studio · Studio Supabase Schema (Memory & Skills Only)
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS public.studio_memory (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_key TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'general',
  content TEXT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.dynamic_skills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  trigger_keywords TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  instructions TEXT NOT NULL,
  engine_scope TEXT NOT NULL DEFAULT 'auto',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.error_memory (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fingerprint TEXT NOT NULL,
  stage TEXT NOT NULL,
  error_message TEXT NOT NULL,
  resolution TEXT NOT NULL,
  hit_count INTEGER NOT NULL DEFAULT 1,
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_studio_memory_category ON public.studio_memory (category);
CREATE INDEX IF NOT EXISTS idx_dynamic_skills_active ON public.dynamic_skills (active);
CREATE INDEX IF NOT EXISTS idx_error_memory_fingerprint ON public.error_memory (fingerprint);
`;

export function parseTargetRepo(targetRepo: string): {
  owner: string;
  repo: string;
  normalized: string;
} {
  const cleaned = targetRepo.trim().replace(/^https?:\/\/github\.com\//i, '').replace(/\.git$/i, '').replace(/^\/+|\/+$/g, '');
  const parts = cleaned.split('/').filter(Boolean);
  if (parts.length >= 2) {
    return {
      owner: parts[0],
      repo: parts[1],
      normalized: `${parts[0]}/${parts[1]}`,
    };
  }
  return {
    owner: 'sarfealam2246-coder',
    repo: 'sarfealam-auto-studio-v2',
    normalized: cleaned || DEFAULT_TARGET_REPO,
  };
}

export function createDefaultSecrets(): StudioSecrets {
  const { owner, repo, normalized } = parseTargetRepo(DEFAULT_TARGET_REPO);
  return {
    geminiApiKey: '',
    geminiModel: DEFAULT_2026_MODELS.gemini,
    geminiLiveModel: DEFAULT_2026_MODELS.geminiLive,
    geminiTtsModel: DEFAULT_2026_MODELS.geminiTts,
    nvidiaApiKey: '',
    nvidiaModel: DEFAULT_2026_MODELS.nvidia,
    groqApiKey: '',
    groqModel: DEFAULT_2026_MODELS.groq,
    openRouterApiKey: '',
    openRouterModel: DEFAULT_2026_MODELS.openRouter,
    cohereApiKey: '',
    cohereModel: DEFAULT_2026_MODELS.cohere,
    githubToken: '',
    githubOwner: owner,
    githubRepo: repo,
    targetRepo: normalized,
    assetVaultUrl: DEFAULT_ASSET_VAULT_URL,
    studioSupabaseUrl: '',
    studioSupabaseAnonKey: '',
    appsSupabaseUrl: '',
    appsSupabaseAnonKey: '',
  };
}

export function loadSecrets(): StudioSecrets {
  const defaults = createDefaultSecrets();
  try {
    const raw = window.localStorage.getItem(SECRETS_STORAGE_KEY);
    if (!raw) return defaults;
    const parsed = JSON.parse(raw) as Partial<StudioSecrets>;
    const repoSource =
      parsed.targetRepo ||
      (parsed.githubOwner && parsed.githubRepo
        ? `${parsed.githubOwner}/${parsed.githubRepo}`
        : DEFAULT_TARGET_REPO);
    const { owner, repo, normalized } = parseTargetRepo(repoSource);

    return {
      ...defaults,
      ...parsed,
      geminiModel: parsed.geminiModel?.trim() || DEFAULT_2026_MODELS.gemini,
      geminiLiveModel: parsed.geminiLiveModel?.trim() || DEFAULT_2026_MODELS.geminiLive,
      geminiTtsModel: parsed.geminiTtsModel?.trim() || DEFAULT_2026_MODELS.geminiTts,
      nvidiaModel: parsed.nvidiaModel?.trim() || DEFAULT_2026_MODELS.nvidia,
      groqModel: parsed.groqModel?.trim() || DEFAULT_2026_MODELS.groq,
      openRouterModel: parsed.openRouterModel?.trim() || DEFAULT_2026_MODELS.openRouter,
      cohereModel: parsed.cohereModel?.trim() || DEFAULT_2026_MODELS.cohere,
      githubOwner: owner,
      githubRepo: repo,
      targetRepo: normalized,
      assetVaultUrl: parsed.assetVaultUrl?.trim() || DEFAULT_ASSET_VAULT_URL,
    };
  } catch {
    return defaults;
  }
}

export function saveSecrets(secrets: StudioSecrets): StudioSecrets {
  const defaults = createDefaultSecrets();
  const repoSource =
    secrets.targetRepo ||
    (secrets.githubOwner && secrets.githubRepo
      ? `${secrets.githubOwner}/${secrets.githubRepo}`
      : DEFAULT_TARGET_REPO);
  const { owner, repo, normalized } = parseTargetRepo(repoSource);

  const sanitized: StudioSecrets = {
    ...defaults,
    ...secrets,
    geminiApiKey: secrets.geminiApiKey.trim(),
    geminiModel: secrets.geminiModel?.trim() || DEFAULT_2026_MODELS.gemini,
    geminiLiveModel: secrets.geminiLiveModel?.trim() || DEFAULT_2026_MODELS.geminiLive,
    geminiTtsModel: secrets.geminiTtsModel?.trim() || DEFAULT_2026_MODELS.geminiTts,
    nvidiaApiKey: secrets.nvidiaApiKey?.trim() ?? '',
    nvidiaModel: secrets.nvidiaModel?.trim() || DEFAULT_2026_MODELS.nvidia,
    groqApiKey: secrets.groqApiKey?.trim() ?? '',
    groqModel: secrets.groqModel?.trim() || DEFAULT_2026_MODELS.groq,
    openRouterApiKey: secrets.openRouterApiKey?.trim() ?? '',
    openRouterModel: secrets.openRouterModel?.trim() || DEFAULT_2026_MODELS.openRouter,
    cohereApiKey: secrets.cohereApiKey?.trim() ?? '',
    cohereModel: secrets.cohereModel?.trim() || DEFAULT_2026_MODELS.cohere,
    githubToken: secrets.githubToken.trim(),
    githubOwner: owner,
    githubRepo: repo,
    targetRepo: normalized,
    assetVaultUrl: secrets.assetVaultUrl?.trim() || DEFAULT_ASSET_VAULT_URL,
    studioSupabaseUrl: secrets.studioSupabaseUrl?.trim() ?? '',
    studioSupabaseAnonKey: secrets.studioSupabaseAnonKey?.trim() ?? '',
    appsSupabaseUrl: secrets.appsSupabaseUrl?.trim() ?? '',
    appsSupabaseAnonKey: secrets.appsSupabaseAnonKey?.trim() ?? '',
  };

  try {
    window.localStorage.setItem(SECRETS_STORAGE_KEY, JSON.stringify(sanitized));
  } catch {
    // Ignore storage quota errors gracefully
  }

  return sanitized;
}

export interface VaultVerifyResult {
  ok: boolean;
  count: number;
  error?: string;
}

function countCatalogItems(data: unknown): number {
  if (Array.isArray(data)) {
    return data.length;
  }
  if (data && typeof data === 'object') {
    const obj = data as Record<string, unknown>;
    if (Array.isArray(obj.assets)) return obj.assets.length;
    if (Array.isArray(obj.items)) return obj.items.length;
    if (Array.isArray(obj.catalog)) return obj.catalog.length;
    if (Array.isArray(obj.models)) return obj.models.length;

    let total = 0;
    for (const value of Object.values(obj)) {
      if (Array.isArray(value)) {
        total += value.length;
      } else if (value && typeof value === 'object') {
        for (const nested of Object.values(value as Record<string, unknown>)) {
          if (Array.isArray(nested)) {
            total += nested.length;
          }
        }
      }
    }
    return total;
  }
  return 0;
}

export async function verifyAssetVault(url: string): Promise<VaultVerifyResult> {
  const trimmed = url.trim();
  if (!trimmed) {
    return { ok: false, count: 0, error: 'Enter a catalog.json URL first.' };
  }

  let parsedUrl: URL;
  try {
    parsedUrl = new URL(trimmed);
  } catch {
    return { ok: false, count: 0, error: 'Invalid URL format.' };
  }

  if (parsedUrl.protocol !== 'https:' && parsedUrl.protocol !== 'http:') {
    return { ok: false, count: 0, error: 'URL must start with https:// or http://' };
  }

  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), 5000);

  try {
    const response = await fetch(parsedUrl.toString(), {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    });

    if (!response.ok) {
      return {
        ok: false,
        count: 0,
        error: `Vault returned HTTP ${response.status}`,
      };
    }

    const json: unknown = await response.json();
    const count = countCatalogItems(json);
    return { ok: true, count };
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      return { ok: false, count: 0, error: 'Timed out after 5 seconds.' };
    }
    if (err instanceof Error) {
      return { ok: false, count: 0, error: err.message || 'Network verification failed.' };
    }
    return { ok: false, count: 0, error: 'Unable to reach Asset Vault.' };
  } finally {
    window.clearTimeout(timeoutId);
  }
}

export function countConfiguredKeys(secrets: StudioSecrets): number {
  const candidates = [
    secrets.geminiApiKey,
    secrets.nvidiaApiKey,
    secrets.groqApiKey,
    secrets.openRouterApiKey,
    secrets.cohereApiKey,
    secrets.githubToken,
  ];
  return candidates.filter((v) => Boolean(v && v.trim().length > 0)).length;
}

export type ApiTestProviderId =
  | 'gemini'
  | 'nvidia'
  | 'groq'
  | 'openRouter'
  | 'cohere';

export interface ApiKeyTestResult {
  provider: ApiTestProviderId;
  label: string;
  configured: boolean;
  ok: boolean;
  statusLabel: string;
  modelCount: number;
  latencyMs: number;
}

export type ApiKeysTestMap = Record<ApiTestProviderId, ApiKeyTestResult>;

const API_TEST_TIMEOUT_MS = 5000;

function extractModelCount(json: unknown): number {
  if (!json || typeof json !== 'object') return 0;
  const obj = json as Record<string, unknown>;
  if (Array.isArray(obj.models)) return obj.models.length;
  if (Array.isArray(obj.data)) return obj.data.length;
  return 0;
}

function formatHttpStatusLabel(status: number): string {
  if (status === 401 || status === 403) return `Invalid (${status})`;
  if (status === 429) return 'Rate Limit (429)';
  if (status === 503) return 'Overloaded (503)';
  return `HTTP ${status}`;
}

async function probeApiEndpoint(
  provider: ApiTestProviderId,
  label: string,
  apiKey: string | undefined,
  buildRequest: (key: string) => { url: string; headers?: Record<string, string> }
): Promise<ApiKeyTestResult> {
  const key = apiKey?.trim() ?? '';
  if (!key) {
    return {
      provider,
      label,
      configured: false,
      ok: false,
      statusLabel: 'Not Set',
      modelCount: 0,
      latencyMs: 0,
    };
  }

  const startedAt = Date.now();
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), API_TEST_TIMEOUT_MS);

  try {
    const req = buildRequest(key);
    const response = await fetch(req.url, {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        ...(req.headers ?? {}),
      },
      signal: controller.signal,
    });
    const latencyMs = Date.now() - startedAt;

    if (!response.ok) {
      return {
        provider,
        label,
        configured: true,
        ok: false,
        statusLabel: formatHttpStatusLabel(response.status),
        modelCount: 0,
        latencyMs,
      };
    }

    let modelCount = 0;
    try {
      const json: unknown = await response.json();
      modelCount = extractModelCount(json);
    } catch {
      modelCount = 0;
    }

    return {
      provider,
      label,
      configured: true,
      ok: true,
      statusLabel: 'Active ✓',
      modelCount,
      latencyMs,
    };
  } catch (err) {
    const latencyMs = Date.now() - startedAt;
    const isTimeout = err instanceof DOMException && err.name === 'AbortError';
    return {
      provider,
      label,
      configured: true,
      ok: false,
      statusLabel: isTimeout ? '5s Timeout' : 'Network / CORS',
      modelCount: 0,
      latencyMs,
    };
  } finally {
    window.clearTimeout(timeoutId);
  }
}

export async function testConfiguredApiKeys(
  secrets: StudioSecrets
): Promise<ApiKeysTestMap> {
  const [gemini, nvidia, groq, openRouter, cohere] = await Promise.all([
    probeApiEndpoint('gemini', 'Gemini', secrets.geminiApiKey, (key) => ({
      url: `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(key)}`,
    })),
    probeApiEndpoint('nvidia', 'NVIDIA NIM', secrets.nvidiaApiKey, (key) => ({
      url: 'https://integrate.api.nvidia.com/v1/models',
      headers: { Authorization: `Bearer ${key}` },
    })),
    probeApiEndpoint('groq', 'Groq', secrets.groqApiKey, (key) => ({
      url: 'https://api.groq.com/openai/v1/models',
      headers: { Authorization: `Bearer ${key}` },
    })),
    probeApiEndpoint('openRouter', 'OpenRouter', secrets.openRouterApiKey, (key) => ({
      url: 'https://openrouter.ai/api/v1/models',
      headers: { Authorization: `Bearer ${key}` },
    })),
    probeApiEndpoint('cohere', 'Cohere', secrets.cohereApiKey, (key) => ({
      url: 'https://api.cohere.com/v1/models',
      headers: { Authorization: `Bearer ${key}` },
    })),
  ]);

  return {
    gemini,
    nvidia,
    groq,
    openRouter,
    cohere,
  };
}

