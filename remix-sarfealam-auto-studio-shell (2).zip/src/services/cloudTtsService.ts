import { studioBus } from './eventBus';
import { DEFAULT_2026_MODELS } from './secretsService';
import { isProviderOnCooldown, markProviderCooldown } from './aiRouter';
import type { Language, VoicePersona } from '../types/studio';

export interface SpeakStudioReplyOptions {
  geminiKey?: string;
  ttsModel?: string;
  voicePersona: VoicePersona;
  voiceSpeed: number;
  language: Language;
}

export type TtsEngineUsed = 'cloud-tts' | 'speech-synthesis' | 'none';

const CLOUD_TTS_TIMEOUT_MS = 8000;
const OUTPUT_SAMPLE_RATE = 24000;

let activeSessionToken = 0;
let activeAbortController: AbortController | null = null;
let ttsAudioCtx: AudioContext | null = null;
let activeSourceNode: AudioBufferSourceNode | null = null;
let speakingFlag = false;
let currentPersona: VoicePersona = 'Aoede';
let currentSpeed = 1.0;

function sanitizeForSpeech(raw: string): string {
  return raw
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/[`*_#>~]/g, '')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 900);
}

function normalizeTtsModel(model?: string): string {
  const cleaned = (model || DEFAULT_2026_MODELS.geminiTts)
    .trim()
    .replace(/^models\//i, '');
  if (/gemini-(1\.5|2\.0|2\.5)/i.test(cleaned)) {
    return DEFAULT_2026_MODELS.geminiTts;
  }
  return cleaned || DEFAULT_2026_MODELS.geminiTts;
}

function base64ToUint8Array(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

function pcm16BytesToFloat32(bytes: Uint8Array): Float32Array {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const sampleCount = Math.floor(bytes.byteLength / 2);
  const float32 = new Float32Array(sampleCount);
  for (let i = 0; i < sampleCount; i++) {
    float32[i] = view.getInt16(i * 2, true) / 32768;
  }
  return float32;
}

function emitTtsPhase(phase: 'speaking' | 'idle'): void {
  speakingFlag = phase === 'speaking';
  studioBus.emit('voice:state', {
    active: false,
    phase,
    persona: currentPersona,
    speed: currentSpeed,
    listening: false,
    speaking: phase === 'speaking',
  });
}

function cleanupAudioOnly(): void {
  if (activeAbortController) {
    try {
      activeAbortController.abort();
    } catch {
      // ignore
    }
    activeAbortController = null;
  }

  if (activeSourceNode) {
    try {
      activeSourceNode.onended = null;
      activeSourceNode.stop();
      activeSourceNode.disconnect();
    } catch {
      // ignore
    }
    activeSourceNode = null;
  }

  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      // ignore
    }
  }
}

export function isStudioSpeaking(): boolean {
  return speakingFlag;
}

export function setCloudTtsSpeed(speed: number): void {
  const clamped = Math.max(1.0, Math.min(1.5, speed));
  currentSpeed = clamped;
  if (activeSourceNode) {
    try {
      activeSourceNode.playbackRate.value = clamped;
    } catch {
      // ignore
    }
  }
}

export function stopStudioSpeech(): void {
  activeSessionToken += 1;
  cleanupAudioOnly();
  if (speakingFlag) {
    emitTtsPhase('idle');
  } else {
    studioBus.emit('voice:state', {
      active: false,
      phase: 'idle',
      listening: false,
      speaking: false,
    });
  }
}

async function playAudioBase64(
  base64Data: string,
  mimeType: string | undefined,
  speed: number,
  token: number
): Promise<boolean> {
  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext })
      .webkitAudioContext;

  if (!ttsAudioCtx || ttsAudioCtx.state === 'closed') {
    ttsAudioCtx = new AudioCtx();
  }
  if (ttsAudioCtx.state === 'suspended') {
    await ttsAudioCtx.resume();
  }

  if (token !== activeSessionToken) return false;

  const bytes = base64ToUint8Array(base64Data);
  if (bytes.byteLength < 2) return false;

  let audioBuffer: AudioBuffer;
  const lowerMime = (mimeType || '').toLowerCase();

  if (
    lowerMime.includes('wav') ||
    lowerMime.includes('mpeg') ||
    lowerMime.includes('mp3') ||
    lowerMime.includes('ogg') ||
    lowerMime.includes('webm')
  ) {
    const arrayBuffer = new ArrayBuffer(bytes.byteLength);
    new Uint8Array(arrayBuffer).set(bytes);
    audioBuffer = await ttsAudioCtx.decodeAudioData(arrayBuffer);
  } else {
    const floatSamples = pcm16BytesToFloat32(bytes);
    if (floatSamples.length === 0) return false;
    audioBuffer = ttsAudioCtx.createBuffer(
      1,
      floatSamples.length,
      OUTPUT_SAMPLE_RATE
    );
    audioBuffer.getChannelData(0).set(floatSamples);
  }

  if (token !== activeSessionToken) return false;

  return new Promise<boolean>((resolve) => {
    if (!ttsAudioCtx || token !== activeSessionToken) {
      resolve(false);
      return;
    }

    const source = ttsAudioCtx.createBufferSource();
    source.buffer = audioBuffer;
    source.playbackRate.value = speed;
    source.connect(ttsAudioCtx.destination);
    activeSourceNode = source;

    emitTtsPhase('speaking');

    source.onended = () => {
      try {
        source.disconnect();
      } catch {
        // ignore
      }
      if (activeSourceNode === source) {
        activeSourceNode = null;
      }
      if (token === activeSessionToken) {
        emitTtsPhase('idle');
      }
      resolve(true);
    };

    source.start(0);
  });
}

function speakWithBrowserSynthesis(
  text: string,
  language: Language,
  speed: number,
  token: number
): Promise<boolean> {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return Promise.resolve(false);
  }

  return new Promise<boolean>((resolve) => {
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      const targetLang = language === 'hi' ? 'hi-IN' : 'en-US';
      utterance.lang = targetLang;
      utterance.rate = speed;

      const voices = window.speechSynthesis.getVoices();
      const matchedVoice =
        voices.find((v) => v.lang.toLowerCase() === targetLang.toLowerCase()) ??
        voices.find((v) =>
          v.lang.toLowerCase().startsWith(language === 'hi' ? 'hi' : 'en')
        );
      if (matchedVoice) {
        utterance.voice = matchedVoice;
      }

      utterance.onstart = () => {
        if (token === activeSessionToken) {
          emitTtsPhase('speaking');
        }
      };

      utterance.onend = () => {
        if (token === activeSessionToken) {
          emitTtsPhase('idle');
        }
        resolve(true);
      };

      utterance.onerror = () => {
        if (token === activeSessionToken) {
          emitTtsPhase('idle');
        }
        resolve(false);
      };

      emitTtsPhase('speaking');
      window.speechSynthesis.speak(utterance);
    } catch {
      if (token === activeSessionToken) {
        emitTtsPhase('idle');
      }
      resolve(false);
    }
  });
}

export async function speakStudioReply(
  text: string,
  options: SpeakStudioReplyOptions
): Promise<TtsEngineUsed> {
  const cleaned = sanitizeForSpeech(text);
  if (!cleaned) return 'none';

  const token = ++activeSessionToken;
  cleanupAudioOnly();

  const speed = Math.max(1.0, Math.min(1.5, options.voiceSpeed || 1.0));
  currentPersona = options.voicePersona;
  currentSpeed = speed;

  const apiKey = options.geminiKey?.trim() ?? '';

  if (apiKey && !isProviderOnCooldown('gemini')) {
    const model = normalizeTtsModel(options.ttsModel);
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
      model
    )}:generateContent?key=${encodeURIComponent(apiKey)}`;

    const controller = new AbortController();
    activeAbortController = controller;
    const timeoutId = window.setTimeout(
      () => controller.abort(),
      CLOUD_TTS_TIMEOUT_MS
    );

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          contents: [
            {
              parts: [{ text: cleaned }],
            },
          ],
          generationConfig: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName: options.voicePersona,
                },
              },
            },
          },
        }),
      });

      if (response.status === 503 || response.status === 429) {
        markProviderCooldown('gemini');
      } else if (response.ok && token === activeSessionToken) {
        const data = (await response.json()) as {
          candidates?: {
            content?: {
              parts?: {
                inlineData?: {
                  mimeType?: string;
                  data?: string;
                };
              }[];
            };
          }[];
        };

        const audioPart = data.candidates?.[0]?.content?.parts?.find(
          (p) => typeof p.inlineData?.data === 'string' && p.inlineData.data.length > 0
        );

        if (audioPart?.inlineData?.data && token === activeSessionToken) {
          const played = await playAudioBase64(
            audioPart.inlineData.data,
            audioPart.inlineData.mimeType,
            speed,
            token
          );
          if (played) {
            return 'cloud-tts';
          }
        }
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        markProviderCooldown('gemini');
      }
      // Gracefully fall through to browser speechSynthesis
    } finally {
      window.clearTimeout(timeoutId);
      if (activeAbortController === controller) {
        activeAbortController = null;
      }
    }
  }

  if (token !== activeSessionToken) return 'none';

  const fallbackPlayed = await speakWithBrowserSynthesis(
    cleaned,
    options.language,
    speed,
    token
  );
  return fallbackPlayed ? 'speech-synthesis' : 'none';
}
