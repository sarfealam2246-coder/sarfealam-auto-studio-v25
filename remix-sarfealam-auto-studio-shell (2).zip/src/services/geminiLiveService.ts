import { studioBus } from './eventBus';
import { DEFAULT_2026_MODELS } from './secretsService';
import { buildMemoryContext } from './memoryService';
import { sanitizeUIActions, type UIAction } from './uiActuators';
import type {
  Language,
  UserMemoryRule,
  VirtualFile,
  VoicePersona,
  VoicePhase,
} from '../types/studio';

export interface LiveTranscriptEvent {
  role: 'user' | 'jarvis';
  text: string;
  isFinal: boolean;
  modelLabel: string;
}

export interface GeminiLiveConnectOptions {
  apiKey: string;
  preferredModel?: string;
  voicePersona: VoicePersona;
  voiceSpeed: number;
  language: Language;
  files: VirtualFile[];
  memoryRules: UserMemoryRule[];
  onTranscript: (evt: LiveTranscriptEvent) => void;
  onToolActions: (actions: UIAction[]) => string[];
  onError: (message: string) => void;
}

const LIVE_WS_BASE =
  'wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent';

const FALLBACK_LIVE_MODELS = [
  'models/gemini-3.8-live',
  'models/gemini-3.1-flash-live-preview',
];

const TARGET_INPUT_SAMPLE_RATE = 16000;
const OUTPUT_SAMPLE_RATE = 24000;
const BARGE_IN_RMS_THRESHOLD = 0.045;
const BARGE_IN_FRAMES_REQUIRED = 2;

const LIVE_TOOL_DECLARATIONS = [
  {
    name: 'open_panel',
    description:
      'Open or close a Sarfealam Auto-Studio drawer panel (secrets, code, vault, admin, camera, or none to close).',
    parameters: {
      type: 'OBJECT',
      properties: {
        panel: {
          type: 'STRING',
          enum: ['none', 'secrets', 'code', 'vault', 'admin', 'camera'],
        },
      },
      required: ['panel'],
    },
  },
  {
    name: 'set_display_mode',
    description: 'Change Display A viewport layout mode.',
    parameters: {
      type: 'OBJECT',
      properties: {
        mode: {
          type: 'STRING',
          enum: ['expanded', 'floating', 'collapsed'],
        },
      },
      required: ['mode'],
    },
  },
  {
    name: 'set_language',
    description: 'Switch studio interface and response language between English (en) and Hindi (hi).',
    parameters: {
      type: 'OBJECT',
      properties: {
        language: {
          type: 'STRING',
          enum: ['en', 'hi'],
        },
      },
      required: ['language'],
    },
  },
  {
    name: 'set_mode',
    description: 'Switch studio mode between JARVIS autonomous and Manual mode.',
    parameters: {
      type: 'OBJECT',
      properties: {
        mode: {
          type: 'STRING',
          enum: ['jarvis', 'manual'],
        },
      },
      required: ['mode'],
    },
  },
  {
    name: 'set_engine',
    description: 'Set the target build engine for the active studio project.',
    parameters: {
      type: 'OBJECT',
      properties: {
        engine: {
          type: 'STRING',
          enum: ['auto', 'capacitor', 'godot4', 'flutter', 'unity'],
        },
      },
      required: ['engine'],
    },
  },
  {
    name: 'select_file',
    description: 'Select and open a virtual file path in the Code Editor.',
    parameters: {
      type: 'OBJECT',
      properties: {
        path: {
          type: 'STRING',
          description: 'Exact virtual file path such as src/App.tsx or assets/manifest.json',
        },
      },
      required: ['path'],
    },
  },
  {
    name: 'set_stage',
    description: 'Jump Display A progress indicator to stage 1 through 5.',
    parameters: {
      type: 'OBJECT',
      properties: {
        stage: {
          type: 'INTEGER',
          description: 'Stage number from 1 (Shell) to 5 (Package).',
        },
      },
      required: ['stage'],
    },
  },
  {
    name: 'save_memory',
    description:
      'Save a permanent user preference or rule into studio memory when the user says remember/always/never/yaad rakhna.',
    parameters: {
      type: 'OBJECT',
      properties: {
        rule: {
          type: 'STRING',
          description: 'Concise permanent rule to remember.',
        },
      },
      required: ['rule'],
    },
  },
  {
    name: 'set_paused',
    description:
      'Pause or resume the studio 5-stage pipeline cooperatively while keeping voice live and preserving all files and state.',
    parameters: {
      type: 'OBJECT',
      properties: {
        paused: {
          type: 'BOOLEAN',
          description: 'true to pause in Inspect Mode, false to resume from the held stage.',
        },
      },
      required: ['paused'],
    },
  },
  {
    name: 'search_assets',
    description:
      'Open the Asset Vault and run a department-scoped AssetHunter search across 3D vault departments, Iconify icons, or Wikimedia photos.',
    parameters: {
      type: 'OBJECT',
      properties: {
        query: {
          type: 'STRING',
          description: 'Short search keywords such as "truck", "sunset sky", or "home icon".',
        },
        categories: {
          type: 'ARRAY',
          description: 'Optional list of target AssetCategory departments to scope the search.',
          items: {
            type: 'STRING',
            enum: [
              'vehicles',
              'characters',
              'weapons_gear',
              'village_world',
              'textures_pbr',
              'hdri_sky',
              'audio_sfx',
              'app_audio',
              'wikimedia_photos',
              'iconify_icons',
            ],
          },
        },
      },
      required: ['query'],
    },
  },
  {
    name: 'select_asset',
    description:
      'Keep or reject a hunted candidate asset by 1-based index ("1", "first", "2", "second", "last", "all") or by name, syncing kept assets into assets/manifest.json.',
    parameters: {
      type: 'OBJECT',
      properties: {
        target: {
          type: 'STRING',
          description: 'Asset target such as "1", "first", "2", "second", "all", or an asset name.',
        },
        decision: {
          type: 'STRING',
          enum: ['keep', 'reject'],
          description: '"keep" to add to selectedAssets, "reject" to dismiss/remove.',
        },
      },
      required: ['target', 'decision'],
    },
  },
  {
    name: 'clone_repo',
    description:
      'Clone a GitHub repository (owner/repo or https://github.com/owner/repo) into the Studio virtual files workspace for editing and live preview.',
    parameters: {
      type: 'OBJECT',
      properties: {
        repoUrl: {
          type: 'STRING',
          description: 'GitHub repository slug (owner/repo) or full URL (https://github.com/owner/repo).',
        },
      },
      required: ['repoUrl'],
    },
  },
  {
    name: 'build_3d_game',
    description:
      'Generate and launch a playable Pro 3D Three.js mobile driving and walking game in Display A with touch steering wheel, R/N/1/2/3 gearbox, gas/brake pedals, compound gate, AI traffic, and selected Vault 3D assets.',
    parameters: {
      type: 'OBJECT',
      properties: {
        theme: {
          type: 'STRING',
          description:
            'Optional vehicle/world theme such as "Village Cargo Truck", "Village 3D Car Drive", "Off-Road Village SUV", or "Street Sports 3D Drive".',
        },
      },
    },
  },
  {
    name: 'build_commercial_app',
    description:
      'Generate and launch a zero-shortcut 360px commercial mobile app (fintech UPI wallet, fantasy sports contest, ecommerce marketplace, or booking app) inside Display A with live Iconify/Wikimedia assets and Apps-only Supabase isolation.',
    parameters: {
      type: 'OBJECT',
      properties: {
        category: {
          type: 'STRING',
          enum: ['fintech', 'fantasy', 'ecommerce', 'booking'],
          description: 'Commercial app category.',
        },
        prompt: {
          type: 'STRING',
          description: 'Optional user description or custom requirements for the commercial app.',
        },
      },
    },
  },
  {
    name: 'create_broadcast',
    description:
      'Script and launch a 2-voice (Host A Aoede + Host B Charon) 9:16 animated canvas broadcast audio/short video inside Display A with optional WebM recording.',
    parameters: {
      type: 'OBJECT',
      properties: {
        topic: {
          type: 'STRING',
          description: 'Topic for the 2-host short video broadcast.',
        },
      },
      required: ['topic'],
    },
  },
  {
    name: 'spawn_sub_bot',
    description:
      'Spawn a focused specialist helper sub-bot (such as QA Reviewer, Physics Tuner, UI Polish, or API Architect) to inspect the active workspace and post concise findings.',
    parameters: {
      type: 'OBJECT',
      properties: {
        role: {
          type: 'STRING',
          description: 'Specialist role for the helper sub-bot (e.g. QA Reviewer, Physics Tuner, UI Polish).',
        },
        task: {
          type: 'STRING',
          description: 'Focused task for the helper sub-bot to execute.',
        },
      },
      required: ['role', 'task'],
    },
  },
  {
    name: 'fetch_any_api',
    description:
      'Call any public http/https REST or JSON API endpoint with a 5-second timeout and save it as a reusable Dynamic Skill in localStorage and Studio Supabase dynamic_skills.',
    parameters: {
      type: 'OBJECT',
      properties: {
        name: {
          type: 'STRING',
          description: 'Short readable name for the API skill (e.g. GitHub Zen, Weather API).',
        },
        url: {
          type: 'STRING',
          description: 'Full http:// or https:// API endpoint URL to fetch.',
        },
      },
      required: ['name', 'url'],
    },
  },
  {
    name: 'test_apis',
    description:
      'Run live parallel 5-second health checks on all configured AI API keys (Gemini, NVIDIA NIM, Groq, OpenRouter, Cohere) and post a status summary in CommandCenter. Do NOT open Secrets or spawn a Sub-Bot when testing API keys.',
    parameters: {
      type: 'OBJECT',
      properties: {},
    },
  },
];

const WORKLET_PROCESSOR_CODE = `
class SarfealamPcmCaptureProcessor extends AudioWorkletProcessor {
  process(inputs) {
    const input = inputs[0];
    if (input && input[0] && input[0].length > 0) {
      this.port.postMessage(new Float32Array(input[0]));
    }
    return true;
  }
}
registerProcessor('sarfealam-pcm-capture', SarfealamPcmCaptureProcessor);
`;

function normalizeModelResource(model?: string): string {
  const raw = (model || DEFAULT_2026_MODELS.geminiLive).trim();
  const stripped = raw.replace(/^models\//i, '');
  // Guard strictly against legacy 1.5 / 2.0 models
  if (/gemini-(1\.5|2\.0)/i.test(stripped)) {
    return 'models/gemini-3.8-live';
  }
  return `models/${stripped}`;
}

function buildCandidateModels(preferredModel?: string): string[] {
  const candidates: string[] = [];
  const primary = normalizeModelResource(preferredModel);
  candidates.push(primary);
  for (const fallback of FALLBACK_LIVE_MODELS) {
    if (!candidates.includes(fallback)) {
      candidates.push(fallback);
    }
  }
  return candidates;
}

function shortModelName(modelResource: string): string {
  return modelResource.replace(/^models\//i, '');
}

function buildLiveSystemInstruction(options: GeminiLiveConnectOptions): string {
  const fileList = options.files.map((f) => f.path).join(', ') || 'none';
  const langLine =
    options.language === 'hi'
      ? 'Speak and respond naturally in Hindi / Hinglish.'
      : 'Speak and respond in crisp, friendly, concise English.';
  const memoryBlock = buildMemoryContext(options.memoryRules);

  return [
    'You are Sarfealam Auto-Studio JARVIS running in real-time full-duplex voice mode.',
    langLine,
    "The user uses mobile Hindi/Hinglish voice-to-text which often transcribes English tech words phonetically or brokenly (e.g., 'इन मीडिया/in media' = NVIDIA, 'ग्रो/ग्रोक' = Groq, 'सिगरेट' = Secrets, 'एपी की/पीआई' = API Key, 'वॉल्ट/बोल्ट' = Vault, 'अमल' = YAML, 'कोड खोलो' = open code). Always infer the user's real technical intent from conversation context instead of taking misheard words literally.",
    'IMPORTANT GUARD: When the user asks to check, test, or verify API keys or providers (Gemini, NVIDIA, Groq, OpenRouter, Cohere), call test_apis ONLY — do NOT auto-open Secrets and do NOT auto-spawn a Sub-Bot.',
    `Available virtual files: [${fileList}].`,
    ...(memoryBlock ? [memoryBlock] : []),
    'Whenever the user asks to open/close panels, switch display modes, change language, switch JARVIS/Manual mode, change engine, jump build stages, open a file, save a permanent memory rule, pause/resume the pipeline ("pause", "ruko", "hold", "resume", "continue", "aage badho"), hunt/find/search assets/icons/photos ("find car assets", "truck dhoondo", "search icons"), keep/reject hunted assets ("keep first", "keep 1", "pehle wala rakho", "reject second", "dusra hatao", "keep all"), clone a GitHub repository ("clone owner/repo"), build/launch a 3D game ("build 3d game", "3d car game", "truck game banao", "3d game banao"), build a commercial mobile app ("commercial app banao", "build fintech app", "dream11 app banao", "shopping app banao"), create a 2-voice broadcast video ("broadcast video banao", "short video banao", "create broadcast"), spawn a helper sub-bot ("spawn qa bot", "sub bot physics tuner"), fetch/save a dynamic external API skill ("fetch api https://..."), or test/check API keys ("test apis", "api check", "nvidia check", "check keys"), invoke the corresponding studio tool function immediately and confirm concisely in speech.',
  ].join('\n');
}

function downsampleTo16kPcm16(
  input: Float32Array,
  inputSampleRate: number
): Int16Array {
  if (inputSampleRate === TARGET_INPUT_SAMPLE_RATE) {
    const pcm = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const clamped = Math.max(-1, Math.min(1, input[i]));
      pcm[i] = clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff;
    }
    return pcm;
  }

  const ratio = inputSampleRate / TARGET_INPUT_SAMPLE_RATE;
  const outputLength = Math.max(1, Math.floor(input.length / ratio));
  const pcm = new Int16Array(outputLength);

  for (let i = 0; i < outputLength; i++) {
    const srcIndex = i * ratio;
    const idx0 = Math.floor(srcIndex);
    const idx1 = Math.min(idx0 + 1, input.length - 1);
    const frac = srcIndex - idx0;
    const sample = input[idx0] + (input[idx1] - input[idx0]) * frac;
    const clamped = Math.max(-1, Math.min(1, sample));
    pcm[i] = clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff;
  }

  return pcm;
}

function int16ToBase64(pcm: Int16Array): string {
  const bytes = new Uint8Array(pcm.buffer, pcm.byteOffset, pcm.byteLength);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const slice = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...slice);
  }
  return btoa(binary);
}

function base64Pcm16ToFloat32(base64: string): Float32Array {
  const binary = atob(base64);
  const byteLen = binary.length;
  const bytes = new Uint8Array(byteLen);
  for (let i = 0; i < byteLen; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  const view = new DataView(bytes.buffer);
  const sampleCount = Math.floor(byteLen / 2);
  const float32 = new Float32Array(sampleCount);
  for (let i = 0; i < sampleCount; i++) {
    float32[i] = view.getInt16(i * 2, true) / 32768;
  }
  return float32;
}

function computeRms(samples: Float32Array): number {
  let sum = 0;
  for (let i = 0; i < samples.length; i++) {
    sum += samples[i] * samples[i];
  }
  return Math.sqrt(sum / Math.max(1, samples.length));
}

function mapToolCallToRawAction(
  name: string,
  args: Record<string, unknown> | undefined
): Record<string, unknown> | null {
  const safeArgs = args ?? {};
  switch (name) {
    case 'open_panel':
      return { type: 'open_panel', panel: safeArgs.panel };
    case 'set_display_mode':
      return { type: 'set_display_mode', mode: safeArgs.mode };
    case 'set_language':
      return { type: 'set_language', language: safeArgs.language };
    case 'set_mode':
      return { type: 'set_mode', mode: safeArgs.mode };
    case 'set_engine':
      return { type: 'set_engine', engine: safeArgs.engine };
    case 'select_file':
      return { type: 'select_file', path: safeArgs.path };
    case 'set_stage':
      return { type: 'set_stage', stage: safeArgs.stage };
    case 'save_memory':
      return { type: 'save_memory', rule: safeArgs.rule };
    case 'set_paused':
      return { type: 'set_paused', paused: safeArgs.paused };
    case 'search_assets':
      return {
        type: 'search_assets',
        query: safeArgs.query,
        categories: safeArgs.categories,
      };
    case 'select_asset':
      return {
        type: 'select_asset',
        target: safeArgs.target,
        decision: safeArgs.decision,
      };
    case 'clone_repo':
      return {
        type: 'clone_repo',
        repoUrl: safeArgs.repoUrl,
      };
    case 'build_3d_game':
      return {
        type: 'build_3d_game',
        theme: safeArgs.theme,
      };
    case 'build_commercial_app':
      return {
        type: 'build_commercial_app',
        category: safeArgs.category,
        prompt: safeArgs.prompt,
      };
    case 'create_broadcast':
      return {
        type: 'create_broadcast',
        topic: safeArgs.topic,
      };
    case 'spawn_sub_bot':
      return {
        type: 'spawn_sub_bot',
        role: safeArgs.role,
        task: safeArgs.task,
      };
    case 'fetch_any_api':
      return {
        type: 'fetch_any_api',
        name: safeArgs.name,
        url: safeArgs.url,
      };
    case 'test_apis':
      return { type: 'test_apis' };
    default:
      return null;
  }
}

class GeminiLiveService {
  private ws: WebSocket | null = null;
  private mediaStream: MediaStream | null = null;
  private captureCtx: AudioContext | null = null;
  private playbackCtx: AudioContext | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private workletNode: AudioWorkletNode | null = null;
  private scriptProcessor: ScriptProcessorNode | null = null;
  private silentSink: GainNode | null = null;
  private workletBlobUrl: string | null = null;

  private activePlaybackSources = new Set<AudioBufferSourceNode>();
  private nextPlayTime = 0;
  private voiceSpeed = 1.0;
  private voicePersona: VoicePersona = 'Aoede';
  private activeModel: string | null = null;
  private phase: VoicePhase = 'idle';
  private connected = false;
  private intentionalDisconnect = false;
  private bargeInStreak = 0;

  private pendingInputTranscript = '';
  private pendingOutputTranscript = '';
  private currentOptions: GeminiLiveConnectOptions | null = null;
  private pcmBuffer: Float32Array[] = [];
  private pcmBufferSamples = 0;

  isConnected(): boolean {
    return this.connected;
  }

  getActiveModel(): string | null {
    return this.activeModel;
  }

  getPhase(): VoicePhase {
    return this.phase;
  }

  setSpeed(speed: number): void {
    const clamped = Math.max(1.0, Math.min(1.5, speed));
    this.voiceSpeed = clamped;
    for (const src of this.activePlaybackSources) {
      try {
        src.playbackRate.value = clamped;
      } catch {
        // Ignore if source already ended
      }
    }
    if (this.connected) {
      this.emitVoiceState(this.phase);
    }
  }

  private emitVoiceState(phase: VoicePhase, error?: string): void {
    this.phase = phase;
    studioBus.emit('voice:state', {
      active: this.connected,
      phase,
      model: this.activeModel ? shortModelName(this.activeModel) : null,
      persona: this.voicePersona,
      speed: this.voiceSpeed,
      listening: phase === 'listening',
      speaking: phase === 'speaking',
      error,
    });
  }

  private clearPlaybackQueue(): void {
    for (const src of this.activePlaybackSources) {
      try {
        src.onended = null;
        src.stop();
        src.disconnect();
      } catch {
        // Ignore already-stopped nodes
      }
    }
    this.activePlaybackSources.clear();
    this.nextPlayTime = 0;
  }

  private scheduleAudioChunk(base64Pcm: string): void {
    if (!this.playbackCtx || this.playbackCtx.state === 'closed') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.playbackCtx = new AudioCtx();
    }

    if (this.playbackCtx.state === 'suspended') {
      void this.playbackCtx.resume();
    }

    const floatSamples = base64Pcm16ToFloat32(base64Pcm);
    if (floatSamples.length === 0) return;

    const buffer = this.playbackCtx.createBuffer(
      1,
      floatSamples.length,
      OUTPUT_SAMPLE_RATE
    );
    buffer.getChannelData(0).set(floatSamples);

    const source = this.playbackCtx.createBufferSource();
    source.buffer = buffer;
    source.playbackRate.value = this.voiceSpeed;
    source.connect(this.playbackCtx.destination);

    const now = this.playbackCtx.currentTime;
    const startAt = Math.max(now + 0.015, this.nextPlayTime);
    const effectiveDuration = buffer.duration / this.voiceSpeed;
    this.nextPlayTime = startAt + effectiveDuration;

    this.activePlaybackSources.add(source);
    if (this.phase !== 'speaking') {
      this.emitVoiceState('speaking');
    }

    source.onended = () => {
      source.disconnect();
      this.activePlaybackSources.delete(source);
      if (this.activePlaybackSources.size === 0 && this.connected) {
        this.nextPlayTime = 0;
        this.emitVoiceState('listening');
      }
    };

    source.start(startAt);
  }

  private handleCapturedAudioFrame(samples: Float32Array, inputSampleRate: number): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    // Local instant barge-in detection during playback
    if (this.activePlaybackSources.size > 0) {
      const rms = computeRms(samples);
      if (rms >= BARGE_IN_RMS_THRESHOLD) {
        this.bargeInStreak += 1;
        if (this.bargeInStreak >= BARGE_IN_FRAMES_REQUIRED) {
          this.clearPlaybackQueue();
          this.bargeInStreak = 0;
          this.emitVoiceState('listening');
        }
      } else {
        this.bargeInStreak = 0;
      }
    } else {
      this.bargeInStreak = 0;
    }

    // Buffer small worklet frames (~128 samples) into ~100ms chunks before sending
    this.pcmBuffer.push(samples);
    this.pcmBufferSamples += samples.length;

    const minBatch = Math.floor(inputSampleRate * 0.08);
    if (this.pcmBufferSamples < minBatch) return;

    const merged = new Float32Array(this.pcmBufferSamples);
    let offset = 0;
    for (const chunk of this.pcmBuffer) {
      merged.set(chunk, offset);
      offset += chunk.length;
    }
    this.pcmBuffer = [];
    this.pcmBufferSamples = 0;

    const pcm16 = downsampleTo16kPcm16(merged, inputSampleRate);
    const base64 = int16ToBase64(pcm16);

    try {
      this.ws.send(
        JSON.stringify({
          realtimeInput: {
            mediaChunks: [
              {
                mimeType: 'audio/pcm;rate=16000',
                data: base64,
              },
            ],
          },
        })
      );
    } catch {
      // Ignore send errors if socket closed mid-frame
    }
  }

  private async startMicrophoneCapture(): Promise<void> {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error('Microphone access is unavailable in this browser/WebView.');
    }

    this.mediaStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        channelCount: 1,
      },
    });

    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.captureCtx = new AudioCtx();
    if (this.captureCtx.state === 'suspended') {
      await this.captureCtx.resume();
    }

    const sampleRate = this.captureCtx.sampleRate;
    this.sourceNode = this.captureCtx.createMediaStreamSource(this.mediaStream);
    this.silentSink = this.captureCtx.createGain();
    this.silentSink.gain.value = 0;
    this.silentSink.connect(this.captureCtx.destination);

    // Prefer AudioWorkletNode; fallback cleanly to ScriptProcessorNode
    if (this.captureCtx.audioWorklet) {
      try {
        const blob = new Blob([WORKLET_PROCESSOR_CODE], {
          type: 'application/javascript',
        });
        this.workletBlobUrl = URL.createObjectURL(blob);
        await this.captureCtx.audioWorklet.addModule(this.workletBlobUrl);
        this.workletNode = new AudioWorkletNode(
          this.captureCtx,
          'sarfealam-pcm-capture'
        );
        this.workletNode.port.onmessage = (event: MessageEvent<Float32Array>) => {
          if (event.data instanceof Float32Array) {
            this.handleCapturedAudioFrame(event.data, sampleRate);
          }
        };
        this.sourceNode.connect(this.workletNode);
        this.workletNode.connect(this.silentSink);
        return;
      } catch {
        // Fall through cleanly to ScriptProcessorNode
        if (this.workletBlobUrl) {
          URL.revokeObjectURL(this.workletBlobUrl);
          this.workletBlobUrl = null;
        }
      }
    }

    this.scriptProcessor = this.captureCtx.createScriptProcessor(4096, 1, 1);
    this.scriptProcessor.onaudioprocess = (event: AudioProcessingEvent) => {
      const channelData = event.inputBuffer.getChannelData(0);
      this.handleCapturedAudioFrame(new Float32Array(channelData), sampleRate);
    };
    this.sourceNode.connect(this.scriptProcessor);
    this.scriptProcessor.connect(this.silentSink);
  }

  private handleServerMessage(
    raw: unknown,
    modelResource: string,
    onSetupComplete: () => void
  ): void {
    if (!raw || typeof raw !== 'object') return;
    const msg = raw as Record<string, unknown>;
    const options = this.currentOptions;
    const modelLabel = `Gemini Live (${shortModelName(modelResource)})`;

    if ('setupComplete' in msg) {
      onSetupComplete();
      return;
    }

    // Handle Live Tool Calling
    if (msg.toolCall && typeof msg.toolCall === 'object') {
      const toolCall = msg.toolCall as {
        functionCalls?: {
          id?: string;
          name?: string;
          args?: Record<string, unknown>;
        }[];
      };
      const calls = Array.isArray(toolCall.functionCalls)
        ? toolCall.functionCalls
        : [];
      if (calls.length > 0 && options) {
        this.emitVoiceState('thinking');
        const rawActions = calls
          .map((c) => mapToolCallToRawAction(c.name ?? '', c.args))
          .filter((a): a is Record<string, unknown> => a !== null);
        const validActions = sanitizeUIActions(rawActions, options.files);
        const labels = options.onToolActions(validActions);

        const functionResponses = calls.map((call, idx) => ({
          id: call.id ?? `call-${idx}`,
          name: call.name ?? 'unknown',
          response: {
            result: {
              ok: true,
              executed: labels[idx] ?? 'applied',
            },
          },
        }));

        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
          this.ws.send(
            JSON.stringify({
              toolResponse: { functionResponses },
            })
          );
        }
      }
    }

    // Handle Server Content (Audio, Transcriptions, Barge-in Interrupted, Turn Complete)
    if (msg.serverContent && typeof msg.serverContent === 'object') {
      const sc = msg.serverContent as {
        interrupted?: boolean;
        turnComplete?: boolean;
        inputTranscription?: { text?: string };
        outputTranscription?: { text?: string };
        modelTurn?: {
          parts?: {
            text?: string;
            inlineData?: { mimeType?: string; data?: string };
          }[];
        };
      };

      if (sc.interrupted) {
        this.clearPlaybackQueue();
        this.pendingOutputTranscript = '';
        this.emitVoiceState('listening');
      }

      if (sc.inputTranscription?.text && options) {
        const piece = sc.inputTranscription.text;
        this.pendingInputTranscript += piece;
        if (this.phase === 'listening') {
          this.emitVoiceState('thinking');
        }
        options.onTranscript({
          role: 'user',
          text: this.pendingInputTranscript.trim(),
          isFinal: false,
          modelLabel,
        });
      }

      if (sc.outputTranscription?.text && options) {
        this.pendingOutputTranscript += sc.outputTranscription.text;
        options.onTranscript({
          role: 'jarvis',
          text: this.pendingOutputTranscript.trim(),
          isFinal: false,
          modelLabel,
        });
      }

      const parts = sc.modelTurn?.parts ?? [];
      for (const part of parts) {
        if (part.inlineData?.data) {
          this.scheduleAudioChunk(part.inlineData.data);
        } else if (part.text && !sc.outputTranscription?.text && options) {
          this.pendingOutputTranscript += part.text;
          options.onTranscript({
            role: 'jarvis',
            text: this.pendingOutputTranscript.trim(),
            isFinal: false,
            modelLabel,
          });
        }
      }

      if (sc.turnComplete && options) {
        if (this.pendingInputTranscript.trim()) {
          options.onTranscript({
            role: 'user',
            text: this.pendingInputTranscript.trim(),
            isFinal: true,
            modelLabel,
          });
          this.pendingInputTranscript = '';
        }
        if (this.pendingOutputTranscript.trim()) {
          options.onTranscript({
            role: 'jarvis',
            text: this.pendingOutputTranscript.trim(),
            isFinal: true,
            modelLabel,
          });
          this.pendingOutputTranscript = '';
        }
        if (this.activePlaybackSources.size === 0 && this.connected) {
          this.emitVoiceState('listening');
        }
      }
    }
  }

  private openSocketForModel(
    modelResource: string,
    options: GeminiLiveConnectOptions
  ): Promise<WebSocket> {
    return new Promise((resolve, reject) => {
      const wsUrl = `${LIVE_WS_BASE}?key=${encodeURIComponent(options.apiKey.trim())}`;
      const ws = new WebSocket(wsUrl);
      let settled = false;

      const timeoutId = window.setTimeout(() => {
        if (!settled) {
          settled = true;
          try {
            ws.close();
          } catch {
            // ignore
          }
          reject(new Error(`Timeout connecting to ${shortModelName(modelResource)}`));
        }
      }, 10000);

      ws.onopen = () => {
        const setupPayload = {
          setup: {
            model: modelResource,
            generationConfig: {
              responseModalities: ['AUDIO'],
              speechConfig: {
                voiceConfig: {
                  prebuiltVoiceConfig: {
                    voiceName: options.voicePersona,
                  },
                },
              },
            },
            inputAudioTranscription: {},
            outputAudioTranscription: {},
            systemInstruction: {
              parts: [{ text: buildLiveSystemInstruction(options) }],
            },
            tools: [{ functionDeclarations: LIVE_TOOL_DECLARATIONS }],
          },
        };
        ws.send(JSON.stringify(setupPayload));
      };

      ws.onmessage = async (event: MessageEvent) => {
        try {
          const textData =
            typeof event.data === 'string'
              ? event.data
              : event.data instanceof Blob
                ? await event.data.text()
                : '';
          if (!textData) return;
          const parsed: unknown = JSON.parse(textData);

          this.handleServerMessage(parsed, modelResource, () => {
            if (!settled) {
              settled = true;
              window.clearTimeout(timeoutId);
              resolve(ws);
            }
          });
        } catch {
          // Ignore malformed non-JSON frames
        }
      };

      ws.onerror = () => {
        if (!settled) {
          settled = true;
          window.clearTimeout(timeoutId);
          reject(new Error(`WebSocket error on ${shortModelName(modelResource)}`));
        }
      };

      ws.onclose = (closeEvent) => {
        if (!settled) {
          settled = true;
          window.clearTimeout(timeoutId);
          const reason = closeEvent.reason || `code ${closeEvent.code}`;
          reject(new Error(`${shortModelName(modelResource)} closed (${reason})`));
          return;
        }

        if (!this.intentionalDisconnect && this.ws === ws) {
          const reason = closeEvent.reason || `Disconnected (code ${closeEvent.code})`;
          this.cleanupResources();
          this.emitVoiceState('idle', reason);
          options.onError(reason);
        }
      };
    });
  }

  async connect(options: GeminiLiveConnectOptions): Promise<string> {
    this.disconnect();
    this.intentionalDisconnect = false;
    this.currentOptions = options;
    this.voicePersona = options.voicePersona;
    this.voiceSpeed = Math.max(1.0, Math.min(1.5, options.voiceSpeed));
    this.pendingInputTranscript = '';
    this.pendingOutputTranscript = '';

    // Initialize playback context cleanly during user-gesture call stack
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.playbackCtx = new AudioCtx();
    if (this.playbackCtx.state === 'suspended') {
      await this.playbackCtx.resume();
    }

    const candidates = buildCandidateModels(options.preferredModel);
    const errors: string[] = [];

    this.emitVoiceState('thinking');

    let openedSocket: WebSocket | null = null;
    let selectedModel: string | null = null;

    for (const candidate of candidates) {
      try {
        openedSocket = await this.openSocketForModel(candidate, options);
        selectedModel = candidate;
        break;
      } catch (err) {
        errors.push(
          err instanceof Error ? err.message : `Failed ${shortModelName(candidate)}`
        );
      }
    }

    if (!openedSocket || !selectedModel) {
      this.cleanupResources();
      const summary = errors.join(' · ') || 'Unable to connect to Gemini Live.';
      this.emitVoiceState('idle', summary);
      throw new Error(summary);
    }

    this.ws = openedSocket;
    this.activeModel = selectedModel;
    this.connected = true;

    try {
      await this.startMicrophoneCapture();
    } catch (micErr) {
      this.disconnect();
      const msg =
        micErr instanceof Error
          ? micErr.message
          : 'Microphone permission denied.';
      throw new Error(msg);
    }

    this.emitVoiceState('listening');
    return shortModelName(selectedModel);
  }

  private cleanupResources(): void {
    this.connected = false;
    this.activeModel = null;
    this.clearPlaybackQueue();
    this.pcmBuffer = [];
    this.pcmBufferSamples = 0;
    this.bargeInStreak = 0;

    if (this.workletNode) {
      try {
        this.workletNode.port.onmessage = null;
        this.workletNode.disconnect();
      } catch {
        // ignore
      }
      this.workletNode = null;
    }

    if (this.scriptProcessor) {
      try {
        this.scriptProcessor.onaudioprocess = null;
        this.scriptProcessor.disconnect();
      } catch {
        // ignore
      }
      this.scriptProcessor = null;
    }

    if (this.sourceNode) {
      try {
        this.sourceNode.disconnect();
      } catch {
        // ignore
      }
      this.sourceNode = null;
    }

    if (this.silentSink) {
      try {
        this.silentSink.disconnect();
      } catch {
        // ignore
      }
      this.silentSink = null;
    }

    if (this.workletBlobUrl) {
      URL.revokeObjectURL(this.workletBlobUrl);
      this.workletBlobUrl = null;
    }

    if (this.mediaStream) {
      for (const track of this.mediaStream.getTracks()) {
        track.stop();
      }
      this.mediaStream = null;
    }

    if (this.captureCtx) {
      void this.captureCtx.close().catch(() => {});
      this.captureCtx = null;
    }

    if (this.playbackCtx) {
      void this.playbackCtx.close().catch(() => {});
      this.playbackCtx = null;
    }

    if (this.ws) {
      try {
        if (
          this.ws.readyState === WebSocket.OPEN ||
          this.ws.readyState === WebSocket.CONNECTING
        ) {
          this.ws.close(1000, 'Client disconnected');
        }
      } catch {
        // ignore
      }
      this.ws = null;
    }
  }

  disconnect(): void {
    this.intentionalDisconnect = true;
    this.cleanupResources();
    this.emitVoiceState('idle');
  }
}

export const geminiLiveService = new GeminiLiveService();
