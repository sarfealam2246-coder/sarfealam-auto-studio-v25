export const ACTIVE_JOB_STORAGE_KEY = 'sarfealam_active_job_v2';

const JOB_EXPIRY_MS = 7 * 24 * 60 * 60 * 1000;

export type ActiveJobStatus =
  | 'building'
  | 'exporting'
  | 'polling'
  | 'healing'
  | 'paused'
  | 'completed'
  | 'failed';

export interface ActiveStudioJob {
  jobId: string;
  title: string;
  stage: string;
  paused: boolean;
  targetRepo: string;
  status: ActiveJobStatus;
  runId: number | null;
  updatedAt: number;
}

const VALID_STATUSES = new Set<ActiveJobStatus>([
  'building',
  'exporting',
  'polling',
  'healing',
  'paused',
  'completed',
  'failed',
]);

function makeJobId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `job-${crypto.randomUUID()}`;
  }
  return `job-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export function createActiveJob(input: {
  jobId?: string;
  title: string;
  stage: string;
  paused: boolean;
  targetRepo?: string;
  status: ActiveJobStatus;
  runId?: number | null;
}): ActiveStudioJob {
  const job: ActiveStudioJob = {
    jobId: input.jobId?.trim() || makeJobId(),
    title: input.title.trim() || 'Sarfealam Studio Job',
    stage: input.stage.trim() || '1. Shell',
    paused: Boolean(input.paused),
    targetRepo: (input.targetRepo ?? '').trim(),
    status: VALID_STATUSES.has(input.status) ? input.status : 'building',
    runId:
      typeof input.runId === 'number' && Number.isFinite(input.runId)
        ? input.runId
        : null,
    updatedAt: Date.now(),
  };
  return saveActiveJob(job);
}

export function saveActiveJob(job: ActiveStudioJob): ActiveStudioJob {
  const normalized: ActiveStudioJob = {
    ...job,
    status: VALID_STATUSES.has(job.status) ? job.status : 'building',
    runId:
      typeof job.runId === 'number' && Number.isFinite(job.runId)
        ? job.runId
        : null,
    updatedAt: Date.now(),
  };

  try {
    window.localStorage.setItem(
      ACTIVE_JOB_STORAGE_KEY,
      JSON.stringify(normalized)
    );
  } catch {
    // Ignore storage quota errors gracefully
  }

  return normalized;
}

export function loadActiveJob(): ActiveStudioJob | null {
  try {
    const raw = window.localStorage.getItem(ACTIVE_JOB_STORAGE_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return null;
    }
    const obj = parsed as Partial<ActiveStudioJob>;
    if (
      typeof obj.jobId !== 'string' ||
      !obj.jobId.trim() ||
      typeof obj.title !== 'string' ||
      !obj.title.trim()
    ) {
      return null;
    }

    const updatedAt =
      typeof obj.updatedAt === 'number' && Number.isFinite(obj.updatedAt)
        ? obj.updatedAt
        : Date.now();

    if (Date.now() - updatedAt > JOB_EXPIRY_MS) {
      clearActiveJob();
      return null;
    }

    const status: ActiveJobStatus =
      typeof obj.status === 'string' &&
      VALID_STATUSES.has(obj.status as ActiveJobStatus)
        ? (obj.status as ActiveJobStatus)
        : 'building';

    return {
      jobId: obj.jobId.trim(),
      title: obj.title.trim(),
      stage:
        typeof obj.stage === 'string' && obj.stage.trim()
          ? obj.stage.trim()
          : '1. Shell',
      paused: Boolean(obj.paused),
      targetRepo:
        typeof obj.targetRepo === 'string' ? obj.targetRepo.trim() : '',
      status,
      runId:
        typeof obj.runId === 'number' && Number.isFinite(obj.runId)
          ? obj.runId
          : null,
      updatedAt,
    };
  } catch {
    return null;
  }
}

export function loadUnfinishedJob(): ActiveStudioJob | null {
  const job = loadActiveJob();
  if (!job) return null;
  if (job.status === 'completed' || job.status === 'failed') {
    return null;
  }
  return job;
}

export function patchActiveJob(
  patch: Partial<Omit<ActiveStudioJob, 'jobId'>>
): ActiveStudioJob | null {
  const current = loadActiveJob();
  if (!current) return null;
  return saveActiveJob({
    ...current,
    ...patch,
    jobId: current.jobId,
    updatedAt: Date.now(),
  });
}

export function clearActiveJob(): void {
  try {
    window.localStorage.removeItem(ACTIVE_JOB_STORAGE_KEY);
  } catch {
    // Ignore storage errors gracefully
  }
}
