import { studioBus } from './eventBus';
import { waitIfPaused } from './pipelineController';
import {
  searchIconifyIcons,
  searchWikimediaPhotos,
} from './assetHunterService';
import type {
  StudioAssetItem,
  StudioSecrets,
  UserMemoryRule,
  VirtualFile,
} from '../types/studio';

export type CommercialAppCategory =
  | 'fintech'
  | 'fantasy'
  | 'ecommerce'
  | 'booking';

export interface GenerateCommercialAppOptions {
  appName?: string;
  category?: string;
  prompt?: string;
  selectedAssets: StudioAssetItem[];
  secrets: StudioSecrets;
  memoryRules?: UserMemoryRule[];
  signal?: AbortSignal;
}

export interface GeneratedCommercialAppResult {
  files: VirtualFile[];
  entryPath: string;
  appName: string;
  category: CommercialAppCategory;
  injectedAssetsCount: number;
  supabaseWired: boolean;
}

interface ResolvedCommercialAssets {
  photos: { name: string; url: string }[];
  icons: { name: string; url: string }[];
  audio: { name: string; url: string }[];
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function safeJsonForScript(data: unknown): string {
  return JSON.stringify(data).replace(/</g, '\\u003c').replace(/>/g, '\\u003e');
}

export function resolveCommercialCategory(
  rawCategory?: string,
  rawPrompt?: string
): CommercialAppCategory {
  const combined = `${rawCategory ?? ''} ${rawPrompt ?? ''}`.toLowerCase();
  if (
    /(dream11|fantasy|cricket|sports|match|contest|league|ipl|team|gaming)/.test(
      combined
    )
  ) {
    return 'fantasy';
  }
  if (
    /(shop|store|ecom|e-com|cart|marketplace|flipkart|amazon|fashion|grocery|product)/.test(
      combined
    )
  ) {
    return 'ecommerce';
  }
  if (
    /(book|booking|hotel|flight|cab|taxi|ride|ticket|travel|salon|doctor|appointment)/.test(
      combined
    )
  ) {
    return 'booking';
  }
  return 'fintech';
}

function defaultAppNameForCategory(category: CommercialAppCategory): string {
  switch (category) {
    case 'fantasy':
      return 'ProXI Fantasy Arena';
    case 'ecommerce':
      return 'SwiftKart Pro';
    case 'booking':
      return 'GoReserve Express';
    case 'fintech':
    default:
      return 'PayPulse UPI Pro';
  }
}

function buildCategoryAssetQueries(category: CommercialAppCategory): {
  photoQuery: string;
  iconQuery: string;
} {
  switch (category) {
    case 'fantasy':
      return { photoQuery: 'cricket stadium', iconQuery: 'trophy' };
    case 'ecommerce':
      return { photoQuery: 'headphones sneaker watch', iconQuery: 'shopping' };
    case 'booking':
      return { photoQuery: 'resort hotel travel', iconQuery: 'calendar' };
    case 'fintech':
    default:
      return { photoQuery: 'smartphone payment finance', iconQuery: 'wallet' };
  }
}

function buildCategoryCatalog(
  category: CommercialAppCategory,
  photos: { name: string; url: string }[],
  icons: { name: string; url: string }[]
) {
  const photoAt = (idx: number) => photos[idx]?.url || '';
  const iconAt = (idx: number) => icons[idx]?.url || '';

  if (category === 'fantasy') {
    return {
      brandTag: 'MEGA CONTESTS · INSTANT WITHDRAW',
      accentPrimary: '#EF4444',
      accentSecondary: '#F59E0B',
      balanceLabel: 'Winning Wallet',
      initialBalance: 4850,
      ctaLabel: 'Join Contest',
      tab2Label: 'Contests',
      tab3Label: 'Wallet',
      quickActions: [
        { id: 'mega', label: 'Mega ₹5Cr', icon: iconAt(0), glyph: '🏆', color: '#EF4444' },
        { id: 'h2h', label: 'Head 2 Head', icon: iconAt(1), glyph: '⚡', color: '#F59E0B' },
        { id: 'add', label: 'Add Cash', icon: iconAt(2), glyph: '💳', color: '#10B981' },
        { id: 'rank', label: 'Leaderboard', icon: iconAt(3), glyph: '📊', color: '#3B82F6' },
      ],
      items: [
        {
          id: 'c1',
          badge: 'LIVE · T20',
          title: 'IND vs AUS · Mega League',
          subtitle: 'Prize Pool ₹2.5 Crore · 1st ₹25L',
          price: 49,
          meta: '12,480 / 20,000 spots',
          fillPct: 62,
          photo: photoAt(0),
          gradient: 'linear-gradient(135deg,#dc2626,#7f1d1d)',
        },
        {
          id: 'c2',
          badge: 'HOT · 2X',
          title: 'MUM vs CHN · Super Over',
          subtitle: 'Prize Pool ₹40 Lakh · 60% Winners',
          price: 99,
          meta: '3,920 / 5,000 spots',
          fillPct: 78,
          photo: photoAt(1),
          gradient: 'linear-gradient(135deg,#2563eb,#1e1b4b)',
        },
        {
          id: 'c3',
          badge: 'PRO',
          title: 'DEL vs BLR · Winner Takes All',
          subtitle: 'Prize Pool ₹10,000 · 4 Spots',
          price: 299,
          meta: '2 / 4 spots left',
          fillPct: 50,
          photo: photoAt(2),
          gradient: 'linear-gradient(135deg,#059669,#064e3b)',
        },
      ],
    };
  }

  if (category === 'ecommerce') {
    return {
      brandTag: 'EXPRESS 20-MIN DELIVERY · VERIFIED',
      accentPrimary: '#007AFF',
      accentSecondary: '#10B981',
      balanceLabel: 'Store Credits',
      initialBalance: 6200,
      ctaLabel: 'Add to Cart',
      tab2Label: 'Catalog',
      tab3Label: 'Cart',
      quickActions: [
        { id: 'flash', label: 'Flash Deals', icon: iconAt(0), glyph: '⚡', color: '#F59E0B' },
        { id: 'tech', label: 'Audio Tech', icon: iconAt(1), glyph: '🎧', color: '#007AFF' },
        { id: 'add', label: 'Add Balance', icon: iconAt(2), glyph: '💳', color: '#10B981' },
        { id: 'track', label: 'Orders', icon: iconAt(3), glyph: '📦', color: '#8B5CF6' },
      ],
      items: [
        {
          id: 'p1',
          badge: 'BESTSELLER',
          title: 'AeroPro ANC Wireless Studio',
          subtitle: '48h Battery · Spatial Hi-Res Audio',
          price: 2499,
          meta: '4.9 ★ · Express Delivery',
          fillPct: 86,
          photo: photoAt(0),
          gradient: 'linear-gradient(135deg,#0284c7,#1e293b)',
        },
        {
          id: 'p2',
          badge: 'NEW DROP',
          title: 'Pulse Titanium Smart Watch',
          subtitle: 'AMOLED 120Hz · Dual-Band GPS',
          price: 3999,
          meta: '4.8 ★ · 1 Year Warranty',
          fillPct: 72,
          photo: photoAt(1),
          gradient: 'linear-gradient(135deg,#7c3aed,#1e1b4b)',
        },
        {
          id: 'p3',
          badge: '35% OFF',
          title: 'CloudStride Pro Runners',
          subtitle: 'Featherlight Knit · Carbon Sole',
          price: 1899,
          meta: '4.7 ★ · Free Exchange',
          fillPct: 64,
          photo: photoAt(2),
          gradient: 'linear-gradient(135deg,#059669,#0f172a)',
        },
      ],
    };
  }

  if (category === 'booking') {
    return {
      brandTag: 'INSTANT CONFIRMATION · ZERO FEE',
      accentPrimary: '#0EA5E9',
      accentSecondary: '#8B5CF6',
      balanceLabel: 'Travel Wallet',
      initialBalance: 12500,
      ctaLabel: 'Book Now',
      tab2Label: 'Bookings',
      tab3Label: 'Wallet',
      quickActions: [
        { id: 'stays', label: 'Stays', icon: iconAt(0), glyph: '🏨', color: '#0EA5E9' },
        { id: 'flights', label: 'Flights', icon: iconAt(1), glyph: '✈️', color: '#6366F1' },
        { id: 'cabs', label: 'Cabs', icon: iconAt(2), glyph: '🚖', color: '#F59E0B' },
        { id: 'add', label: 'Top Up', icon: iconAt(3), glyph: '💳', color: '#10B981' },
      ],
      items: [
        {
          id: 'b1',
          badge: 'TOP RATED',
          title: 'Azure Bay Cliffside Resort',
          subtitle: 'Goa · Infinity Pool · Breakfast Included',
          price: 4200,
          meta: '4.9 ★ · Instant Voucher',
          fillPct: 84,
          photo: photoAt(0),
          gradient: 'linear-gradient(135deg,#0284c7,#0f172a)',
        },
        {
          id: 'b2',
          badge: 'EXPRESS',
          title: 'DEL → BOM · Morning Non-Stop',
          subtitle: '07:45 AM · Cabin + 15kg Check-In',
          price: 3650,
          meta: '6 seats left at this fare',
          fillPct: 79,
          photo: photoAt(1),
          gradient: 'linear-gradient(135deg,#4f46e5,#1e1b4b)',
        },
        {
          id: 'b3',
          badge: 'PRIME CAB',
          title: 'Airport Sedan · Fixed Fare',
          subtitle: 'AC Sedan · Live GPS & Verified Driver',
          price: 699,
          meta: 'Arrives in 4 mins',
          fillPct: 92,
          photo: photoAt(2),
          gradient: 'linear-gradient(135deg,#0d9488,#064e3b)',
        },
      ],
    };
  }

  // Default: Fintech / PhonePe-inspired UPI + Super Wallet
  return {
    brandTag: 'UPI LITE · INSTANT 24x7 SETTLEMENT',
    accentPrimary: '#6D28D9',
    accentSecondary: '#007AFF',
    balanceLabel: 'UPI Wallet Balance',
    initialBalance: 18450,
    ctaLabel: 'Pay Now',
    tab2Label: 'Offers',
    tab3Label: 'Wallet',
    quickActions: [
      { id: 'scan', label: 'Scan & Pay', icon: iconAt(0), glyph: '📷', color: '#7C3AED' },
      { id: 'mobile', label: 'To Mobile', icon: iconAt(1), glyph: '📱', color: '#007AFF' },
      { id: 'bank', label: 'To Bank', icon: iconAt(2), glyph: '🏦', color: '#10B981' },
      { id: 'add', label: 'Add Money', icon: iconAt(3), glyph: '➕', color: '#F59E0B' },
    ],
    items: [
      {
        id: 'f1',
        badge: 'CASHBACK 5%',
        title: '5G Mobile & Fiber Recharge',
        subtitle: 'Instant Plan Activation · Zero Platform Fee',
        price: 299,
        meta: 'Up to ₹50 instant cashback',
        fillPct: 88,
        photo: photoAt(0),
        gradient: 'linear-gradient(135deg,#6d28d9,#312e81)',
      },
      {
        id: 'f2',
        badge: 'FASTAG',
        title: 'Electricity & Utility Bills',
        subtitle: 'BBPS Verified · Instant Digital Receipt',
        price: 1240,
        meta: 'Auto-pay reminders active',
        fillPct: 74,
        photo: photoAt(1),
        gradient: 'linear-gradient(135deg,#0284c7,#0f172a)',
      },
      {
        id: 'f3',
        badge: '24K GOLD',
        title: 'Digital Gold Micro-SIP',
        subtitle: '99.99% Hallmarked Vault · Start ₹100',
        price: 500,
        meta: 'Live rate ₹7,420/g',
        fillPct: 65,
        photo: photoAt(2),
        gradient: 'linear-gradient(135deg,#d97706,#78350f)',
      },
    ],
  };
}

function buildCommercialManifestJson(
  appName: string,
  category: CommercialAppCategory,
  selectedAssets: StudioAssetItem[],
  appsSupabaseUrl?: string
): string {
  const payload = {
    studio: 'Sarfealam Auto-Studio',
    runtime: 'commercial-mobile-pro',
    appName,
    category,
    schemaVersion: 1,
    updatedAt: new Date().toISOString(),
    appsSupabaseConfigured: Boolean(appsSupabaseUrl?.trim()),
    strictIsolation: 'apps-only-no-studio-keys',
    count: selectedAssets.length,
    assets: selectedAssets.map((item) => ({
      id: item.id,
      name: item.name,
      category: item.category,
      source: item.source,
      url: item.url,
      ...(item.previewUrl ? { previewUrl: item.previewUrl } : {}),
      ...(item.format ? { format: item.format } : {}),
    })),
  };
  return `${JSON.stringify(payload, null, 2)}\n`;
}

function buildCommercialAppHtml(params: {
  appName: string;
  category: CommercialAppCategory;
  prompt?: string;
  assets: ResolvedCommercialAssets;
  appsSupabaseUrl: string;
  appsSupabaseAnonKey: string;
  activeRules: string[];
}): string {
  const catalog = buildCategoryCatalog(
    params.category,
    params.assets.photos,
    params.assets.icons
  );

  // STRICT ISOLATION: ONLY appsSupabaseUrl and appsSupabaseAnonKey are injected.
  // NEVER inject studioSupabaseUrl, studioSupabaseAnonKey, or any Studio AI keys.
  const runtimeConfig = {
    appName: params.appName,
    category: params.category,
    prompt: params.prompt || '',
    catalog,
    appAudioUrls: params.assets.audio.map((a) => a.url).slice(0, 4),
    memoryHints: params.activeRules.slice(0, 4),
    supabase: {
      url: params.appsSupabaseUrl,
      anonKey: params.appsSupabaseAnonKey,
    },
  };

  const configJson = safeJsonForScript(runtimeConfig);

  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, maximum-scale=1.0, viewport-fit=cover"
    />
    <title>${escapeHtml(params.appName)}</title>
    <style>
      *, *::before, *::after { box-sizing: border-box; }
      html, body {
        margin: 0;
        padding: 0;
        width: 100%;
        max-width: 100vw;
        overflow-x: hidden;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        background: #0B1120;
        color: #F8FAFC;
        -webkit-tap-highlight-color: transparent;
      }
      body.light-theme {
        background: #F3F6FB;
        color: #0F172A;
      }
      .app-shell {
        min-height: 100dvh;
        width: 100%;
        max-width: 460px;
        margin: 0 auto;
        padding: 10px 10px 76px;
        display: flex;
        flex-direction: column;
        gap: 10px;
      }
      .topbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        padding: 8px 10px;
        border-radius: 16px;
        background: rgba(30, 41, 59, 0.88);
        border: 1px solid rgba(255, 255, 255, 0.1);
      }
      body.light-theme .topbar {
        background: rgba(255, 255, 255, 0.9);
        border-color: rgba(15, 23, 42, 0.1);
      }
      .brand-wrap { display: flex; align-items: center; gap: 8px; min-width: 0; }
      .brand-mark {
        width: 30px;
        height: 30px;
        border-radius: 10px;
        background: linear-gradient(135deg, ${catalog.accentPrimary}, ${catalog.accentSecondary});
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 900;
        font-size: 13px;
        color: #fff;
        flex-shrink: 0;
      }
      .brand-title { font-size: 13px; font-weight: 800; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .brand-sub { font-size: 9.5px; color: #94A3B8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      body.light-theme .brand-sub { color: #64748B; }
      .icon-pill-btn {
        height: 28px;
        padding: 0 9px;
        border-radius: 999px;
        border: 1px solid rgba(255, 255, 255, 0.14);
        background: rgba(15, 23, 42, 0.65);
        color: inherit;
        font-size: 10.5px;
        font-weight: 700;
        cursor: pointer;
        flex-shrink: 0;
      }
      body.light-theme .icon-pill-btn {
        background: #F1F5F9;
        border-color: rgba(15, 23, 42, 0.12);
      }

      /* Hero Wallet Card */
      .wallet-hero {
        position: relative;
        border-radius: 18px;
        padding: 13px;
        background: linear-gradient(135deg, ${catalog.accentPrimary}, ${catalog.accentSecondary});
        color: #fff;
        box-shadow: 0 10px 26px rgba(0, 0, 0, 0.28);
        overflow: hidden;
      }
      .wallet-row { display: flex; align-items: flex-start; justify-content: space-between; gap: 8px; }
      .wallet-label { font-size: 10px; font-weight: 700; opacity: 0.88; letter-spacing: 0.04em; text-transform: uppercase; }
      .wallet-amt { font-size: 24px; font-weight: 900; margin-top: 2px; font-variant-numeric: tabular-nums; }
      .wallet-tag {
        margin-top: 6px;
        display: inline-block;
        padding: 3px 8px;
        border-radius: 999px;
        background: rgba(15, 23, 42, 0.28);
        font-size: 9.5px;
        font-weight: 700;
      }
      .hero-btn {
        height: 30px;
        padding: 0 11px;
        border-radius: 10px;
        border: 1px solid rgba(255, 255, 255, 0.32);
        background: rgba(255, 255, 255, 0.2);
        color: #fff;
        font-size: 11px;
        font-weight: 800;
        cursor: pointer;
        white-space: nowrap;
      }
      .hero-btn:active { transform: scale(0.96); }

      /* Quick Actions Grid */
      .quick-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 6px;
      }
      .quick-card {
        border-radius: 14px;
        padding: 8px 4px;
        background: rgba(30, 41, 59, 0.82);
        border: 1px solid rgba(255, 255, 255, 0.08);
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 5px;
        cursor: pointer;
        color: inherit;
      }
      body.light-theme .quick-card {
        background: #FFFFFF;
        border-color: rgba(15, 23, 42, 0.08);
      }
      .quick-card:active { transform: scale(0.96); }
      .quick-icon {
        width: 32px;
        height: 32px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 15px;
        color: #fff;
      }
      .quick-icon img { width: 18px; height: 18px; filter: brightness(0) invert(1); }
      .quick-label { font-size: 9.5px; font-weight: 700; text-align: center; line-height: 1.15; }

      /* Section & Cards */
      .sec-head { display: flex; align-items: center; justify-content: space-between; gap: 6px; }
      .sec-title { font-size: 12px; font-weight: 800; }
      .sec-meta { font-size: 10px; color: #94A3B8; }
      .card-list { display: flex; flex-direction: column; gap: 8px; }
      .item-card {
        border-radius: 16px;
        overflow: hidden;
        background: rgba(30, 41, 59, 0.85);
        border: 1px solid rgba(255, 255, 255, 0.09);
      }
      body.light-theme .item-card {
        background: #FFFFFF;
        border-color: rgba(15, 23, 42, 0.09);
      }
      .item-banner {
        height: 76px;
        position: relative;
        overflow: hidden;
        display: flex;
        align-items: flex-end;
        padding: 8px 10px;
      }
      .item-banner img {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        opacity: 0.48;
      }
      .item-badge {
        position: relative;
        z-index: 2;
        padding: 2px 7px;
        border-radius: 999px;
        background: rgba(15, 23, 42, 0.78);
        color: #FDE68A;
        font-size: 9.5px;
        font-weight: 800;
      }
      .item-body { padding: 10px; display: flex; flex-direction: column; gap: 6px; }
      .item-top { display: flex; align-items: flex-start; justify-content: space-between; gap: 8px; }
      .item-title { font-size: 12.5px; font-weight: 800; }
      .item-sub { font-size: 10.5px; color: #94A3B8; margin-top: 1px; }
      body.light-theme .item-sub { color: #64748B; }
      .item-price { font-size: 13px; font-weight: 900; color: #34D399; white-space: nowrap; font-variant-numeric: tabular-nums; }
      body.light-theme .item-price { color: #059669; }
      .progress-track { height: 5px; border-radius: 999px; background: rgba(148, 163, 184, 0.22); overflow: hidden; }
      .progress-fill { height: 100%; border-radius: 999px; background: linear-gradient(90deg, ${catalog.accentPrimary}, ${catalog.accentSecondary}); }
      .item-foot { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
      .item-meta { font-size: 10px; color: #94A3B8; }
      .cta-btn {
        height: 28px;
        padding: 0 12px;
        border-radius: 9px;
        border: 0;
        background: linear-gradient(90deg, ${catalog.accentPrimary}, ${catalog.accentSecondary});
        color: #fff;
        font-size: 10.5px;
        font-weight: 800;
        cursor: pointer;
        white-space: nowrap;
      }
      .cta-btn:active { transform: scale(0.95); }

      /* Ledger & Cloud panel */
      .glass-panel {
        border-radius: 16px;
        padding: 11px;
        background: rgba(30, 41, 59, 0.85);
        border: 1px solid rgba(255, 255, 255, 0.09);
        display: flex;
        flex-direction: column;
        gap: 8px;
      }
      body.light-theme .glass-panel {
        background: #FFFFFF;
        border-color: rgba(15, 23, 42, 0.09);
      }
      .tx-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        padding: 7px 8px;
        border-radius: 10px;
        background: rgba(15, 23, 42, 0.45);
        font-size: 11px;
      }
      body.light-theme .tx-row { background: #F8FAFC; }
      .tx-credit { color: #34D399; font-weight: 800; font-variant-numeric: tabular-nums; }
      .tx-debit { color: #F87171; font-weight: 800; font-variant-numeric: tabular-nums; }

      /* Bottom Tab Bar */
      .bottom-nav {
        position: fixed;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 30;
        background: rgba(15, 23, 42, 0.96);
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        padding: 6px 8px;
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 4px;
      }
      body.light-theme .bottom-nav {
        background: rgba(255, 255, 255, 0.96);
        border-top-color: rgba(15, 23, 42, 0.1);
      }
      .nav-btn {
        height: 44px;
        border-radius: 12px;
        border: 0;
        background: transparent;
        color: #94A3B8;
        font-size: 10px;
        font-weight: 700;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 2px;
        cursor: pointer;
      }
      .nav-btn.active {
        background: rgba(99, 102, 241, 0.22);
        color: #F8FAFC;
      }
      body.light-theme .nav-btn.active {
        background: rgba(0, 122, 255, 0.12);
        color: #007AFF;
      }
      .nav-emoji { font-size: 14px; line-height: 1; }

      /* Modal Overlay */
      .modal-backdrop {
        position: fixed;
        inset: 0;
        z-index: 50;
        background: rgba(2, 6, 23, 0.72);
        display: none;
        align-items: flex-end;
        justify-content: center;
        padding: 10px;
      }
      .modal-backdrop.open { display: flex; }
      .modal-sheet {
        width: 100%;
        max-width: 420px;
        border-radius: 20px;
        padding: 14px;
        background: #1E293B;
        border: 1px solid rgba(255, 255, 255, 0.14);
        color: #F8FAFC;
        display: flex;
        flex-direction: column;
        gap: 10px;
      }
      body.light-theme .modal-sheet {
        background: #FFFFFF;
        color: #0F172A;
        border-color: rgba(15, 23, 42, 0.12);
      }
      .modal-input {
        width: 100%;
        height: 36px;
        border-radius: 10px;
        border: 1px solid rgba(148, 163, 184, 0.35);
        background: rgba(15, 23, 42, 0.5);
        color: inherit;
        padding: 0 10px;
        font-size: 13px;
        font-weight: 700;
      }
      body.light-theme .modal-input { background: #F8FAFC; }
      .chip-row { display: flex; gap: 6px; flex-wrap: wrap; }
      .amt-chip {
        height: 28px;
        padding: 0 10px;
        border-radius: 999px;
        border: 1px solid rgba(148, 163, 184, 0.35);
        background: transparent;
        color: inherit;
        font-size: 11px;
        font-weight: 700;
        cursor: pointer;
      }
      .toast {
        position: fixed;
        top: 10px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 60;
        padding: 6px 12px;
        border-radius: 999px;
        background: #10B981;
        color: #052E16;
        font-size: 11px;
        font-weight: 800;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.2s ease;
        white-space: nowrap;
        max-width: calc(100vw - 24px);
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .toast.show { opacity: 1; }
      .hidden { display: none !important; }
    </style>
  </head>
  <body>
    <div id="toast" class="toast"></div>

    <div class="app-shell">
      <header class="topbar">
        <div class="brand-wrap">
          <div class="brand-mark">${escapeHtml(params.appName.slice(0, 2).toUpperCase())}</div>
          <div style="min-width:0">
            <div class="brand-title">${escapeHtml(params.appName)}</div>
            <div class="brand-sub" id="cloud-status-line">Checking Apps Cloud...</div>
          </div>
        </div>
        <button type="button" class="icon-pill-btn" id="btn-theme">Light</button>
      </header>

      <!-- TAB 1: HOME -->
      <main id="tab-home" class="card-list">
        <section class="wallet-hero">
          <div class="wallet-row">
            <div>
              <div class="wallet-label">${escapeHtml(catalog.balanceLabel)}</div>
              <div class="wallet-amt" id="wallet-balance">₹${catalog.initialBalance.toLocaleString('en-IN')}</div>
              <div class="wallet-tag">${escapeHtml(catalog.brandTag)}</div>
            </div>
            <button type="button" class="hero-btn" id="btn-open-topup">+ Add Cash</button>
          </div>
        </section>

        <section class="quick-grid" id="quick-actions-grid"></section>

        <div class="sec-head">
          <span class="sec-title">Featured ${escapeHtml(catalog.tab2Label)}</span>
          <span class="sec-meta" id="featured-count"></span>
        </div>
        <div id="home-items-list" class="card-list"></div>
      </main>

      <!-- TAB 2: CATALOG / CONTESTS / BOOKINGS -->
      <main id="tab-explore" class="card-list hidden">
        <div class="sec-head">
          <span class="sec-title">All ${escapeHtml(catalog.tab2Label)}</span>
          <span class="sec-meta">Instant Checkout</span>
        </div>
        <div id="explore-items-list" class="card-list"></div>
      </main>

      <!-- TAB 3: WALLET / CART / LEDGER -->
      <main id="tab-wallet" class="card-list hidden">
        <div class="glass-panel">
          <div class="sec-head">
            <span class="sec-title">${escapeHtml(catalog.tab3Label)} & Activity</span>
            <button type="button" class="cta-btn" id="btn-wallet-topup">+ Top Up</button>
          </div>
          <div style="font-size:20px;font-weight:900;font-variant-numeric:tabular-nums;" id="wallet-balance-secondary"></div>
          <div id="tx-ledger" class="card-list"></div>
        </div>
      </main>

      <!-- TAB 4: PROFILE & SUPABASE HOOKS -->
      <main id="tab-profile" class="card-list hidden">
        <div class="glass-panel">
          <div class="sec-title">Apps Supabase Cloud Hook</div>
          <div class="item-sub" id="supabase-hook-desc"></div>
          <button type="button" class="cta-btn" id="btn-sync-cloud">Test Cloud Sync</button>
        </div>
        <div class="glass-panel">
          <div class="sec-title">Zero-Shortcut Isolation Verified</div>
          <div class="item-sub">
            Only Apps Supabase public client config is wired. Studio AI keys and Studio Supabase remain 100% isolated.
          </div>
        </div>
      </main>
    </div>

    <!-- Bottom Tab Bar -->
    <nav class="bottom-nav" aria-label="App Navigation">
      <button type="button" class="nav-btn active" data-tab="home">
        <span class="nav-emoji">🏠</span>
        <span>Home</span>
      </button>
      <button type="button" class="nav-btn" data-tab="explore">
        <span class="nav-emoji">✨</span>
        <span>${escapeHtml(catalog.tab2Label)}</span>
      </button>
      <button type="button" class="nav-btn" data-tab="wallet">
        <span class="nav-emoji">💳</span>
        <span>${escapeHtml(catalog.tab3Label)}</span>
      </button>
      <button type="button" class="nav-btn" data-tab="profile">
        <span class="nav-emoji">☁️</span>
        <span>Cloud</span>
      </button>
    </nav>

    <!-- Interactive Modal -->
    <div id="action-modal" class="modal-backdrop" role="dialog" aria-modal="true">
      <div class="modal-sheet">
        <div class="sec-head">
          <span class="sec-title" id="modal-title">Add Funds</span>
          <button type="button" class="icon-pill-btn" id="btn-close-modal">Close</button>
        </div>
        <div class="item-sub" id="modal-desc">Enter amount to credit instantly.</div>
        <input type="number" id="modal-amount" class="modal-input" value="500" min="10" max="100000" />
        <div class="chip-row">
          <button type="button" class="amt-chip" data-add="250">+₹250</button>
          <button type="button" class="amt-chip" data-add="500">+₹500</button>
          <button type="button" class="amt-chip" data-add="1000">+₹1,000</button>
          <button type="button" class="amt-chip" data-add="2500">+₹2,500</button>
        </div>
        <button type="button" class="cta-btn" style="height:36px;font-size:12px;" id="btn-confirm-modal">Confirm Instantly</button>
      </div>
    </div>

    <script id="studio-commercial-app-config" type="application/json">${configJson}</script>
    <script>
      (function () {
        const CONFIG = JSON.parse(
          document.getElementById('studio-commercial-app-config').textContent
        );
        window.__COMMERCIAL_APP_CONFIG__ = CONFIG;

        // App Audio SFX Engine (selected app_audio + crisp Web Audio tap/success synth)
        let audioCtx = null;
        const externalAudio = (CONFIG.appAudioUrls || []).map((u) => {
          const a = new Audio(u);
          a.preload = 'none';
          return a;
        });

        function ensureAudio() {
          if (!audioCtx) {
            const AC = window.AudioContext || window.webkitAudioContext;
            if (AC) audioCtx = new AC();
          }
          if (audioCtx && audioCtx.state === 'suspended') {
            audioCtx.resume().catch(() => {});
          }
        }

        function playTapSfx() {
          ensureAudio();
          if (!audioCtx) return;
          const now = audioCtx.currentTime;
          const osc = audioCtx.createOscillator();
          const gain = audioCtx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(640, now);
          osc.frequency.exponentialRampToValueAtTime(880, now + 0.055);
          gain.gain.setValueAtTime(0.05, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.065);
          osc.connect(gain);
          gain.connect(audioCtx.destination);
          osc.start(now);
          osc.stop(now + 0.07);
        }

        function playSuccessSfx() {
          ensureAudio();
          if (externalAudio.length > 0) {
            try {
              externalAudio[0].currentTime = 0;
              externalAudio[0].play().catch(() => {});
            } catch {}
          }
          if (!audioCtx) return;
          const now = audioCtx.currentTime;
          [523.25, 659.25, 783.99].forEach((freq, idx) => {
            const osc = audioCtx.createOscillator();
            const g = audioCtx.createGain();
            osc.type = 'triangle';
            osc.frequency.value = freq;
            const start = now + idx * 0.075;
            g.gain.setValueAtTime(0.001, start);
            g.gain.exponentialRampToValueAtTime(0.07, start + 0.02);
            g.gain.exponentialRampToValueAtTime(0.001, start + 0.22);
            osc.connect(g);
            g.connect(audioCtx.destination);
            osc.start(start);
            osc.stop(start + 0.24);
          });
        }

        // Apps-Only Supabase REST Client Hook (zero studio key leakage)
        const supabaseHook = {
          configured: Boolean(CONFIG.supabase && CONFIG.supabase.url && CONFIG.supabase.anonKey),
          async syncEvent(record) {
            if (!this.configured) {
              return { ok: true, mode: 'local-demo' };
            }
            try {
              const endpoint = CONFIG.supabase.url.replace(/\\/+$/, '') + '/rest/v1/app_events';
              const res = await fetch(endpoint, {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  apikey: CONFIG.supabase.anonKey,
                  Authorization: 'Bearer ' + CONFIG.supabase.anonKey,
                  Prefer: 'return=minimal',
                },
                body: JSON.stringify(record),
              });
              return { ok: res.ok, mode: 'supabase-rest', status: res.status };
            } catch (err) {
              return { ok: false, mode: 'offline-fallback', error: String(err) };
            }
          },
        };
        window.__COMMERCIAL_SUPABASE_HOOK__ = supabaseHook;

        const state = {
          balance: CONFIG.catalog.initialBalance,
          txs: [
            { title: 'Welcome Bonus Credit', amount: 500, type: 'credit', time: 'Just now' },
            { title: 'Verified Instant KYC', amount: 0, type: 'credit', time: 'Active' },
          ],
          modalMode: 'topup',
          pendingItem: null,
        };

        const toastEl = document.getElementById('toast');
        let toastTimer = 0;
        function showToast(msg) {
          toastEl.textContent = msg;
          toastEl.classList.add('show');
          clearTimeout(toastTimer);
          toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2200);
        }

        function formatInr(n) {
          return '₹' + Number(n || 0).toLocaleString('en-IN');
        }

        function renderBalancesAndLedger() {
          document.getElementById('wallet-balance').textContent = formatInr(state.balance);
          document.getElementById('wallet-balance-secondary').textContent = formatInr(state.balance);
          const ledger = document.getElementById('tx-ledger');
          ledger.innerHTML = '';
          state.txs.slice(0, 8).forEach((tx) => {
            const row = document.createElement('div');
            row.className = 'tx-row';
            const left = document.createElement('div');
            left.innerHTML = '<div style="font-weight:700">' + tx.title + '</div><div style="font-size:9.5px;color:#94A3B8">' + tx.time + '</div>';
            const right = document.createElement('div');
            right.className = tx.type === 'credit' ? 'tx-credit' : 'tx-debit';
            right.textContent = (tx.type === 'credit' ? '+' : '-') + formatInr(tx.amount);
            row.appendChild(left);
            row.appendChild(right);
            ledger.appendChild(row);
          });
        }

        function renderQuickActions() {
          const grid = document.getElementById('quick-actions-grid');
          grid.innerHTML = '';
          CONFIG.catalog.quickActions.forEach((act) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'quick-card';
            const iconBox = document.createElement('div');
            iconBox.className = 'quick-icon';
            iconBox.style.background = act.color;
            if (act.icon) {
              const img = document.createElement('img');
              img.src = act.icon;
              img.alt = act.label;
              img.onerror = () => { iconBox.textContent = act.glyph; };
              iconBox.appendChild(img);
            } else {
              iconBox.textContent = act.glyph;
            }
            const lbl = document.createElement('span');
            lbl.className = 'quick-label';
            lbl.textContent = act.label;
            btn.appendChild(iconBox);
            btn.appendChild(lbl);
            btn.addEventListener('click', () => {
              playTapSfx();
              if (act.id === 'add') {
                openModal('topup', null);
              } else {
                showToast(act.label + ' opened');
                switchTab('explore');
              }
            });
            grid.appendChild(btn);
          });
        }

        function buildItemCard(item) {
          const card = document.createElement('article');
          card.className = 'item-card';

          const banner = document.createElement('div');
          banner.className = 'item-banner';
          banner.style.background = item.gradient;
          if (item.photo) {
            const img = document.createElement('img');
            img.src = item.photo;
            img.alt = item.title;
            img.loading = 'lazy';
            img.onerror = () => img.remove();
            banner.appendChild(img);
          }
          const badge = document.createElement('span');
          badge.className = 'item-badge';
          badge.textContent = item.badge;
          banner.appendChild(badge);

          const body = document.createElement('div');
          body.className = 'item-body';

          const top = document.createElement('div');
          top.className = 'item-top';
          const info = document.createElement('div');
          const title = document.createElement('div');
          title.className = 'item-title';
          title.textContent = item.title;
          const sub = document.createElement('div');
          sub.className = 'item-sub';
          sub.textContent = item.subtitle;
          info.appendChild(title);
          info.appendChild(sub);

          const price = document.createElement('div');
          price.className = 'item-price';
          price.textContent = formatInr(item.price);
          top.appendChild(info);
          top.appendChild(price);

          const track = document.createElement('div');
          track.className = 'progress-track';
          const fill = document.createElement('div');
          fill.className = 'progress-fill';
          fill.style.width = item.fillPct + '%';
          track.appendChild(fill);

          const foot = document.createElement('div');
          foot.className = 'item-foot';
          const meta = document.createElement('span');
          meta.className = 'item-meta';
          meta.textContent = item.meta;
          const cta = document.createElement('button');
          cta.type = 'button';
          cta.className = 'cta-btn';
          cta.textContent = CONFIG.catalog.ctaLabel;
          cta.addEventListener('click', () => {
            playTapSfx();
            openModal('checkout', item);
          });
          foot.appendChild(meta);
          foot.appendChild(cta);

          body.appendChild(top);
          body.appendChild(track);
          body.appendChild(foot);
          card.appendChild(banner);
          card.appendChild(body);
          return card;
        }

        function renderCatalogLists() {
          const homeList = document.getElementById('home-items-list');
          const exploreList = document.getElementById('explore-items-list');
          homeList.innerHTML = '';
          exploreList.innerHTML = '';
          document.getElementById('featured-count').textContent = CONFIG.catalog.items.length + ' Live';
          CONFIG.catalog.items.forEach((item, idx) => {
            if (idx < 2) homeList.appendChild(buildItemCard(item));
            exploreList.appendChild(buildItemCard(item));
          });
        }

        const modalEl = document.getElementById('action-modal');
        const modalTitle = document.getElementById('modal-title');
        const modalDesc = document.getElementById('modal-desc');
        const modalAmt = document.getElementById('modal-amount');

        function openModal(mode, item) {
          state.modalMode = mode;
          state.pendingItem = item;
          if (mode === 'topup') {
            modalTitle.textContent = 'Add Instant Cash';
            modalDesc.textContent = 'Credit your ' + CONFIG.catalog.balanceLabel + ' via UPI.';
            modalAmt.value = '500';
            modalAmt.disabled = false;
          } else {
            modalTitle.textContent = CONFIG.catalog.ctaLabel + ' · ' + item.title;
            modalDesc.textContent = item.subtitle + ' (Wallet Balance: ' + formatInr(state.balance) + ')';
            modalAmt.value = String(item.price);
            modalAmt.disabled = true;
          }
          modalEl.classList.add('open');
        }

        function closeModal() {
          modalEl.classList.remove('open');
        }

        document.getElementById('btn-open-topup').addEventListener('click', () => {
          playTapSfx();
          openModal('topup', null);
        });
        document.getElementById('btn-wallet-topup').addEventListener('click', () => {
          playTapSfx();
          openModal('topup', null);
        });
        document.getElementById('btn-close-modal').addEventListener('click', () => {
          playTapSfx();
          closeModal();
        });
        document.querySelectorAll('.amt-chip').forEach((chip) => {
          chip.addEventListener('click', () => {
            if (modalAmt.disabled) return;
            playTapSfx();
            modalAmt.value = chip.dataset.add;
          });
        });

        document.getElementById('btn-confirm-modal').addEventListener('click', async () => {
          const val = Math.max(1, Number(modalAmt.value) || 0);
          if (state.modalMode === 'topup') {
            state.balance += val;
            state.txs.unshift({
              title: 'Instant UPI Top-Up',
              amount: val,
              type: 'credit',
              time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            });
            playSuccessSfx();
            showToast('Added ' + formatInr(val) + ' to Wallet');
            void supabaseHook.syncEvent({ event: 'topup', amount: val, app: CONFIG.appName });
          } else if (state.pendingItem) {
            if (state.balance < val) {
              showToast('Low balance — tap + Add Cash first');
              return;
            }
            state.balance -= val;
            state.txs.unshift({
              title: state.pendingItem.title,
              amount: val,
              type: 'debit',
              time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            });
            playSuccessSfx();
            showToast('Confirmed: ' + state.pendingItem.title);
            void supabaseHook.syncEvent({
              event: 'order',
              item: state.pendingItem.title,
              amount: val,
              app: CONFIG.appName,
            });
          }
          renderBalancesAndLedger();
          closeModal();
        });

        const tabPanels = {
          home: document.getElementById('tab-home'),
          explore: document.getElementById('tab-explore'),
          wallet: document.getElementById('tab-wallet'),
          profile: document.getElementById('tab-profile'),
        };
        const navBtns = Array.from(document.querySelectorAll('.nav-btn'));

        function switchTab(id) {
          Object.entries(tabPanels).forEach(([key, el]) => {
            el.classList.toggle('hidden', key !== id);
          });
          navBtns.forEach((b) => b.classList.toggle('active', b.dataset.tab === id));
        }

        navBtns.forEach((btn) => {
          btn.addEventListener('click', () => {
            playTapSfx();
            switchTab(btn.dataset.tab);
          });
        });

        const themeBtn = document.getElementById('btn-theme');
        themeBtn.addEventListener('click', () => {
          playTapSfx();
          const isLight = document.body.classList.toggle('light-theme');
          themeBtn.textContent = isLight ? 'Dark' : 'Light';
        });

        // Cloud Status Line
        const cloudLine = document.getElementById('cloud-status-line');
        const hookDesc = document.getElementById('supabase-hook-desc');
        if (supabaseHook.configured) {
          cloudLine.textContent = 'Apps Supabase Connected';
          hookDesc.textContent = 'Connected to Apps Supabase: ' + CONFIG.supabase.url;
        } else {
          cloudLine.textContent = 'Local Commercial Mode · Ready';
          hookDesc.textContent = 'Add Apps Supabase URL & Anon Key in Studio Secrets to enable live cloud sync.';
        }

        document.getElementById('btn-sync-cloud').addEventListener('click', async () => {
          playTapSfx();
          const res = await supabaseHook.syncEvent({ event: 'ping', app: CONFIG.appName });
          playSuccessSfx();
          showToast(res.mode === 'supabase-rest' ? 'Apps Supabase Synced!' : 'Local Demo Sync OK');
        });

        renderQuickActions();
        renderCatalogLists();
        renderBalancesAndLedger();
      })();
    </script>
  </body>
</html>
`;
}

export async function generateCommercialAppFiles(
  options: GenerateCommercialAppOptions
): Promise<GeneratedCommercialAppResult> {
  const category = resolveCommercialCategory(options.category, options.prompt);
  const appName = options.appName?.trim() || defaultAppNameForCategory(category);
  const selectedAssets = options.selectedAssets ?? [];
  const activeRules = (options.memoryRules ?? [])
    .filter((r) => r.enabled)
    .map((r) => r.rule);

  studioBus.emit('bot:progress', {
    botId: 'code',
    status: 'working',
    progress: 18,
    message: `Scaffolding ${appName} (${category})...`,
  });

  await waitIfPaused(options.signal);

  const selectedPhotos = selectedAssets
    .filter((a) => a.category === 'wikimedia_photos' && (a.previewUrl || a.url))
    .map((a) => ({ name: a.name, url: a.previewUrl || a.url }));
  const selectedIcons = selectedAssets
    .filter((a) => a.category === 'iconify_icons' && (a.previewUrl || a.url))
    .map((a) => ({ name: a.name, url: a.previewUrl || a.url }));
  const selectedAudio = selectedAssets
    .filter((a) => a.category === 'app_audio' && Boolean(a.url))
    .map((a) => ({ name: a.name, url: a.url }));

  const queries = buildCategoryAssetQueries(category);
  const fetchTasks: Promise<void>[] = [];
  const livePhotos = [...selectedPhotos];
  const liveIcons = [...selectedIcons];

  studioBus.emit('bot:progress', {
    botId: 'code',
    status: 'working',
    progress: 48,
    message: `Resolving Iconify icons & Wikimedia photos (5s cap)...`,
  });

  if (livePhotos.length < 3) {
    fetchTasks.push(
      searchWikimediaPhotos(queries.photoQuery, 4)
        .then((res) => {
          for (const item of res.items) {
            if (item.previewUrl) {
              livePhotos.push({ name: item.name, url: item.previewUrl });
            }
          }
        })
        .catch(() => {})
    );
  }

  if (liveIcons.length < 4) {
    fetchTasks.push(
      searchIconifyIcons(queries.iconQuery, 6)
        .then((res) => {
          for (const item of res.items) {
            if (item.previewUrl || item.url) {
              liveIcons.push({ name: item.name, url: item.previewUrl || item.url });
            }
          }
        })
        .catch(() => {})
    );
  }

  if (fetchTasks.length > 0) {
    await Promise.allSettled(fetchTasks);
  }

  await waitIfPaused(options.signal);

  // STRICT ISOLATION: Read ONLY appsSupabaseUrl and appsSupabaseAnonKey
  const appsSupabaseUrl = options.secrets.appsSupabaseUrl?.trim() ?? '';
  const appsSupabaseAnonKey = options.secrets.appsSupabaseAnonKey?.trim() ?? '';

  const resolvedAssets: ResolvedCommercialAssets = {
    photos: livePhotos.slice(0, 6),
    icons: liveIcons.slice(0, 8),
    audio: selectedAudio.slice(0, 4),
  };

  const now = Date.now();
  const indexHtml = buildCommercialAppHtml({
    appName,
    category,
    prompt: options.prompt,
    assets: resolvedAssets,
    appsSupabaseUrl,
    appsSupabaseAnonKey,
    activeRules,
  });

  const manifestJson = buildCommercialManifestJson(
    appName,
    category,
    selectedAssets,
    appsSupabaseUrl
  );

  await waitIfPaused(options.signal);

  const files: VirtualFile[] = [
    {
      path: 'index.html',
      language: 'html',
      content: indexHtml,
      updatedAt: now,
      generatedBy: 'code',
    },
    {
      path: 'assets/manifest.json',
      language: 'json',
      content: manifestJson,
      updatedAt: now,
      generatedBy: 'asset',
    },
  ];

  const injectedAssetsCount =
    resolvedAssets.photos.length +
    resolvedAssets.icons.length +
    resolvedAssets.audio.length;

  studioBus.emit('bot:progress', {
    botId: 'code',
    status: 'ready',
    progress: 100,
    message: `${appName} ready · ${injectedAssetsCount} UI assets wired`,
  });

  return {
    files,
    entryPath: 'index.html',
    appName,
    category,
    injectedAssetsCount,
    supabaseWired: Boolean(appsSupabaseUrl && appsSupabaseAnonKey),
  };
}
