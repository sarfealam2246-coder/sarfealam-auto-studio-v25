import { requestStudioAICompletion } from './aiRouter';
import { speakStudioReply, stopStudioSpeech } from './cloudTtsService';
import { studioBus } from './eventBus';
import { buildMemoryContext } from './memoryService';
import type {
  Language,
  StudioSecrets,
  UserMemoryRule,
  WorldState,
} from '../types/studio';

export interface BroadcastLine {
  id: string;
  speaker: 'Host A' | 'Host B';
  voice: 'Aoede' | 'Charon';
  text: string;
}

export interface GenerateBroadcastScriptOptions {
  topic: string;
  language: Language;
  secrets: StudioSecrets;
  memoryRules?: UserMemoryRule[];
}

export interface GeneratedBroadcastScript {
  topic: string;
  language: Language;
  lines: BroadcastLine[];
  providerUsed: string;
}

export interface PlayTwoVoiceBroadcastOptions {
  lines: BroadcastLine[];
  geminiKey?: string;
  ttsModel?: string;
  language?: Language;
  voiceSpeed?: number;
  onLineChange?: (index: number, line: BroadcastLine | null) => void;
  canvasEl?: HTMLCanvasElement | null;
  recordVideo?: boolean;
  onRecordingReady?: (blob: Blob, url: string) => void;
}

let activeBroadcastToken = 0;
let activeRecorder: MediaRecorder | null = null;
let activeRafId = 0;

function buildFallbackScript(topic: string, language: Language): BroadcastLine[] {
  const cleanTopic = topic.trim() || 'Sarfealam Auto-Studio Launch';

  if (language === 'hi') {
    return [
      {
        id: 'b-1',
        speaker: 'Host A',
        voice: 'Aoede',
        text: `नमस्ते दोस्तों! आज का सबसे बड़ा टेक अपडेट है — ${cleanTopic}!`,
      },
      {
        id: 'b-2',
        speaker: 'Host B',
        voice: 'Charon',
        text: `बिल्कुल सही कहा! मोबाइल पर ही इतनी तेज़ और स्मार्ट क्रिएशन पहले कभी नहीं देखी।`,
      },
      {
        id: 'b-3',
        speaker: 'Host A',
        voice: 'Aoede',
        text: `सबसे कमाल की बात है इसका ज़ीरो-शॉर्टकट डिज़ाइन — 3D गेम, कमर्शियल ऐप और वॉइस सब एक साथ!`,
      },
      {
        id: 'b-4',
        speaker: 'Host B',
        voice: 'Charon',
        text: `और ऊपर से रियल-टाइम प्रीव्यू और इंस्टेंट एक्सपोर्ट — यानी आइडिया से लॉन्च बस कुछ सेकंड में।`,
      },
      {
        id: 'b-5',
        speaker: 'Host A',
        voice: 'Aoede',
        text: `तो देर किस बात की? आज ही ${cleanTopic} को लाइव ट्राई करें!`,
      },
      {
        id: 'b-6',
        speaker: 'Host B',
        voice: 'Charon',
        text: `लाइक, शेयर और सब्सक्राइब ज़रूर करें — मिलते हैं अगले ब्रॉडकास्ट में!`,
      },
    ];
  }

  return [
    {
      id: 'b-1',
      speaker: 'Host A',
      voice: 'Aoede',
      text: `Welcome back! Today we are spotlighting ${cleanTopic} — built right on mobile!`,
    },
    {
      id: 'b-2',
      speaker: 'Host B',
      voice: 'Charon',
      text: `Honestly, the speed is unreal. Full interactive UI, real assets, and instant live preview in seconds.`,
    },
    {
      id: 'b-3',
      speaker: 'Host A',
      voice: 'Aoede',
      text: `And zero shortcuts — clean architecture, touch-ready controls, and crisp studio audio built in.`,
    },
    {
      id: 'b-4',
      speaker: 'Host B',
      voice: 'Charon',
      text: `Whether you are shipping a fintech wallet, a 3D world, or a viral short video, it runs seamlessly.`,
    },
    {
      id: 'b-5',
      speaker: 'Host A',
      voice: 'Aoede',
      text: `Ready to launch ${cleanTopic}? Tap play and test it live right now!`,
    },
    {
      id: 'b-6',
      speaker: 'Host B',
      voice: 'Charon',
      text: `Hit download to save this 9 by 16 reel, and we will catch you on the next broadcast!`,
    },
  ];
}

function parseDialogueLines(rawText: string): BroadcastLine[] {
  const trimmed = rawText.trim();
  const fenceMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fenceMatch ? fenceMatch[1].trim() : trimmed;

  const tryParse = (str: string): BroadcastLine[] | null => {
    try {
      const parsed: unknown = JSON.parse(str);
      const arr = Array.isArray(parsed)
        ? parsed
        : parsed &&
            typeof parsed === 'object' &&
            Array.isArray((parsed as { lines?: unknown }).lines)
          ? ((parsed as { lines: unknown[] }).lines as unknown[])
          : null;
      if (!arr) return null;

      const result: BroadcastLine[] = [];
      for (let i = 0; i < arr.length; i++) {
        const entry = arr[i];
        if (!entry || typeof entry !== 'object') continue;
        const obj = entry as Record<string, unknown>;
        const text = typeof obj.text === 'string' ? obj.text.trim() : '';
        if (!text) continue;
        const rawSpeaker = String(obj.speaker ?? '').toLowerCase();
        const isHostB =
          rawSpeaker.includes('b') ||
          rawSpeaker.includes('charon') ||
          (rawSpeaker === '' && i % 2 === 1);
        result.push({
          id: `b-${i + 1}`,
          speaker: isHostB ? 'Host B' : 'Host A',
          voice: isHostB ? 'Charon' : 'Aoede',
          text: text.slice(0, 220),
        });
      }
      return result.length >= 2 ? result.slice(0, 8) : null;
    } catch {
      return null;
    }
  };

  const direct = tryParse(candidate);
  if (direct) return direct;

  const start = candidate.indexOf('[');
  const end = candidate.lastIndexOf(']');
  if (start !== -1 && end > start) {
    const sliced = tryParse(candidate.slice(start, end + 1));
    if (sliced) return sliced;
  }

  const objStart = candidate.indexOf('{');
  const objEnd = candidate.lastIndexOf('}');
  if (objStart !== -1 && objEnd > objStart) {
    const sliced = tryParse(candidate.slice(objStart, objEnd + 1));
    if (sliced) return sliced;
  }

  return [];
}

function createMinimalRouterState(
  language: Language,
  secrets: StudioSecrets,
  memoryRules: UserMemoryRule[]
): WorldState {
  const now = Date.now();
  return {
    projectName: 'Broadcast Studio',
    language,
    mode: 'jarvis',
    targetEngine: 'auto',
    paused: false,
    liveActive: false,
    currentStage: '4. Controls',
    activePanel: 'none',
    displayMode: 'expanded',
    voicePersona: 'Aoede',
    voiceSpeed: 1.0,
    bots: {
      asset: { id: 'asset', label: 'Asset', status: 'idle', progress: 0, message: '', updatedAt: now },
      code: { id: 'code', label: 'Code', status: 'working', progress: 50, message: '', updatedAt: now },
      vision: { id: 'vision', label: 'Vision', status: 'idle', progress: 0, message: '', updatedAt: now },
      github: { id: 'github', label: 'GitHub', status: 'idle', progress: 0, message: '', updatedAt: now },
    },
    selectedAssets: [],
    files: [],
    memoryRules,
    messages: [],
    secrets,
    lastUpdated: now,
  };
}

export async function generateBroadcastScript(
  options: GenerateBroadcastScriptOptions
): Promise<GeneratedBroadcastScript> {
  const topic = options.topic.trim() || 'Sarfealam Auto-Studio Pro';
  const language = options.language;
  const memoryRules = options.memoryRules ?? [];

  studioBus.emit('bot:progress', {
    botId: 'code',
    status: 'working',
    progress: 30,
    message: `Scripting 2-Voice Broadcast (${topic})...`,
  });

  const memoryBlock = buildMemoryContext(memoryRules);
  const langLine =
    language === 'hi'
      ? 'Write punchy, energetic natural Hindi / Hinglish dialogue suitable for a 30-second vertical short video.'
      : 'Write punchy, high-energy English dialogue suitable for a 30-second vertical short video.';

  const systemPrompt = [
    'You are a top broadcast producer creating a 2-host short-form video script.',
    langLine,
    ...(memoryBlock ? [memoryBlock] : []),
    'Return STRICT JSON ONLY (no markdown fences) with this exact schema:',
    '{"lines":[{"speaker":"Host A","text":"..."},{"speaker":"Host B","text":"..."}]}',
    'Rules: Exactly 6 short alternating lines (Host A, Host B, Host A, Host B, Host A, Host B). Each line max 18 words, energetic and conversational.',
  ].join('\n');

  const userPrompt = `Create a 2-host broadcast short video script about: ${topic}`;

  try {
    const stateSnapshot = createMinimalRouterState(
      language,
      options.secrets,
      memoryRules
    );
    const completion = await requestStudioAICompletion(
      systemPrompt,
      userPrompt,
      stateSnapshot
    );

    if (completion.ok && completion.rawText) {
      const parsed = parseDialogueLines(completion.rawText);
      if (parsed.length >= 2) {
        studioBus.emit('bot:progress', {
          botId: 'code',
          status: 'ready',
          progress: 100,
          message: `Broadcast script ready (${parsed.length} lines · ${completion.providerUsed})`,
        });
        return {
          topic,
          language,
          lines: parsed,
          providerUsed: completion.providerUsed,
        };
      }
    }
  } catch {
    // Gracefully fall back to local script
  }

  const fallbackLines = buildFallbackScript(topic, language);
  studioBus.emit('bot:progress', {
    botId: 'code',
    status: 'ready',
    progress: 100,
    message: `Broadcast script ready (${fallbackLines.length} lines · Local)`,
  });

  return {
    topic,
    language,
    lines: fallbackLines,
    providerUsed: 'Local Studio Script',
  };
}

function wrapCanvasText(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number
): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let current = '';

  for (const word of words) {
    const test = current ? `${current} ${word}` : word;
    if (ctx.measureText(test).width <= maxWidth) {
      current = test;
    } else {
      if (current) lines.push(current);
      current = word;
    }
  }
  if (current) lines.push(current);
  return lines.slice(0, 6);
}

function renderBroadcastFrame(
  canvas: HTMLCanvasElement,
  state: {
    topic: string;
    line: BroadcastLine | null;
    lineIndex: number;
    totalLines: number;
    timeSec: number;
    isPlaying: boolean;
  }
): void {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const w = canvas.width;
  const h = canvas.height;
  const isHostA = !state.line || state.line.speaker === 'Host A';

  // Background studio gradient
  const bgGrad = ctx.createLinearGradient(0, 0, w, h);
  if (isHostA) {
    bgGrad.addColorStop(0, '#09152B');
    bgGrad.addColorStop(0.55, '#112244');
    bgGrad.addColorStop(1, '#0F172A');
  } else {
    bgGrad.addColorStop(0, '#1B1033');
    bgGrad.addColorStop(0.55, '#2A1447');
    bgGrad.addColorStop(1, '#0F172A');
  }
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, w, h);

  // Subtle ambient glow circles
  const glowA = ctx.createRadialGradient(w * 0.25, h * 0.3, 12, w * 0.25, h * 0.3, w * 0.55);
  glowA.addColorStop(0, isHostA ? 'rgba(56, 189, 248, 0.30)' : 'rgba(56, 189, 248, 0.08)');
  glowA.addColorStop(1, 'rgba(56, 189, 248, 0)');
  ctx.fillStyle = glowA;
  ctx.fillRect(0, 0, w, h);

  const glowB = ctx.createRadialGradient(w * 0.75, h * 0.3, 12, w * 0.75, h * 0.3, w * 0.55);
  glowB.addColorStop(0, !isHostA ? 'rgba(236, 72, 153, 0.32)' : 'rgba(236, 72, 153, 0.08)');
  glowB.addColorStop(1, 'rgba(236, 72, 153, 0)');
  ctx.fillStyle = glowB;
  ctx.fillRect(0, 0, w, h);

  // Top Broadcast Header Pill
  ctx.fillStyle = 'rgba(15, 23, 42, 0.78)';
  ctx.beginPath();
  ctx.roundRect(18, 20, w - 36, 40, 20);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.16)';
  ctx.lineWidth = 1.2;
  ctx.stroke();

  ctx.fillStyle = '#38BDF8';
  ctx.font = '700 11px -apple-system, BlinkMacSystemFont, sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('9:16 BROADCAST STUDIO', 34, 44);

  ctx.fillStyle = '#E2E8F0';
  ctx.textAlign = 'right';
  ctx.font = '700 11px ui-monospace, Menlo, monospace';
  ctx.fillText(
    state.totalLines > 0
      ? `${Math.min(state.lineIndex + 1, state.totalLines)} / ${state.totalLines}`
      : 'READY',
    w - 34,
    44
  );

  // Topic Banner
  ctx.textAlign = 'center';
  ctx.fillStyle = '#F8FAFC';
  ctx.font = '800 15px -apple-system, BlinkMacSystemFont, sans-serif';
  const topicText =
    state.topic.length > 34 ? `${state.topic.slice(0, 33)}…` : state.topic;
  ctx.fillText(topicText, w / 2, 92);

  // Dual Host Avatars (Host A · Aoede vs Host B · Charon)
  const hosts = [
    {
      label: 'Host A',
      sub: 'Aoede',
      x: w * 0.3,
      y: 185,
      color: '#0EA5E9',
      active: state.isPlaying && isHostA,
    },
    {
      label: 'Host B',
      sub: 'Charon',
      x: w * 0.7,
      y: 185,
      color: '#EC4899',
      active: state.isPlaying && !isHostA,
    },
  ];

  hosts.forEach((host) => {
    const pulse = host.active ? Math.sin(state.timeSec * 8) * 5 : 0;
    if (host.active) {
      ctx.beginPath();
      ctx.arc(host.x, host.y, 44 + pulse, 0, Math.PI * 2);
      ctx.strokeStyle = host.color;
      ctx.lineWidth = 3;
      ctx.stroke();
    }

    ctx.beginPath();
    ctx.arc(host.x, host.y, 34, 0, Math.PI * 2);
    ctx.fillStyle = host.active ? host.color : 'rgba(30, 41, 59, 0.9)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = '800 15px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(host.label === 'Host A' ? 'A' : 'B', host.x, host.y + 5);

    ctx.font = '700 12px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.fillStyle = host.active ? '#FFFFFF' : '#94A3B8';
    ctx.fillText(host.label, host.x, host.y + 56);

    ctx.font = '600 10px ui-monospace, Menlo, monospace';
    ctx.fillStyle = host.active ? host.color : '#64748B';
    ctx.fillText(host.sub, host.x, host.y + 72);
  });

  // Live Animated Audio Visualizer Bars
  const barCount = 26;
  const barZoneW = w - 56;
  const barStep = barZoneW / barCount;
  const barBaseY = 335;
  for (let i = 0; i < barCount; i++) {
    const norm = Math.abs(i - barCount / 2) / (barCount / 2);
    const wave = state.isPlaying
      ? Math.abs(Math.sin(state.timeSec * 9.2 + i * 0.55) * Math.cos(state.timeSec * 4.1 + i * 0.3))
      : 0.08;
    const barH = 10 + (1 - norm * 0.55) * wave * 58;
    const bx = 28 + i * barStep;

    ctx.fillStyle = isHostA ? '#38BDF8' : '#F472B6';
    ctx.beginPath();
    ctx.roundRect(bx + 2, barBaseY - barH / 2, Math.max(4, barStep - 4), barH, 3);
    ctx.fill();
  }

  // Animated Caption Card
  const cardX = 20;
  const cardY = 390;
  const cardW = w - 40;
  const cardH = 188;

  ctx.fillStyle = 'rgba(15, 23, 42, 0.86)';
  ctx.beginPath();
  ctx.roundRect(cardX, cardY, cardW, cardH, 20);
  ctx.fill();
  ctx.strokeStyle = isHostA ? 'rgba(56, 189, 248, 0.5)' : 'rgba(244, 114, 182, 0.5)';
  ctx.lineWidth = 1.6;
  ctx.stroke();

  if (state.line) {
    // Speaker Pill inside caption card
    ctx.fillStyle = isHostA ? '#0EA5E9' : '#EC4899';
    ctx.beginPath();
    ctx.roundRect(cardX + 16, cardY + 16, 126, 24, 12);
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'left';
    ctx.font = '800 11px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.fillText(`${state.line.speaker} · ${state.line.voice}`, cardX + 26, cardY + 32);

    ctx.fillStyle = '#F8FAFC';
    ctx.font = '700 17px -apple-system, BlinkMacSystemFont, sans-serif';
    const wrapped = wrapCanvasText(ctx, state.line.text, cardW - 34);
    wrapped.forEach((lineStr, idx) => {
      ctx.fillText(lineStr, cardX + 18, cardY + 68 + idx * 24);
    });
  } else {
    ctx.fillStyle = '#CBD5E1';
    ctx.textAlign = 'center';
    ctx.font = '700 15px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.fillText('Tap Play to start 2-Voice Broadcast', w / 2, cardY + 98);
  }

  // Progress bar at bottom
  const progPct =
    state.totalLines > 0
      ? Math.min(1, (state.lineIndex + (state.isPlaying ? 0.5 : 0)) / state.totalLines)
      : 0;
  ctx.fillStyle = 'rgba(255, 255, 255, 0.14)';
  ctx.beginPath();
  ctx.roundRect(24, h - 32, w - 48, 6, 3);
  ctx.fill();

  ctx.fillStyle = isHostA ? '#38BDF8' : '#F472B6';
  ctx.beginPath();
  ctx.roundRect(24, h - 32, Math.max(8, (w - 48) * progPct), 6, 3);
  ctx.fill();
}

export function stopTwoVoiceBroadcast(): void {
  activeBroadcastToken += 1;
  stopStudioSpeech();
  if (activeRafId) {
    cancelAnimationFrame(activeRafId);
    activeRafId = 0;
  }
  if (activeRecorder && activeRecorder.state !== 'inactive') {
    try {
      activeRecorder.stop();
    } catch {
      // ignore
    }
  }
  activeRecorder = null;
}

export function downloadBroadcastBlob(blob: Blob, filename = 'sarfealam-broadcast-9x16.webm'): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export async function playTwoVoiceBroadcast(
  options: PlayTwoVoiceBroadcastOptions
): Promise<{ completed: boolean; recordedBlob?: Blob }> {
  stopTwoVoiceBroadcast();
  const token = ++activeBroadcastToken;
  const lines = options.lines ?? [];
  if (lines.length === 0) {
    return { completed: false };
  }

  const canvas = options.canvasEl ?? null;
  if (canvas) {
    canvas.width = 360;
    canvas.height = 640;
  }

  let currentIndex = 0;
  let currentLine: BroadcastLine | null = lines[0];
  let isPlaying = true;
  const startMs = performance.now();

  const topicLabel = lines[0]?.text.slice(0, 32) || 'Sarfealam Broadcast';

  // Start optional MediaRecorder (video/webm) on the 9:16 HTML5 Canvas
  const recordedChunks: BlobPart[] = [];
  let recordedBlobPromise: Promise<Blob | undefined> = Promise.resolve(undefined);

  if (
    canvas &&
    options.recordVideo &&
    typeof MediaRecorder !== 'undefined' &&
    typeof canvas.captureStream === 'function'
  ) {
    try {
      const stream = canvas.captureStream(30);
      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : MediaRecorder.isTypeSupported('video/webm')
          ? 'video/webm'
          : '';
      const recorder = mimeType
        ? new MediaRecorder(stream, { mimeType })
        : new MediaRecorder(stream);

      activeRecorder = recorder;
      recorder.ondataavailable = (evt) => {
        if (evt.data && evt.data.size > 0) {
          recordedChunks.push(evt.data);
        }
      };
      recordedBlobPromise = new Promise<Blob | undefined>((resolve) => {
        recorder.onstop = () => {
          const blob =
            recordedChunks.length > 0
              ? new Blob(recordedChunks, { type: mimeType || 'video/webm' })
              : undefined;
          resolve(blob);
        };
      });
      recorder.start(250);
    } catch {
      // Ignore MediaRecorder unavailability gracefully
    }
  }

  // Canvas animation loop
  if (canvas) {
    const animateCanvas = () => {
      if (token !== activeBroadcastToken) return;
      renderBroadcastFrame(canvas, {
        topic: topicLabel,
        line: currentLine,
        lineIndex: currentIndex,
        totalLines: lines.length,
        timeSec: (performance.now() - startMs) / 1000,
        isPlaying,
      });
      if (isPlaying) {
        activeRafId = requestAnimationFrame(animateCanvas);
      }
    };
    activeRafId = requestAnimationFrame(animateCanvas);
  }

  const speed = Math.max(1.0, Math.min(1.5, options.voiceSpeed ?? 1.05));
  const language: Language = options.language ?? 'en';

  for (let i = 0; i < lines.length; i++) {
    if (token !== activeBroadcastToken) break;
    const line = lines[i];
    currentIndex = i;
    currentLine = line;
    options.onLineChange?.(i, line);

    const voicePersona = line.speaker === 'Host B' ? 'Charon' : 'Aoede';

    const used = await speakStudioReply(line.text, {
      geminiKey: options.geminiKey,
      ttsModel: options.ttsModel,
      voicePersona,
      voiceSpeed: speed,
      language,
    });

    if (token !== activeBroadcastToken) break;

    // If neither Cloud TTS nor browser speechSynthesis spoke (e.g. headless browser),
    // pace the caption rhythm cleanly so the 9:16 video still animates smoothly.
    if (used === 'none') {
      const approxMs = Math.max(1400, Math.min(3400, line.text.length * 48));
      await new Promise<void>((r) => window.setTimeout(r, approxMs));
    } else {
      await new Promise<void>((r) => window.setTimeout(r, 240));
    }
  }

  isPlaying = false;
  if (activeRafId) {
    cancelAnimationFrame(activeRafId);
    activeRafId = 0;
  }

  if (canvas && token === activeBroadcastToken) {
    renderBroadcastFrame(canvas, {
      topic: topicLabel,
      line: lines[lines.length - 1] ?? null,
      lineIndex: lines.length - 1,
      totalLines: lines.length,
      timeSec: (performance.now() - startMs) / 1000,
      isPlaying: false,
    });
  }

  let recordedBlob: Blob | undefined;
  if (activeRecorder && activeRecorder.state !== 'inactive') {
    try {
      activeRecorder.stop();
    } catch {
      // ignore
    }
    recordedBlob = await recordedBlobPromise;
    activeRecorder = null;
  }

  const completed = token === activeBroadcastToken;
  if (completed) {
    options.onLineChange?.(-1, null);
    if (recordedBlob && options.onRecordingReady) {
      const blobUrl = URL.createObjectURL(recordedBlob);
      options.onRecordingReady(recordedBlob, blobUrl);
    }
  }

  return { completed, recordedBlob };
}
