import type { Dispatch, SetStateAction } from 'react';
import { studioBus } from './eventBus';
import {
  addMemoryRuleUnique,
  detectMemorySaveIntent,
  loadMemoryRules,
} from './memoryService';
import {
  pauseStudioPipeline,
  resumeStudioPipeline,
  setStudioPipelineStage,
} from './pipelineController';
import {
  inferDepartmentsFromQuery,
  VALID_ASSET_CATEGORIES,
} from './assetHunterService';
import type {
  AssetCategory,
  DisplayMode,
  Language,
  PanelId,
  StudioMode,
  TargetEngine,
  VirtualFile,
  WorldState,
} from '../types/studio';

export type StudioStageNumber = 1 | 2 | 3 | 4 | 5;

export type UIAction =
  | { type: 'open_panel'; panel: PanelId }
  | { type: 'set_display_mode'; mode: DisplayMode }
  | { type: 'set_language'; language: Language }
  | { type: 'set_mode'; mode: StudioMode }
  | { type: 'set_engine'; engine: TargetEngine }
  | { type: 'select_file'; path: string }
  | { type: 'set_stage'; stage: StudioStageNumber }
  | { type: 'save_memory'; rule: string }
  | { type: 'set_paused'; paused: boolean }
  | { type: 'search_assets'; query: string; categories?: AssetCategory[] }
  | { type: 'select_asset'; target: string; decision: 'keep' | 'reject' }
  | { type: 'clone_repo'; repoUrl: string }
  | { type: 'build_3d_game'; theme?: string }
  | { type: 'build_commercial_app'; category?: string; prompt?: string }
  | { type: 'create_broadcast'; topic: string }
  | { type: 'spawn_sub_bot'; role: string; task: string }
  | { type: 'fetch_any_api'; name: string; url: string }
  | { type: 'test_apis' };

export const STAGE_LABELS: Record<StudioStageNumber, string> = {
  1: '1. Shell',
  2: '2. Assets',
  3: '3. Logic',
  4: '4. Controls',
  5: '5. Package',
};

const VALID_PANELS = new Set<PanelId>([
  'none',
  'secrets',
  'code',
  'vault',
  'admin',
  'camera',
]);

const VALID_DISPLAY_MODES = new Set<DisplayMode>([
  'expanded',
  'floating',
  'collapsed',
]);

const VALID_LANGUAGES = new Set<Language>(['en', 'hi']);

const VALID_MODES = new Set<StudioMode>(['jarvis', 'manual']);

const VALID_ENGINES = new Set<TargetEngine>([
  'auto',
  'capacitor',
  'godot4',
  'flutter',
  'unity',
]);

const PANEL_NAMES: Record<PanelId, string> = {
  none: 'Closed Panel',
  secrets: 'Opened Secrets',
  code: 'Opened Code',
  vault: 'Opened Vault',
  admin: 'Opened Admin',
  camera: 'Opened Camera',
};

const DISPLAY_NAMES: Record<DisplayMode, string> = {
  expanded: 'Display → Expanded',
  floating: 'Display → Floating',
  collapsed: 'Display → Collapsed',
};

const ENGINE_NAMES: Record<TargetEngine, string> = {
  auto: 'Engine → Auto',
  capacitor: 'Engine → Capacitor',
  godot4: 'Engine → Godot 4',
  flutter: 'Engine → Flutter',
  unity: 'Engine → Unity',
};

function resolveFileMatch(
  candidate: string,
  files: VirtualFile[]
): string | null {
  const cleaned = candidate.trim().replace(/^\/+/, '').toLowerCase();
  if (!cleaned) return null;

  const exact = files.find((f) => f.path.toLowerCase() === cleaned);
  if (exact) return exact.path;

  const bySuffix = files.find((f) => {
    const lower = f.path.toLowerCase();
    const base = lower.split('/').pop() ?? lower;
    return base === cleaned || lower.endsWith(`/${cleaned}`);
  });
  return bySuffix ? bySuffix.path : null;
}

export function sanitizeUIActions(
  raw: unknown,
  files: VirtualFile[]
): UIAction[] {
  if (!Array.isArray(raw)) return [];
  const valid: UIAction[] = [];

  for (const item of raw) {
    if (!item || typeof item !== 'object') continue;
    const obj = item as Record<string, unknown>;
    const type = obj.type;

    if (
      type === 'open_panel' &&
      typeof obj.panel === 'string' &&
      VALID_PANELS.has(obj.panel as PanelId)
    ) {
      valid.push({ type: 'open_panel', panel: obj.panel as PanelId });
    } else if (
      type === 'set_display_mode' &&
      typeof obj.mode === 'string' &&
      VALID_DISPLAY_MODES.has(obj.mode as DisplayMode)
    ) {
      valid.push({ type: 'set_display_mode', mode: obj.mode as DisplayMode });
    } else if (
      type === 'set_language' &&
      typeof obj.language === 'string' &&
      VALID_LANGUAGES.has(obj.language as Language)
    ) {
      valid.push({ type: 'set_language', language: obj.language as Language });
    } else if (
      type === 'set_mode' &&
      typeof obj.mode === 'string' &&
      VALID_MODES.has(obj.mode as StudioMode)
    ) {
      valid.push({ type: 'set_mode', mode: obj.mode as StudioMode });
    } else if (
      type === 'set_engine' &&
      typeof obj.engine === 'string' &&
      VALID_ENGINES.has(obj.engine as TargetEngine)
    ) {
      valid.push({ type: 'set_engine', engine: obj.engine as TargetEngine });
    } else if (type === 'select_file' && typeof obj.path === 'string') {
      const matched = resolveFileMatch(obj.path, files);
      if (matched) {
        valid.push({ type: 'select_file', path: matched });
      }
    } else if (type === 'set_stage') {
      const num = Number(obj.stage);
      if (num === 1 || num === 2 || num === 3 || num === 4 || num === 5) {
        valid.push({ type: 'set_stage', stage: num });
      }
    } else if (
      type === 'save_memory' &&
      typeof obj.rule === 'string' &&
      obj.rule.trim().length >= 3
    ) {
      valid.push({ type: 'save_memory', rule: obj.rule.trim() });
    } else if (type === 'set_paused' && typeof obj.paused === 'boolean') {
      valid.push({ type: 'set_paused', paused: obj.paused });
    } else if (type === 'search_assets') {
      const rawQuery = typeof obj.query === 'string' ? obj.query.trim() : '';
      const rawCats = Array.isArray(obj.categories)
        ? obj.categories.filter(
            (c): c is AssetCategory =>
              typeof c === 'string' &&
              VALID_ASSET_CATEGORIES.has(c as AssetCategory)
          )
        : undefined;
      const categories =
        rawCats && rawCats.length > 0 ? Array.from(new Set(rawCats)) : undefined;
      if (rawQuery.length > 0 || (categories && categories.length > 0)) {
        valid.push({
          type: 'search_assets',
          query: rawQuery,
          categories,
        });
      }
    } else if (
      type === 'select_asset' &&
      typeof obj.target === 'string' &&
      obj.target.trim().length > 0 &&
      (obj.decision === 'keep' || obj.decision === 'reject')
    ) {
      valid.push({
        type: 'select_asset',
        target: obj.target.trim(),
        decision: obj.decision,
      });
    } else if (
      type === 'clone_repo' &&
      typeof obj.repoUrl === 'string' &&
      obj.repoUrl.trim().length >= 3
    ) {
      valid.push({
        type: 'clone_repo',
        repoUrl: obj.repoUrl.trim(),
      });
    } else if (type === 'build_3d_game') {
      const theme =
        typeof obj.theme === 'string' && obj.theme.trim().length > 0
          ? obj.theme.trim().slice(0, 60)
          : undefined;
      valid.push({
        type: 'build_3d_game',
        ...(theme ? { theme } : {}),
      });
    } else if (type === 'build_commercial_app') {
      const category =
        typeof obj.category === 'string' && obj.category.trim().length > 0
          ? obj.category.trim().slice(0, 40)
          : undefined;
      const prompt =
        typeof obj.prompt === 'string' && obj.prompt.trim().length > 0
          ? obj.prompt.trim().slice(0, 140)
          : undefined;
      valid.push({
        type: 'build_commercial_app',
        ...(category ? { category } : {}),
        ...(prompt ? { prompt } : {}),
      });
    } else if (
      type === 'create_broadcast' &&
      typeof obj.topic === 'string' &&
      obj.topic.trim().length > 0
    ) {
      valid.push({
        type: 'create_broadcast',
        topic: obj.topic.trim().slice(0, 100),
      });
    } else if (
      type === 'spawn_sub_bot' &&
      typeof obj.role === 'string' &&
      obj.role.trim().length > 0 &&
      typeof obj.task === 'string' &&
      obj.task.trim().length > 0
    ) {
      valid.push({
        type: 'spawn_sub_bot',
        role: obj.role.trim().slice(0, 60),
        task: obj.task.trim().slice(0, 220),
      });
    } else if (
      type === 'fetch_any_api' &&
      typeof obj.url === 'string' &&
      /^https?:\/\/\S+/i.test(obj.url.trim())
    ) {
      const cleanUrl = obj.url.trim();
      const rawName = typeof obj.name === 'string' ? obj.name.trim() : '';
      let fallbackName = 'custom-api';
      try {
        fallbackName = new URL(cleanUrl).hostname.replace(/^www\./, '');
      } catch {
        // fallback
      }
      valid.push({
        type: 'fetch_any_api',
        name: (rawName || fallbackName).slice(0, 64),
        url: cleanUrl,
      });
    } else if (type === 'test_apis') {
      valid.push({ type: 'test_apis' });
    }
  }

  return deduplicateActions(valid);
}

export function deduplicateActions(actions: UIAction[]): UIAction[] {
  const byType = new Map<UIAction['type'], UIAction>();
  for (const action of actions) {
    byType.set(action.type, action);
  }
  return Array.from(byType.values());
}

export function detectLocalUIActions(
  input: string,
  state: WorldState
): UIAction[] {
  const text = input.trim();
  if (!text) return [];
  const lower = text.toLowerCase();
  const actions: UIAction[] = [];

  // 0. Direct Live API Keys Check matching (EN + HI/Hinglish phonetic voice-to-text)
  const isApiCheckIntent =
    /\b(test\s+(?:all\s+|my\s+)?apis?|apis?\s+(?:test|check)|api\s+check|check\s+(?:all\s+|my\s+)?apis?|nvidia\s+check|check\s+nvidia|in\s+media\s+(?:check|test)|groq\s+check|check\s+groq|gemini\s+check|check\s+gemini|openrouter\s+check|cohere\s+check|check\s+(?:all\s+|my\s+)?(?:api\s+)?keys?|test\s+(?:all\s+|my\s+)?(?:api\s+)?keys?|keys?\s+(?:check|test)|verify\s+(?:all\s+|my\s+)?(?:api\s+)?keys?)\b/i.test(
      lower
    ) ||
    /(एपीआई\s*(?:चेक|टेस्ट)|एपी\s*की\s*(?:चेक|टेस्ट)|इन\s*मीडिया\s*(?:चेक|टेस्ट)|ग्रोक?\s*(?:चेक|टेस्ट)|की\s*(?:चेक|टेस्ट))/.test(
      text
    );

  if (isApiCheckIntent) {
    actions.push({ type: 'test_apis' });
  }

  // 1. Panel matching (EN + HI/Hinglish) — NEVER auto-open Secrets on API check intent
  if (
    !isApiCheckIntent &&
    (/\b(open|show|kholo|khol|edit|manage)\b.*\b(secrets?|api\s*keys?|keys?)\b/i.test(
      lower
    ) ||
      /\b(secrets?|api\s*keys?)\b.*\b(kholo|khol|dikhao|open|panel)\b/i.test(
        lower
      ) ||
      lower === 'secrets')
  ) {
    actions.push({ type: 'open_panel', panel: 'secrets' });
  } else if (
    /\b(open|show|kholo|khol)\b.*\b(code|editor)\b/i.test(lower) ||
    /\b(code|editor)\b.*\b(kholo|khol|dikhao|open|panel)\b/i.test(lower) ||
    lower === 'code'
  ) {
    actions.push({ type: 'open_panel', panel: 'code' });
  } else if (
    /\b(open|show|kholo|khol)\b.*\b(vault|assets?)\b/i.test(lower) ||
    /\b(vault)\b.*\b(kholo|khol|dikhao|open|panel)\b/i.test(lower) ||
    lower === 'vault'
  ) {
    actions.push({ type: 'open_panel', panel: 'vault' });
  } else if (
    /\b(open|show|kholo|khol)\b.*\b(camera|vision)\b/i.test(lower) ||
    /\b(camera|vision)\b.*\b(kholo|khol|dikhao|open|panel)\b/i.test(lower) ||
    lower === 'camera'
  ) {
    actions.push({ type: 'open_panel', panel: 'camera' });
  } else if (
    /\b(open|show|kholo|khol)\b.*\b(admin)\b/i.test(lower) ||
    /\b(admin)\b.*\b(kholo|khol|dikhao|open|panel)\b/i.test(lower) ||
    lower === 'admin'
  ) {
    actions.push({ type: 'open_panel', panel: 'admin' });
  } else if (
    /\b(close\s+panel|close\s+sheet|panel\s+band|band\s+karo|panel\s+hatao|hide\s+panel)\b/i.test(
      lower
    )
  ) {
    actions.push({ type: 'open_panel', panel: 'none' });
  }

  // 2. Display mode matching
  if (
    /\b(expand\s+display|display\s+expand|display\s+bada|full\s+display|show\s+display)\b/i.test(
      lower
    )
  ) {
    actions.push({ type: 'set_display_mode', mode: 'expanded' });
  } else if (
    /\b(float\s+display|floating\s+display|display\s+float|mini\s+display|pip\s+display|pip\s+mode)\b/i.test(
      lower
    )
  ) {
    actions.push({ type: 'set_display_mode', mode: 'floating' });
  } else if (
    /\b(collapse\s+display|display\s+collapse|hide\s+display|minimize\s+display|display\s+chhota|display\s+band)\b/i.test(
      lower
    )
  ) {
    actions.push({ type: 'set_display_mode', mode: 'collapsed' });
  }

  // 3. Language matching
  if (
    /\b(hindi|hinglish)\b/i.test(lower) ||
    text.includes('हिंदी') ||
    text.includes('हिन्दी') ||
    text.includes('हिं')
  ) {
    actions.push({ type: 'set_language', language: 'hi' });
  } else if (/\b(english|angrezi)\b/i.test(lower)) {
    actions.push({ type: 'set_language', language: 'en' });
  }

  // 4. Studio mode matching
  if (/\b(manual\s+mode|switch\s+to\s+manual|mode\s+manual)\b/i.test(lower)) {
    actions.push({ type: 'set_mode', mode: 'manual' });
  } else if (
    /\b(jarvis\s+mode|switch\s+to\s+jarvis|mode\s+jarvis)\b/i.test(lower)
  ) {
    actions.push({ type: 'set_mode', mode: 'jarvis' });
  }

  // 5. Target engine matching
  if (/\b(engine\s+unity|unity\s+engine|set\s+unity|switch\s+to\s+unity)\b/i.test(lower)) {
    actions.push({ type: 'set_engine', engine: 'unity' });
  } else if (
    /\b(engine\s+godot4?|godot\s*4?\s+engine|set\s+godot4?|switch\s+to\s+godot4?)\b/i.test(
      lower
    )
  ) {
    actions.push({ type: 'set_engine', engine: 'godot4' });
  } else if (
    /\b(engine\s+flutter|flutter\s+engine|set\s+flutter|switch\s+to\s+flutter)\b/i.test(
      lower
    )
  ) {
    actions.push({ type: 'set_engine', engine: 'flutter' });
  } else if (
    /\b(engine\s+capacitor|capacitor\s+engine|set\s+capacitor|switch\s+to\s+capacitor)\b/i.test(
      lower
    )
  ) {
    actions.push({ type: 'set_engine', engine: 'capacitor' });
  } else if (
    /\b(engine\s+auto|auto\s+engine|switch\s+to\s+auto\s+engine)\b/i.test(lower)
  ) {
    actions.push({ type: 'set_engine', engine: 'auto' });
  }

  // 6. Stage matching
  const stageMatch = lower.match(/\bstage\s*([1-5])\b/i);
  if (stageMatch) {
    const stageNum = Number(stageMatch[1]) as StudioStageNumber;
    actions.push({ type: 'set_stage', stage: stageNum });
  }

  // 7. File path matching from state.files
  for (const file of state.files) {
    const fullLower = file.path.toLowerCase();
    const baseLower = fullLower.split('/').pop() ?? fullLower;
    if (lower.includes(fullLower) || (baseLower.length >= 4 && lower.includes(baseLower))) {
      actions.push({ type: 'select_file', path: file.path });
      break;
    }
  }

  // 8. Permanent memory save intent matching (EN + HI/Hinglish)
  const memoryRule = detectMemorySaveIntent(text);
  if (memoryRule) {
    actions.push({ type: 'save_memory', rule: memoryRule });
  }

  // 9. Cooperative Pause / Resume intent matching (EN + HI/Hinglish)
  if (
    /\b(resume|continue|unpause|aage\s+badho|chalu\s+karo|jaari\s+rakho)\b/i.test(
      lower
    ) ||
    text.includes('आगे बढ़ो') ||
    text.includes('जारी रखो')
  ) {
    actions.push({ type: 'set_paused', paused: false });
  } else if (
    /\b(pause|ruko|ruk\s+jao|roko|hold|hold\s+on)\b/i.test(lower) ||
    text.includes('रुको') ||
    text.includes('रोको')
  ) {
    actions.push({ type: 'set_paused', paused: true });
  }

  // 10. Department-Scoped Asset Hunt matching (EN + HI/Hinglish)
  const detectAssetSearch = (
    raw: string
  ): { query: string; categories?: AssetCategory[] } | null => {
    const trimmed = raw.trim();
    const patterns: RegExp[] = [
      /^(?:vault\s+search|asset\s+search|search\s+vault|hunt\s+assets?|find\s+assets?|search\s+assets?)\s*[:\-]?\s*(.+)$/i,
      /^(?:find|search|hunt|get|fetch|lookup|look\s+for)\s+(?:me\s+)?(?:some\s+)?(.+?)\s*(?:assets?|models?|3d\s+models?|from\s+vault|in\s+vault)?$/i,
      /^(.+?)\s+(?:assets?|models?)?\s*(?:dhoondo|dhundo|khojo|talash\s+karo|search\s+karo|nikalo|lao)$/i,
      /^(.+?)\s+(?:ढूंढो|खोजो|लाओ)$/i,
    ];

    const assetTriggerSignal =
      /\b(vault\s+search|asset|assets|dhoondo|dhundo|khojo|hunt|iconify|icons?|wikimedia|photos?|sfx|skybox|hdri|pbr|textures?|vehicles?|cars?|trucks?|bikes?|weapons?|guns?|swords?|characters?|zombies?|village|houses?|trees?|buildings?|models?)\b/i.test(
        trimmed
      ) || /(ढूंढो|खोजो|लाओ|गाड़ी|ट्रक|कार|आइकन|फोटो|तस्वीर)/.test(trimmed);

    if (!assetTriggerSignal) return null;

    // Avoid hijacking API skill fetches or raw URL commands
    if (/\b(?:fetch|call|test)\s+api\b/i.test(trimmed) || /https?:\/\//i.test(trimmed)) {
      return null;
    }

    // Avoid hijacking pure "open vault" / "show assets" panel commands
    if (/^(open|show|kholo|khol)\s+(the\s+)?(vault|assets?)$/i.test(trimmed)) {
      return null;
    }

    for (const re of patterns) {
      const m = trimmed.match(re);
      if (m && m[1]) {
        const cleaned = m[1]
          .replace(
            /\b(assets?|models?|3d|from\s+vault|in\s+vault|vault|please|plz|zara|mujhe|mere\s+liye)\b/gi,
            ' '
          )
          .replace(/\s+/g, ' ')
          .trim();
        if (cleaned.length >= 2) {
          return {
            query: cleaned,
            categories: inferDepartmentsFromQuery(cleaned),
          };
        }
      }
    }
    return null;
  };

  const assetSearch = detectAssetSearch(text);
  if (assetSearch) {
    actions.push({ type: 'open_panel', panel: 'vault' });
    actions.push({
      type: 'search_assets',
      query: assetSearch.query,
      categories: assetSearch.categories,
    });
  }

  // 11. Voice & Tap Asset Keep / Reject matching (EN + HI/Hinglish)
  const detectAssetSelection = (
    raw: string
  ): { target: string; decision: 'keep' | 'reject' } | null => {
    const trimmed = raw.trim();
    const low = trimmed.toLowerCase();

    const ordinalMap: Record<string, string> = {
      first: '1',
      '1st': '1',
      one: '1',
      pehla: '1',
      pehle: '1',
      pahla: '1',
      पहला: '1',
      पहले: '1',
      second: '2',
      '2nd': '2',
      two: '2',
      dusra: '2',
      doosra: '2',
      dusre: '2',
      दूसरा: '2',
      दूसरे: '2',
      third: '3',
      '3rd': '3',
      three: '3',
      teesra: '3',
      tisra: '3',
      तीसरा: '3',
      fourth: '4',
      '4th': '4',
      four: '4',
      chautha: '4',
      चौथा: '4',
      fifth: '5',
      '5th': '5',
      five: '5',
      paanchwa: '5',
      panchwa: '5',
      last: 'last',
      aakhri: 'last',
      akhiri: 'last',
      all: 'all',
      sab: 'all',
      sabhi: 'all',
      saare: 'all',
      सब: 'all',
      सभी: 'all',
    };

    const normalizeTarget = (token: string): string | null => {
      const cleaned = token
        .trim()
        .toLowerCase()
        .replace(/^#/, '')
        .replace(/\b(wala|wali|wale|number|no\.?|asset|item|one)\b/gi, '')
        .trim();
      if (!cleaned) return null;
      if (ordinalMap[cleaned]) return ordinalMap[cleaned];
      if (/^\d{1,2}$/.test(cleaned)) return cleaned;
      return null;
    };

    // EN prefix form: "keep first", "keep 1", "keep #2", "keep all", "reject second", "remove 3"
    const enMatch = low.match(
      /^(keep|select|save|pick|reject|remove|drop|skip|discard)\s+(?:the\s+)?(?:asset\s+|item\s+|number\s+|#)?([a-z0-9]+(?:\s+wala)?)$/i
    );
    if (enMatch) {
      const verb = enMatch[1];
      const decision: 'keep' | 'reject' =
        /^(keep|select|save|pick)$/i.test(verb) ? 'keep' : 'reject';
      const target = normalizeTarget(enMatch[2]);
      if (target) {
        return { target, decision };
      }
    }

    // HI/Hinglish suffix form: "pehle wala rakho", "dusra hatao", "1 rakho", "sab rakho", "पहला रखो", "दूसरा हटाओ"
    const hiMatch = trimmed.match(
      /^(.+?)\s+(rakho|rakh\s+lo|le\s+lo|chuno|keep\s+karo|select\s+karo|hatao|hata\s+do|nikalo|nikal\s+do|chhodo|reject\s+karo|रखो|रख\s+लो|चुनो|हटाओ|हटा\s+दो|निकालो)$/i
    );
    if (hiMatch) {
      const rawTarget = hiMatch[1];
      const verb = hiMatch[2].toLowerCase();
      const decision: 'keep' | 'reject' =
        /(rakho|rakh|le\s+lo|chuno|keep|select|रखो|रख|चुनो)/i.test(verb)
          ? 'keep'
          : 'reject';
      const target = normalizeTarget(rawTarget);
      if (target) {
        return { target, decision };
      }
    }

    // Explicit named asset form: "keep asset truck", "reject asset sunset"
    const namedMatch = low.match(
      /^(keep|reject|remove)\s+(?:the\s+)?asset\s+(.{2,40})$/i
    );
    if (namedMatch) {
      const decision: 'keep' | 'reject' =
        namedMatch[1] === 'keep' ? 'keep' : 'reject';
      return { target: namedMatch[2].trim(), decision };
    }

    return null;
  };

  const assetSelection = detectAssetSelection(text);
  if (assetSelection) {
    actions.push({
      type: 'select_asset',
      target: assetSelection.target,
      decision: assetSelection.decision,
    });
  }

  // 12. GitHub Repo Clone matching (EN + HI/Hinglish)
  const cloneMatch =
    text.match(
      /\b(?:clone|import)\s+(?:github\s+)?(?:repo\s+)?(https?:\/\/github\.com\/[^\s]+|[a-zA-Z0-9._-]+\/[a-zA-Z0-9._-]+)\b/i
    ) ??
    text.match(
      /^(https?:\/\/github\.com\/[^\s]+|[a-zA-Z0-9._-]+\/[a-zA-Z0-9._-]+)\s+(?:clone|import)\s*(?:karo|kar\s+do)?$/i
    );
  if (cloneMatch && cloneMatch[1]) {
    actions.push({
      type: 'clone_repo',
      repoUrl: cloneMatch[1].trim(),
    });
  }

  // 13. Pro 3D Three.js Game Builder matching (EN + HI/Hinglish)
  if (
    /\b(build\s+3d\s+(?:car\s+|truck\s+|suv\s+|village\s+|racing\s+)?game|3d\s+car\s+game|3d\s+truck\s+game|truck\s+game\s+banao|3d\s+game\s+banao|car\s+game\s+banao|create\s+3d\s+game|make\s+3d\s+(?:car\s+|truck\s+)?game|launch\s+3d\s+game)\b/i.test(
      lower
    ) ||
    /(3d\s*गेम\s*बनाओ|ट्रक\s*गेम\s*बनाओ|कार\s*गेम\s*बनाओ)/i.test(text)
  ) {
    let theme = 'Village 3D Drive';
    if (/\b(truck|lorry|cargo|pickup)\b/i.test(lower) || text.includes('ट्रक')) {
      theme = 'Village Cargo Truck';
    } else if (/\b(suv|jeep|offroad|off-road|thar|4x4)\b/i.test(lower)) {
      theme = 'Off-Road Village SUV';
    } else if (/\b(sports?|racing|race|supercar|drift)\b/i.test(lower)) {
      theme = 'Street Sports 3D Drive';
    } else if (/\b(car|gaadi|gadi)\b/i.test(lower) || text.includes('कार')) {
      theme = 'Village 3D Car Drive';
    }
    actions.push({ type: 'build_3d_game', theme });
  }

  // 14a. Commercial App Builder matching (EN + HI/Hinglish)
  if (
    /\b(commercial\s+app\s+banao|build\s+(?:a\s+)?commercial\s+app|create\s+(?:a\s+)?commercial\s+app|build\s+(?:a\s+)?(?:fintech|upi|payment|wallet|fantasy|dream11|phonepe|ecommerce|e-commerce|shopping|booking)\s+app|(?:fintech|upi|payment|wallet|fantasy|dream11|phonepe|ecommerce|shopping|booking)\s+app\s+banao)\b/i.test(
      lower
    ) ||
    /(कॉमर्शियल\s*ऐप\s*बनाओ|फिनटेक\s*ऐप\s*बनाओ|शॉपिंग\s*ऐप\s*बनाओ|बुकिंग\s*ऐप\s*बनाओ)/i.test(
      text
    )
  ) {
    let category = 'fintech';
    if (/\b(dream11|fantasy|cricket|contest|ipl)\b/i.test(lower)) {
      category = 'fantasy';
    } else if (/\b(ecommerce|e-commerce|shopping|shop|store|marketplace)\b/i.test(lower) || text.includes('शॉपिंग')) {
      category = 'ecommerce';
    } else if (/\b(booking|hotel|flight|travel|cab|ticket)\b/i.test(lower) || text.includes('बुकिंग')) {
      category = 'booking';
    }
    actions.push({
      type: 'build_commercial_app',
      category,
      prompt: text,
    });
  }

  // 14b. 2-Voice Broadcast Audio / Short Video Maker matching (EN + HI/Hinglish)
  if (
    /\b(broadcast\s+video\s+banao|create\s+(?:a\s+)?broadcast|build\s+(?:a\s+)?broadcast|make\s+(?:a\s+)?broadcast|2[\s-]?voice\s+broadcast|short\s+video\s+banao|reel\s+banao|podcast\s+banao|broadcast\s+(?:about|on)\s+.+)\b/i.test(
      lower
    ) ||
    /(ब्रॉडकास्ट\s*वीडियो\s*बनाओ|शॉर्ट\s*वीडियो\s*बनाओ|रील\s*बनाओ)/i.test(text)
  ) {
    const topicMatch = text.match(
      /(?:about|on|for|topic)\s+(.{2,80})$/i
    );
    const cleanedTopic =
      topicMatch?.[1]?.trim() ||
      text
        .replace(
          /\b(broadcast|video|short|reel|podcast|create|build|make|banao|2-voice|2 voice|a)\b/gi,
          ' '
        )
        .replace(/(ब्रॉडकास्ट|वीडियो|शॉर्ट|रील|बनाओ)/g, ' ')
        .replace(/\s+/g, ' ')
        .trim() ||
      'Sarfealam Auto-Studio Launch';

    actions.push({
      type: 'create_broadcast',
      topic: cleanedTopic.slice(0, 80),
    });
  }

  // 15a. Dynamic Bot-to-Bot Mesh (spawn_sub_bot) matching (EN + HI/Hinglish)
  // Guard: never auto-spawn Sub-Bot when user asks to check/test API keys
  const spawnBotPrefix = !isApiCheckIntent
    ? text.match(
        /^(?:please\s+)?(?:spawn|launch|run|start)\s+(?:a\s+)?(.+?)\s+(?:sub[\s-]?)?bot(?:\s*(?:to|for|:|-)?\s*(.+))?$/i
      )
    : null;
  const subBotDirect = !isApiCheckIntent
    ? text.match(/^(?:sub[\s-]?bot|सब\s*बॉट)\s*[:\-]?\s*(.+)$/i)
    : null;
  if (spawnBotPrefix && spawnBotPrefix[1]) {
    const rawRole = spawnBotPrefix[1]
      .replace(/\b(helper|specialist|sub|mini|a|an|the)\b/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    const role = rawRole
      ? rawRole.toLowerCase() === 'qa'
        ? 'QA Reviewer'
        : rawRole
            .split(' ')
            .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
            .join(' ')
      : 'QA Reviewer';
    const task =
      spawnBotPrefix[2]?.trim() ||
      `Inspect the active workspace as ${role} and report concise improvements.`;
    actions.push({
      type: 'spawn_sub_bot',
      role: role.slice(0, 60),
      task: task.slice(0, 220),
    });
  } else if (subBotDirect && subBotDirect[1]) {
    const body = subBotDirect[1].trim();
    const colonParts = body.split(/\s*[:\-]\s*/);
    let role = 'QA Reviewer';
    let task = body;
    if (colonParts.length >= 2 && colonParts[0].length <= 36) {
      role = colonParts[0].trim();
      task = colonParts.slice(1).join(' - ').trim() || body;
    } else if (/\b(physics|tuner|gravity|steering)\b/i.test(body)) {
      role = 'Physics Tuner';
    } else if (/\b(ui|polish|glass|layout|360px)\b/i.test(body)) {
      role = 'UI Polish';
    } else if (/\b(api|supabase|security|isolation)\b/i.test(body)) {
      role = 'API Architect';
    }
    actions.push({
      type: 'spawn_sub_bot',
      role: role.slice(0, 60),
      task: task.slice(0, 220),
    });
  }

  // 15b. Self-Expanding Skills (fetch_any_api) matching (EN + HI/Hinglish)
  const fetchApiMatch =
    text.match(
      /\b(?:fetch|call|test|save|run)\s+(?:any\s+)?api(?:\s+skill)?\s+(?:([a-zA-Z0-9._-]{2,32})\s+)?(https?:\/\/[^\s]+)/i
    ) ??
    text.match(
      /\bapi\s+(?:fetch|call|test)\s+(?:([a-zA-Z0-9._-]{2,32})\s+)?(https?:\/\/[^\s]+)/i
    );
  if (fetchApiMatch && fetchApiMatch[2]) {
    const url = fetchApiMatch[2].replace(/[),.;]+$/, '').trim();
    let derivedName = fetchApiMatch[1]?.trim() || '';
    if (!derivedName) {
      try {
        derivedName = new URL(url).hostname.replace(/^www\./, '');
      } catch {
        derivedName = 'api-skill';
      }
    }
    actions.push({
      type: 'fetch_any_api',
      name: derivedName.slice(0, 64),
      url,
    });
  }

  return deduplicateActions(actions);
}

export function executeUIActions(
  actions: UIAction[],
  setWorldState: Dispatch<SetStateAction<WorldState>>,
  files: VirtualFile[],
  onSelectFile?: (path: string) => void,
  onSearchAssets?: (query: string, categories?: AssetCategory[]) => void,
  onSelectAsset?: (target: string, decision: 'keep' | 'reject') => string | void,
  onCloneRepo?: (repoUrl: string) => void,
  onBuild3DGame?: (theme?: string) => void,
  onBuildCommercialApp?: (category?: string, prompt?: string) => void,
  onCreateBroadcast?: (topic: string) => void,
  onSpawnSubBot?: (role: string, task: string) => void,
  onFetchAnyApi?: (name: string, url: string) => void,
  onTestApis?: () => void
): string[] {
  const sanitized = sanitizeUIActions(actions, files);
  if (sanitized.length === 0) return [];

  const labels: string[] = [];
  const patch: Partial<WorldState> = {};
  let panelToEmit: PanelId | null = null;
  let selectedFilePath: string | null = null;
  let pendingAssetSearch: { query: string; categories?: AssetCategory[] } | null =
    null;
  let pendingAssetSelection: {
    target: string;
    decision: 'keep' | 'reject';
  } | null = null;
  let pendingCloneRepo: string | null = null;
  let pendingBuild3DGame: { triggered: boolean; theme?: string } | null = null;
  let pendingBuildCommercialApp: {
    triggered: boolean;
    category?: string;
    prompt?: string;
  } | null = null;
  let pendingCreateBroadcast: { topic: string } | null = null;
  let pendingSpawnSubBot: { role: string; task: string } | null = null;
  let pendingFetchAnyApi: { name: string; url: string } | null = null;
  let pendingTestApis = false;

  for (const action of sanitized) {
    switch (action.type) {
      case 'open_panel':
        patch.activePanel = action.panel;
        panelToEmit = action.panel;
        labels.push(PANEL_NAMES[action.panel]);
        break;
      case 'set_display_mode':
        patch.displayMode = action.mode;
        labels.push(DISPLAY_NAMES[action.mode]);
        break;
      case 'set_language':
        patch.language = action.language;
        labels.push(action.language === 'hi' ? 'Language → हिं' : 'Language → EN');
        break;
      case 'set_mode':
        patch.mode = action.mode;
        labels.push(action.mode === 'jarvis' ? 'Mode → JARVIS' : 'Mode → Manual');
        break;
      case 'set_engine':
        patch.targetEngine = action.engine;
        labels.push(ENGINE_NAMES[action.engine]);
        break;
      case 'select_file':
        selectedFilePath = action.path;
        patch.activePanel = 'code';
        panelToEmit = 'code';
        labels.push(`Opened ${action.path}`);
        break;
      case 'set_stage': {
        const label = setStudioPipelineStage(action.stage);
        patch.currentStage = label;
        labels.push(`Stage → ${label}`);
        break;
      }
      case 'save_memory': {
        const currentRules = patch.memoryRules ?? loadMemoryRules();
        const { rules: updatedRules } = addMemoryRuleUnique(
          currentRules,
          action.rule
        );
        patch.memoryRules = updatedRules;
        labels.push('Saved Memory Rule');
        break;
      }
      case 'set_paused': {
        if (action.paused) {
          const { stage } = pauseStudioPipeline(patch.currentStage);
          patch.paused = true;
          labels.push(`Paused · Stage ${stage}`);
        } else {
          const { stage } = resumeStudioPipeline(patch.currentStage);
          patch.paused = false;
          labels.push(`Resumed · Stage ${stage}`);
        }
        break;
      }
      case 'search_assets': {
        pendingAssetSearch = {
          query: action.query,
          categories: action.categories,
        };
        patch.activePanel = 'vault';
        panelToEmit = 'vault';
        labels.push(
          action.query
            ? `Hunt Assets → ${action.query}`
            : 'Hunt Assets'
        );
        break;
      }
      case 'select_asset': {
        pendingAssetSelection = {
          target: action.target,
          decision: action.decision,
        };
        labels.push(
          action.decision === 'keep'
            ? `Keep Asset (${action.target})`
            : `Reject Asset (${action.target})`
        );
        break;
      }
      case 'clone_repo': {
        pendingCloneRepo = action.repoUrl;
        labels.push(`Clone Repo → ${action.repoUrl}`);
        break;
      }
      case 'build_3d_game': {
        pendingBuild3DGame = { triggered: true, theme: action.theme };
        patch.displayMode = 'expanded';
        labels.push(
          action.theme
            ? `Build 3D Game → ${action.theme}`
            : 'Build 3D Game'
        );
        break;
      }
      case 'build_commercial_app': {
        pendingBuildCommercialApp = {
          triggered: true,
          category: action.category,
          prompt: action.prompt,
        };
        patch.displayMode = 'expanded';
        labels.push(
          action.category
            ? `Build Commercial App → ${action.category}`
            : 'Build Commercial App'
        );
        break;
      }
      case 'create_broadcast': {
        pendingCreateBroadcast = { topic: action.topic };
        patch.displayMode = 'expanded';
        labels.push(`Broadcast → ${action.topic}`);
        break;
      }
      case 'spawn_sub_bot': {
        pendingSpawnSubBot = { role: action.role, task: action.task };
        labels.push(`Sub-Bot → ${action.role}`);
        break;
      }
      case 'fetch_any_api': {
        pendingFetchAnyApi = { name: action.name, url: action.url };
        labels.push(`Fetch API → ${action.name}`);
        break;
      }
      case 'test_apis': {
        pendingTestApis = true;
        labels.push('Test All APIs');
        break;
      }
    }
  }

  if (selectedFilePath && onSelectFile) {
    onSelectFile(selectedFilePath);
  }

  if (Object.keys(patch).length > 0) {
    setWorldState((prev) => ({
      ...prev,
      ...patch,
      lastUpdated: Date.now(),
    }));

    studioBus.emit('world:update', {
      patch,
      source: 'ui-actuators',
    });
  }

  if (panelToEmit !== null) {
    studioBus.emit('ui:panel', { panel: panelToEmit });
  }

  if (pendingAssetSearch && onSearchAssets) {
    onSearchAssets(pendingAssetSearch.query, pendingAssetSearch.categories);
  }

  if (pendingAssetSelection && onSelectAsset) {
    const summary = onSelectAsset(
      pendingAssetSelection.target,
      pendingAssetSelection.decision
    );
    if (summary) {
      labels[labels.length - 1] = summary;
    }
  }

  if (pendingCloneRepo && onCloneRepo) {
    onCloneRepo(pendingCloneRepo);
  }

  if (pendingBuild3DGame?.triggered && onBuild3DGame) {
    onBuild3DGame(pendingBuild3DGame.theme);
  }

  if (pendingBuildCommercialApp?.triggered && onBuildCommercialApp) {
    onBuildCommercialApp(
      pendingBuildCommercialApp.category,
      pendingBuildCommercialApp.prompt
    );
  }

  if (pendingCreateBroadcast && onCreateBroadcast) {
    onCreateBroadcast(pendingCreateBroadcast.topic);
  }

  if (pendingSpawnSubBot && onSpawnSubBot) {
    onSpawnSubBot(pendingSpawnSubBot.role, pendingSpawnSubBot.task);
  }

  if (pendingFetchAnyApi && onFetchAnyApi) {
    onFetchAnyApi(pendingFetchAnyApi.name, pendingFetchAnyApi.url);
  }

  if (pendingTestApis && onTestApis) {
    onTestApis();
  }

  return labels;
}
