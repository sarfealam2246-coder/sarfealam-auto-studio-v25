import { studioBus } from './eventBus';
import { buildMemoryContext } from './memoryService';
import { DEFAULT_2026_MODELS } from './secretsService';
import type { Language, UserMemoryRule } from '../types/studio';

const VISION_TIMEOUT_MS = 15_000;

export interface AnalyzeImageOptions {
  base64DataUrl: string;
  prompt: string;
  geminiKey: string;
  geminiModel?: string;
  language: Language;
  memoryRules: UserMemoryRule[];
}

export interface VisionAnalysisResult {
  ok: boolean;
  text: string;
  modelUsed: string;
  durationMs: number;
  error?: string;
}

export interface ConceptVisualResult {
  ok: boolean;
  dataUrl: string;
  source: 'gemini-image' | 'imagen-3' | 'local-canvas';
  caption: string;
  note?: string;
  durationMs: number;
}

function parseDataUrl(dataUrl: string): { mimeType: string; base64Data: string } | null {
  const trimmed = dataUrl.trim();
  const match = trimmed.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,([\s\S]+)$/);
  if (!match) return null;
  const rawMime = match[1].toLowerCase();
  const mimeType =
    rawMime === 'image/jpg'
      ? 'image/jpeg'
      : rawMime === 'image/png' || rawMime === 'image/jpeg' || rawMime === 'image/webp'
        ? rawMime
        : 'image/jpeg';
  const base64Data = match[2].replace(/\s+/g, '');
  if (!base64Data) return null;
  return { mimeType, base64Data };
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs = VISION_TIMEOUT_MS
): Promise<Response> {
  const controller = new AbortController();
  const timerId = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    window.clearTimeout(timerId);
  }
}

export async function analyzeImageWithGemini(
  options: AnalyzeImageOptions
): Promise<VisionAnalysisResult> {
  const startedAt = Date.now();
  const apiKey = options.geminiKey.trim();
  const model = options.geminiModel?.trim() || DEFAULT_2026_MODELS.gemini;

  studioBus.emit('bot:progress', {
    botId: 'vision',
    status: 'working',
    progress: 30,
    message: 'Analyzing image with Gemini Vision...',
  });

  let finalStatus: 'ready' | 'error' = 'ready';
  let finalProgress = 100;
  let finalMessage = 'Vision analysis complete';

  try {
    if (!apiKey) {
      finalStatus = 'error';
      finalProgress = 0;
      finalMessage = 'Gemini API Key required';
      return {
        ok: false,
        text:
          options.language === 'hi'
            ? 'विज़न विश्लेषण के लिए पहले Secrets में Google Gemini API Key जोड़ें।'
            : 'Add your Google Gemini API Key in Secrets to analyze images with Gemini Vision.',
        modelUsed: model,
        durationMs: Date.now() - startedAt,
        error: 'Missing Gemini API key',
      };
    }

    const parsed = parseDataUrl(options.base64DataUrl);
    if (!parsed) {
      finalStatus = 'error';
      finalProgress = 0;
      finalMessage = 'Invalid image payload';
      return {
        ok: false,
        text:
          options.language === 'hi'
            ? 'कृपया पहले कैमरा कैप्चर करें या कोई छवि अपलोड करें।'
            : 'Please capture a camera frame or upload a valid image first.',
        modelUsed: model,
        durationMs: Date.now() - startedAt,
        error: 'Invalid base64 image data URL',
      };
    }

    const memoryBlock = buildMemoryContext(options.memoryRules);
    const langInstruction =
      options.language === 'hi'
        ? 'Respond concisely and helpfully in natural Hindi / Hinglish.'
        : 'Respond concisely and practically in crisp English.';

    const systemText = [
      'You are Sarfealam Auto-Studio Camera Vision Eye.',
      langInstruction,
      'Analyze the provided visual frame for mobile game/app development, UI layout, 3D scene inspiration, lighting, or asset matching. Keep the response actionable and concise (3–6 short sentences or crisp bullets).',
      ...(memoryBlock ? [memoryBlock] : []),
    ].join('\n');

    const userPrompt =
      options.prompt.trim() ||
      (options.language === 'hi'
        ? 'इस छवि का विश्लेषण करें और गेम/ऐप बनाने के लिए मुख्य विज़ुअल और एसेट सुझाव दें।'
        : 'Analyze this image and highlight key visual details, colors, objects, and useful studio asset ideas.');

    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
      model
    )}:generateContent?key=${encodeURIComponent(apiKey)}`;

    const response = await fetchWithTimeout(
      endpoint,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: systemText }],
          },
          contents: [
            {
              role: 'user',
              parts: [
                {
                  inlineData: {
                    mimeType: parsed.mimeType,
                    data: parsed.base64Data,
                  },
                },
                { text: userPrompt },
              ],
            },
          ],
          generationConfig: {
            temperature: 0.35,
          },
        }),
      },
      VISION_TIMEOUT_MS
    );

    if (!response.ok) {
      throw new Error(`Gemini Vision HTTP ${response.status}`);
    }

    const json = (await response.json()) as {
      candidates?: {
        content?: {
          parts?: { text?: string }[];
        };
      }[];
    };

    const text =
      json.candidates?.[0]?.content?.parts
        ?.map((p) => p.text ?? '')
        .join('')
        .trim() ?? '';

    if (!text) {
      throw new Error('Empty Gemini Vision response');
    }

    finalStatus = 'ready';
    finalProgress = 100;
    finalMessage = `Analyzed via ${model}`;

    return {
      ok: true,
      text,
      modelUsed: model,
      durationMs: Date.now() - startedAt,
    };
  } catch (err) {
    const isTimeout = err instanceof DOMException && err.name === 'AbortError';
    const errMsg = isTimeout
      ? 'Gemini Vision timed out after 15s.'
      : err instanceof Error
        ? err.message
        : 'Vision analysis failed.';

    finalStatus = 'error';
    finalProgress = 0;
    finalMessage = errMsg;

    return {
      ok: false,
      text:
        options.language === 'hi'
          ? `विज़न विश्लेषण विफल रहा: ${errMsg}`
          : `Vision analysis failed: ${errMsg}`,
      modelUsed: model,
      durationMs: Date.now() - startedAt,
      error: errMsg,
    };
  } finally {
    studioBus.emit('bot:progress', {
      botId: 'vision',
      status: finalStatus,
      progress: finalProgress,
      message: finalMessage,
    });
  }
}

function hashPrompt(str: string): number {
  let hash = 2166136261;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return Math.abs(hash);
}

function buildLocalConceptSvgDataUrl(prompt: string): string {
  const safeTitle = (prompt.trim() || 'Sarfealam Studio Concept')
    .replace(/[<>&"']/g, '')
    .slice(0, 64);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="960" height="540" viewBox="0 0 960 540">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#E0F2FE"/>
      <stop offset="50%" stop-color="#EDE9FE"/>
      <stop offset="100%" stop-color="#D1FAE5"/>
    </linearGradient>
    <linearGradient id="orb" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#007AFF"/>
      <stop offset="60%" stop-color="#5856D6"/>
      <stop offset="100%" stop-color="#10B981"/>
    </linearGradient>
  </defs>
  <rect width="960" height="540" fill="url(#bg)"/>
  <circle cx="720" cy="170" r="130" fill="url(#orb)" opacity="0.24"/>
  <circle cx="240" cy="390" r="170" fill="#007AFF" opacity="0.12"/>
  <rect x="48" y="48" width="864" height="444" rx="28" fill="rgba(255,255,255,0.78)" stroke="rgba(15,23,42,0.12)" stroke-width="2"/>
  <text x="86" y="122" font-family="system-ui, -apple-system, sans-serif" font-size="22" font-weight="700" fill="#007AFF">SARFEALAM AUTO-STUDIO · CONCEPT POSTER</text>
  <text x="86" y="250" font-family="system-ui, -apple-system, sans-serif" font-size="40" font-weight="800" fill="#0F172A">${safeTitle}</text>
  <text x="86" y="438" font-family="monospace" font-size="18" fill="#64748B">LOCAL CANVAS CONCEPT · READY FOR 3D &amp; UI ITERATION</text>
</svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function buildLocalConceptCanvasDataUrl(prompt: string): string {
  try {
    const canvas = document.createElement('canvas');
    canvas.width = 960;
    canvas.height = 540;
    const ctx = canvas.getContext('2d');
    if (!ctx) return buildLocalConceptSvgDataUrl(prompt);

    const seed = hashPrompt(prompt || 'studio');
    const palettes: [string, string, string, string][] = [
      ['#EFF6FF', '#EEF2FF', '#ECFDF5', '#007AFF'],
      ['#FDF4FF', '#EFF6FF', '#FEF3C7', '#5856D6'],
      ['#ECFDF5', '#E0F2FE', '#F5F3FF', '#10B981'],
      ['#FFF7ED', '#FEF2F2', '#EFF6FF', '#F59E0B'],
    ];
    const [c1, c2, c3, accent] = palettes[seed % palettes.length];

    // Luminous Apple-inspired sky backdrop
    const bgGrad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    bgGrad.addColorStop(0, c1);
    bgGrad.addColorStop(0.55, c2);
    bgGrad.addColorStop(1, c3);
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Subtle perspective grid
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.06)';
    ctx.lineWidth = 1;
    for (let x = 0; x <= canvas.width; x += 48) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y <= canvas.height; y += 48) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Glowing atmospheric spheres
    const orb1 = ctx.createRadialGradient(730, 165, 16, 730, 165, 190);
    orb1.addColorStop(0, `${accent}55`);
    orb1.addColorStop(1, `${accent}00`);
    ctx.fillStyle = orb1;
    ctx.beginPath();
    ctx.arc(730, 165, 190, 0, Math.PI * 2);
    ctx.fill();

    const orb2 = ctx.createRadialGradient(210, 410, 20, 210, 410, 210);
    orb2.addColorStop(0, 'rgba(16, 185, 129, 0.30)');
    orb2.addColorStop(1, 'rgba(16, 185, 129, 0)');
    ctx.fillStyle = orb2;
    ctx.beginPath();
    ctx.arc(210, 410, 210, 0, Math.PI * 2);
    ctx.fill();

    // Stylized geometric horizon silhouette
    ctx.fillStyle = 'rgba(15, 23, 42, 0.08)';
    ctx.beginPath();
    ctx.moveTo(0, 430);
    ctx.lineTo(180, 345);
    ctx.lineTo(360, 405);
    ctx.lineTo(570, 310);
    ctx.lineTo(760, 385);
    ctx.lineTo(960, 330);
    ctx.lineTo(960, 540);
    ctx.lineTo(0, 540);
    ctx.closePath();
    ctx.fill();

    // Frosted glass concept card overlay
    ctx.fillStyle = 'rgba(255, 255, 255, 0.80)';
    ctx.strokeStyle = 'rgba(15, 23, 42, 0.10)';
    ctx.lineWidth = 2;
    const rx = 56;
    const ry = 64;
    const rw = 848;
    const rh = 412;
    const radius = 28;
    ctx.beginPath();
    ctx.moveTo(rx + radius, ry);
    ctx.lineTo(rx + rw - radius, ry);
    ctx.quadraticCurveTo(rx + rw, ry, rx + rw, ry + radius);
    ctx.lineTo(rx + rw, ry + rh - radius);
    ctx.quadraticCurveTo(rx + rw, ry + rh, rx + rw - radius, ry + rh);
    ctx.lineTo(rx + radius, ry + rh);
    ctx.quadraticCurveTo(rx, ry + rh, rx, ry + rh - radius);
    ctx.lineTo(rx, ry + radius);
    ctx.quadraticCurveTo(rx, ry, rx + radius, ry);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Top badge
    ctx.fillStyle = accent;
    ctx.font = '700 18px system-ui, -apple-system, sans-serif';
    ctx.fillText('SARFEALAM AUTO-STUDIO · CONCEPT VISUAL', 94, 126);

    // Wrapped concept title
    const cleanPrompt = (prompt.trim() || 'Interactive 3D Mobile Studio Concept').slice(0, 110);
    ctx.fillStyle = '#0F172A';
    ctx.font = '800 38px system-ui, -apple-system, sans-serif';
    const words = cleanPrompt.split(/\s+/);
    const lines: string[] = [];
    let currentLine = '';
    for (const w of words) {
      const candidate = currentLine ? `${currentLine} ${w}` : w;
      if (ctx.measureText(candidate).width > 740 && currentLine) {
        lines.push(currentLine);
        currentLine = w;
        if (lines.length >= 3) break;
      } else {
        currentLine = candidate;
      }
    }
    if (currentLine && lines.length < 3) {
      lines.push(currentLine);
    }

    let y = 210;
    for (const line of lines) {
      ctx.fillText(line, 94, y);
      y += 52;
    }

    // Color swatch dots
    const swatches = ['#007AFF', '#5856D6', '#10B981', '#F59E0B', '#FF3B30'];
    swatches.forEach((hex, idx) => {
      ctx.fillStyle = hex;
      ctx.beginPath();
      ctx.arc(108 + idx * 34, 412, 10, 0, Math.PI * 2);
      ctx.fill();
    });

    ctx.fillStyle = '#64748B';
    ctx.font = '600 16px ui-monospace, SFMono-Regular, monospace';
    ctx.fillText('LOCAL CANVAS FALLBACK · 16:9 CONCEPT BOARD', 298, 418);

    return canvas.toDataURL('image/png');
  } catch {
    return buildLocalConceptSvgDataUrl(prompt);
  }
}

export async function generateConceptVisual(
  prompt: string,
  geminiKey?: string
): Promise<ConceptVisualResult> {
  const startedAt = Date.now();
  const cleanPrompt =
    prompt.trim() || 'Clean futuristic mobile 3D game concept art, daylight atmosphere';
  const apiKey = geminiKey?.trim() ?? '';

  studioBus.emit('bot:progress', {
    botId: 'vision',
    status: 'working',
    progress: 35,
    message: 'Generating concept visual...',
  });

  let finalMessage = 'Concept visual ready';

  try {
    if (apiKey) {
      // Attempt 1: Gemini Image Generation endpoint (15s AbortController timeout)
      try {
        const geminiImgUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp-image-generation:generateContent?key=${encodeURIComponent(
          apiKey
        )}`;
        const res = await fetchWithTimeout(
          geminiImgUrl,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: [
                {
                  role: 'user',
                  parts: [
                    {
                      text: `Create a clean, crisp concept visual for: ${cleanPrompt}`,
                    },
                  ],
                },
              ],
              generationConfig: {
                responseModalities: ['IMAGE', 'TEXT'],
              },
            }),
          },
          VISION_TIMEOUT_MS
        );

        if (res.ok) {
          const data = (await res.json()) as {
            candidates?: {
              content?: {
                parts?: {
                  text?: string;
                  inlineData?: { mimeType?: string; data?: string };
                }[];
              };
            }[];
          };
          const parts = data.candidates?.[0]?.content?.parts ?? [];
          const imagePart = parts.find((p) => p.inlineData?.data);
          if (imagePart?.inlineData?.data) {
            const mime = imagePart.inlineData.mimeType || 'image/png';
            const caption =
              parts
                .map((p) => p.text ?? '')
                .join(' ')
                .trim() || `Generated concept visual for "${cleanPrompt}".`;
            finalMessage = 'Concept visual generated (Gemini)';
            return {
              ok: true,
              dataUrl: `data:${mime};base64,${imagePart.inlineData.data}`,
              source: 'gemini-image',
              caption,
              durationMs: Date.now() - startedAt,
            };
          }
        }
      } catch {
        // Fall through cleanly to Imagen 3
      }

      // Attempt 2: Imagen 3 predict endpoint (15s AbortController timeout)
      try {
        const imagenUrl = `https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-002:predict?key=${encodeURIComponent(
          apiKey
        )}`;
        const res = await fetchWithTimeout(
          imagenUrl,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              instances: [{ prompt: cleanPrompt }],
              parameters: { sampleCount: 1, aspectRatio: '16:9' },
            }),
          },
          VISION_TIMEOUT_MS
        );

        if (res.ok) {
          const data = (await res.json()) as {
            predictions?: { bytesBase64Encoded?: string; mimeType?: string }[];
          };
          const b64 = data.predictions?.[0]?.bytesBase64Encoded;
          if (b64) {
            const mime = data.predictions?.[0]?.mimeType || 'image/png';
            finalMessage = 'Concept visual generated (Imagen 3)';
            return {
              ok: true,
              dataUrl: `data:${mime};base64,${b64}`,
              source: 'imagen-3',
              caption: `Generated Imagen 3 concept visual for "${cleanPrompt}".`,
              durationMs: Date.now() - startedAt,
            };
          }
        }
      } catch {
        // Fall through cleanly to local Canvas/SVG concept poster
      }
    }

    // Crisp local HTML5 Canvas / SVG concept poster fallback (never crashes)
    const fallbackUrl = buildLocalConceptCanvasDataUrl(cleanPrompt);
    finalMessage = 'Concept poster ready (Local Canvas)';
    return {
      ok: true,
      dataUrl: fallbackUrl,
      source: 'local-canvas',
      caption: `Created local concept poster for "${cleanPrompt}".`,
      note: apiKey
        ? 'Cloud image endpoint unavailable — rendered crisp local Concept Poster.'
        : 'Add a Gemini API Key in Secrets for cloud image generation; rendered local Concept Poster.',
      durationMs: Date.now() - startedAt,
    };
  } finally {
    studioBus.emit('bot:progress', {
      botId: 'vision',
      status: 'ready',
      progress: 100,
      message: finalMessage,
    });
  }
}
