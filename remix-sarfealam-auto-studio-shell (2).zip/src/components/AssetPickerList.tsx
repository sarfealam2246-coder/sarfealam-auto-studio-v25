import { useEffect, useState } from 'react';
import {
  Check,
  X,
  Play,
  Square,
  Car,
  User,
  Swords,
  Trees,
  Layers,
  CloudSun,
  Volume2,
  Bell,
  Image as ImageIcon,
  Shapes,
  Archive,
  CheckCircle2,
  Trash2,
} from 'lucide-react';
import { ASSET_DEPARTMENTS } from '../services/assetHunterService';
import type {
  AssetCategory,
  Language,
  StudioAssetItem,
} from '../types/studio';

// Single-instance HTML5 Audio manager so only one audio clip plays at a time
// and playback stops cleanly on panel close / tab switch / unmount.
let sharedAudioEl: HTMLAudioElement | null = null;
let sharedPlayingId: string | null = null;
let sharedErrorId: string | null = null;
const audioListeners = new Set<() => void>();

function notifyAudioListeners(): void {
  for (const listener of audioListeners) {
    listener();
  }
}

export function stopAssetPreviewAudio(): void {
  if (sharedAudioEl) {
    try {
      sharedAudioEl.pause();
      sharedAudioEl.currentTime = 0;
      sharedAudioEl.removeAttribute('src');
      sharedAudioEl.load();
    } catch {
      // ignore media teardown errors
    }
    sharedAudioEl = null;
  }
  if (sharedPlayingId !== null || sharedErrorId !== null) {
    sharedPlayingId = null;
    sharedErrorId = null;
    notifyAudioListeners();
  }
}

function toggleAssetPreviewAudio(item: StudioAssetItem): void {
  if (sharedPlayingId === item.id) {
    stopAssetPreviewAudio();
    return;
  }

  stopAssetPreviewAudio();

  if (!item.url) {
    sharedErrorId = item.id;
    notifyAudioListeners();
    return;
  }

  const audio = new Audio();
  audio.preload = 'none';
  audio.crossOrigin = 'anonymous';
  audio.src = item.url;

  sharedAudioEl = audio;
  sharedPlayingId = item.id;
  sharedErrorId = null;
  notifyAudioListeners();

  audio.onended = () => {
    if (sharedAudioEl === audio) {
      sharedAudioEl = null;
      sharedPlayingId = null;
      notifyAudioListeners();
    }
  };

  audio.onerror = () => {
    if (sharedAudioEl === audio) {
      sharedAudioEl = null;
      sharedPlayingId = null;
      sharedErrorId = item.id;
      notifyAudioListeners();
    }
  };

  void audio.play().catch(() => {
    if (sharedAudioEl === audio) {
      sharedAudioEl = null;
      sharedPlayingId = null;
      sharedErrorId = item.id;
      notifyAudioListeners();
    }
  });
}

function useSharedAudioState(): { playingId: string | null; errorId: string | null } {
  const [, setTick] = useState(0);

  useEffect(() => {
    const listener = () => setTick((t) => t + 1);
    audioListeners.add(listener);
    return () => {
      audioListeners.delete(listener);
    };
  }, []);

  return { playingId: sharedPlayingId, errorId: sharedErrorId };
}

const DEPARTMENT_ICONS: Record<AssetCategory, typeof Car> = {
  vehicles: Car,
  characters: User,
  weapons_gear: Swords,
  village_world: Trees,
  textures_pbr: Layers,
  hdri_sky: CloudSun,
  audio_sfx: Volume2,
  app_audio: Bell,
  wikimedia_photos: ImageIcon,
  iconify_icons: Shapes,
};

const MODEL_3D_GRADIENTS: Partial<Record<AssetCategory, string>> = {
  vehicles: 'from-[#007AFF]/16 via-[#38BDF8]/12 to-[#5856D6]/14',
  characters: 'from-[#5856D6]/16 via-[#A855F7]/12 to-[#EC4899]/12',
  weapons_gear: 'from-[#FF3B30]/15 via-[#F97316]/12 to-[#F59E0B]/12',
  village_world: 'from-[#10B981]/16 via-[#14B8A6]/12 to-[#007AFF]/12',
};

const VISUAL_CATEGORIES = new Set<AssetCategory>([
  'wikimedia_photos',
  'iconify_icons',
  'textures_pbr',
  'hdri_sky',
]);

const AUDIO_CATEGORIES = new Set<AssetCategory>(['audio_sfx', 'app_audio']);

function isAudioItem(item: StudioAssetItem): boolean {
  if (AUDIO_CATEGORIES.has(item.category)) return true;
  const fmt = (item.format ?? '').toLowerCase();
  return ['mp3', 'wav', 'ogg', 'm4a', 'aac', 'flac'].includes(fmt);
}

function isVisualThumbnailItem(item: StudioAssetItem): boolean {
  if (VISUAL_CATEGORIES.has(item.category)) return true;
  const fmt = (item.format ?? '').toLowerCase();
  return ['png', 'jpg', 'jpeg', 'webp', 'svg', 'gif'].includes(fmt);
}

function isSameAsset(a: StudioAssetItem, b: StudioAssetItem): boolean {
  return a.id === b.id || (Boolean(a.url) && a.url === b.url);
}

export interface AssetPickerListProps {
  candidates: StudioAssetItem[];
  selectedAssets: StudioAssetItem[];
  language: Language;
  compact?: boolean;
  onKeep: (item: StudioAssetItem) => void;
  onReject: (item: StudioAssetItem) => void;
  onRemoveSelected: (item: StudioAssetItem) => void;
}

interface PickerCardProps {
  item: StudioAssetItem;
  indexNumber: number;
  isKept: boolean;
  isSelectedViewOnly: boolean;
  compact: boolean;
  playingId: string | null;
  errorId: string | null;
  language: Language;
  onKeep: (item: StudioAssetItem) => void;
  onReject: (item: StudioAssetItem) => void;
  onRemoveSelected: (item: StudioAssetItem) => void;
}

function AssetPickerCard({
  item,
  indexNumber,
  isKept,
  isSelectedViewOnly,
  compact,
  playingId,
  errorId,
  language,
  onKeep,
  onReject,
  onRemoveSelected,
}: PickerCardProps) {
  const [imgFailed, setImgFailed] = useState(false);
  const deptMeta = ASSET_DEPARTMENTS.find((d) => d.id === item.category);
  const DeptIcon = DEPARTMENT_ICONS[item.category] ?? Archive;
  const isAudio = isAudioItem(item);
  const isPlaying = playingId === item.id;
  const hasAudioError = errorId === item.id;

  const thumbnailSrc =
    item.previewUrl || (isVisualThumbnailItem(item) ? item.url : undefined);
  const showImagePreview = Boolean(thumbnailSrc && !imgFailed && !isAudio);
  const modelGradient =
    MODEL_3D_GRADIENTS[item.category] ??
    'from-[#F3F6FB] via-[#EDF3FC] to-[#E8EFFA]';

  return (
    <article
      className={`bg-white/92 backdrop-blur-md border rounded-2xl p-2 flex flex-col gap-1.5 shadow-[0_4px_14px_rgba(15,23,42,0.045)] min-w-0 overflow-hidden transition-all ${
        isKept
          ? 'border-[#10B981]/50 ring-1 ring-[#10B981]/20'
          : 'border-slate-200/85'
      }`}
    >
      {/* Visual / 3D Badge / Audio Preview Box */}
      <div
        className={`relative w-full ${
          compact ? 'aspect-[16/9]' : 'aspect-[16/10]'
        } rounded-xl bg-gradient-to-br ${
          isAudio
            ? 'from-[#EC4899]/12 via-[#8B5CF6]/10 to-[#007AFF]/10'
            : modelGradient
        } border border-slate-200/65 flex items-center justify-center overflow-hidden`}
      >
        {/* 1-based Index Badge for Voice Selection ("keep 1", "reject second") */}
        <span className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded-md bg-slate-900/75 text-white text-[9px] font-mono font-bold tabular-nums z-10">
          #{indexNumber}
        </span>

        {/* Format Pill */}
        <span className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded-md bg-white/92 backdrop-blur-sm border border-slate-200/80 text-[9px] font-mono font-bold uppercase text-[#0F172A] z-10">
          {(item.format || (isAudio ? 'audio' : 'glb')).slice(0, 5)}
        </span>

        {showImagePreview ? (
          <img
            src={thumbnailSrc}
            alt={item.name}
            loading="lazy"
            onError={() => setImgFailed(true)}
            className={
              item.category === 'iconify_icons'
                ? compact
                  ? 'w-8 h-8 object-contain'
                  : 'w-10 h-10 object-contain'
                : 'w-full h-full object-cover'
            }
          />
        ) : isAudio ? (
          <div className="flex flex-col items-center justify-center gap-1 px-2">
            <button
              type="button"
              onClick={() => toggleAssetPreviewAudio(item)}
              aria-label={isPlaying ? `Stop ${item.name}` : `Play ${item.name}`}
              className={`h-8 px-3 rounded-full text-[11px] font-bold inline-flex items-center gap-1.5 shadow-xs transition-all cursor-pointer active:scale-95 whitespace-nowrap ${
                isPlaying
                  ? 'bg-[#FF3B30] text-white'
                  : 'bg-gradient-to-r from-[#EC4899] to-[#8B5CF6] text-white hover:brightness-105'
              }`}
            >
              {isPlaying ? (
                <>
                  <Square className="w-3 h-3 fill-current shrink-0" aria-hidden="true" />
                  <span>Stop</span>
                </>
              ) : (
                <>
                  <Play className="w-3 h-3 fill-current shrink-0" aria-hidden="true" />
                  <span>Play</span>
                </>
              )}
            </button>
            {hasAudioError && (
              <span className="text-[9px] font-semibold text-[#DC2626] truncate max-w-full">
                {language === 'hi' ? 'ऑडियो लोड नहीं हुआ' : 'Audio unavailable'}
              </span>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center gap-1 px-2">
            <div
              className={`w-9 h-9 rounded-xl bg-white/90 border border-white shadow-xs flex items-center justify-center ${
                deptMeta?.accentText ?? 'text-[#007AFF]'
              }`}
            >
              <DeptIcon className="w-4 h-4" aria-hidden="true" />
            </div>
            <span
              className={`px-1.5 py-0.5 rounded-full text-[9px] font-bold ${
                deptMeta?.accentBg ?? 'bg-slate-100'
              } ${deptMeta?.accentText ?? 'text-slate-700'}`}
            >
              {deptMeta?.shortLabel ?? item.category}
            </span>
          </div>
        )}
      </div>

      {/* Name + Department Tag */}
      <div className="min-w-0 flex flex-col gap-1">
        <h4
          className="text-[11px] font-bold text-[#0F172A] leading-tight line-clamp-1"
          title={item.name}
        >
          {item.name}
        </h4>

        <div className="flex items-center justify-between gap-1 min-w-0">
          <span
            className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[9.5px] font-semibold truncate ${
              deptMeta?.accentBg ?? 'bg-slate-100'
            } ${deptMeta?.accentText ?? 'text-slate-600'}`}
          >
            <DeptIcon className="w-2.5 h-2.5 shrink-0" aria-hidden="true" />
            <span className="truncate">{deptMeta?.shortLabel ?? item.category}</span>
          </span>

          {isKept && (
            <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-[#10B981]/14 text-[#047857] text-[9px] font-bold shrink-0">
              <CheckCircle2 className="w-2.5 h-2.5 shrink-0" aria-hidden="true" />
              <span>Selected</span>
            </span>
          )}
        </div>
      </div>

      {/* Interactive Keep / Reject Buttons */}
      {isSelectedViewOnly ? (
        <button
          type="button"
          onClick={() => onRemoveSelected(item)}
          className="w-full h-7 px-2 rounded-xl bg-[#FF3B30]/10 hover:bg-[#FF3B30]/18 border border-[#FF3B30]/25 text-[#DC2626] text-[10.5px] font-bold inline-flex items-center justify-center gap-1 transition-all cursor-pointer active:scale-[0.97] whitespace-nowrap"
        >
          <Trash2 className="w-3 h-3 shrink-0" aria-hidden="true" />
          <span>{language === 'hi' ? 'हटाएँ' : 'Remove'}</span>
        </button>
      ) : (
        <div className="grid grid-cols-2 gap-1 pt-0.5">
          {isKept ? (
            <button
              type="button"
              onClick={() => onRemoveSelected(item)}
              aria-pressed="true"
              className="h-7 px-1.5 rounded-xl bg-[#10B981]/15 hover:bg-[#10B981]/22 border border-[#10B981]/40 text-[#047857] text-[10px] font-bold inline-flex items-center justify-center gap-0.5 transition-all cursor-pointer active:scale-[0.97] whitespace-nowrap min-w-0"
            >
              <Check className="w-3 h-3 shrink-0" aria-hidden="true" />
              <span className="truncate">Selected</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onKeep(item)}
              className="h-7 px-1.5 rounded-xl bg-gradient-to-r from-[#10B981] to-[#059669] hover:brightness-105 text-white text-[10px] font-bold inline-flex items-center justify-center gap-0.5 shadow-2xs transition-all cursor-pointer active:scale-[0.97] whitespace-nowrap min-w-0"
            >
              <Check className="w-3 h-3 shrink-0" aria-hidden="true" />
              <span className="truncate">Keep</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => onReject(item)}
            className="h-7 px-1.5 rounded-xl bg-[#FF3B30]/10 hover:bg-[#FF3B30]/18 border border-[#FF3B30]/25 text-[#DC2626] text-[10px] font-bold inline-flex items-center justify-center gap-0.5 transition-all cursor-pointer active:scale-[0.97] whitespace-nowrap min-w-0"
          >
            <X className="w-3 h-3 shrink-0" aria-hidden="true" />
            <span className="truncate">Reject</span>
          </button>
        </div>
      )}
    </article>
  );
}

export function AssetPickerList({
  candidates,
  selectedAssets,
  language,
  compact = false,
  onKeep,
  onReject,
  onRemoveSelected,
}: AssetPickerListProps) {
  const { playingId, errorId } = useSharedAudioState();
  const [scope, setScope] = useState<'candidates' | 'selected'>(() =>
    candidates.length > 0 ? 'candidates' : 'selected'
  );

  // Stop audio cleanly if this picker unmounts
  useEffect(() => {
    return () => {
      stopAssetPreviewAudio();
    };
  }, []);

  // Auto-switch to candidates when fresh hunt results arrive while viewing empty selected
  useEffect(() => {
    if (candidates.length > 0 && scope === 'selected' && selectedAssets.length === 0) {
      setScope('candidates');
    } else if (candidates.length === 0 && selectedAssets.length > 0) {
      setScope('selected');
    }
  }, [candidates.length, selectedAssets.length, scope]);

  const showSwitchBar = candidates.length > 0 || selectedAssets.length > 0;
  const activeItems = scope === 'candidates' ? candidates : selectedAssets;

  return (
    <div className="flex flex-col gap-2 min-w-0 w-full">
      {showSwitchBar && (
        <div className="flex items-center justify-between gap-1.5 min-w-0">
          <div className="inline-flex items-center p-0.5 rounded-xl bg-slate-100/95 border border-slate-200/80">
            <button
              type="button"
              onClick={() => {
                stopAssetPreviewAudio();
                setScope('candidates');
              }}
              aria-pressed={scope === 'candidates'}
              className={`h-6 px-2 rounded-lg text-[10.5px] font-bold transition-all cursor-pointer whitespace-nowrap tabular-nums ${
                scope === 'candidates'
                  ? 'bg-white text-[#0F172A] shadow-2xs'
                  : 'text-[#64748B] hover:text-[#0F172A]'
              }`}
            >
              {language === 'hi' ? 'परिणाम' : 'Results'} ({candidates.length})
            </button>
            <button
              type="button"
              onClick={() => {
                stopAssetPreviewAudio();
                setScope('selected');
              }}
              aria-pressed={scope === 'selected'}
              className={`h-6 px-2 rounded-lg text-[10.5px] font-bold transition-all cursor-pointer whitespace-nowrap tabular-nums ${
                scope === 'selected'
                  ? 'bg-[#10B981] text-white shadow-2xs'
                  : 'text-[#64748B] hover:text-[#0F172A]'
              }`}
            >
              {language === 'hi' ? 'चुने गए' : 'Selected'} ({selectedAssets.length})
            </button>
          </div>

          <span className="text-[10px] font-medium text-[#64748B] truncate">
            {scope === 'candidates'
              ? language === 'hi'
                ? 'बोलें "pehla rakho"'
                : 'Say "keep 1"'
              : 'assets/manifest.json'}
          </span>
        </div>
      )}

      {activeItems.length > 0 ? (
        <div
          className={`grid gap-2 min-w-0 ${
            compact ? 'grid-cols-2' : 'grid-cols-2 sm:grid-cols-3'
          }`}
        >
          {activeItems.map((item, idx) => {
            const kept = selectedAssets.some((sel) => isSameAsset(sel, item));
            return (
              <AssetPickerCard
                key={`${scope}:${item.id}:${idx}`}
                item={item}
                indexNumber={idx + 1}
                isKept={kept}
                isSelectedViewOnly={scope === 'selected'}
                compact={compact}
                playingId={playingId}
                errorId={errorId}
                language={language}
                onKeep={onKeep}
                onReject={onReject}
                onRemoveSelected={onRemoveSelected}
              />
            );
          })}
        </div>
      ) : (
        <div className="rounded-xl bg-white/80 border border-dashed border-slate-300/80 p-3 text-center text-[11px] text-[#64748B]">
          {scope === 'selected'
            ? language === 'hi'
              ? 'अभी कोई एसेट नहीं चुना गया — ✓ Keep टैप करें।'
              : 'No assets kept yet — tap ✓ Keep on any candidate.'
            : language === 'hi'
              ? 'सभी उम्मीदवार समीक्षा किए जा चुके हैं।'
              : 'All candidate assets reviewed.'}
        </div>
      )}
    </div>
  );
}
